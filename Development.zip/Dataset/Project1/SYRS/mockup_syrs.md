# Project 1 System Requirements
This project focuses on Avionics and ARINC protocols.
It includes subsystems for Communication and Navigation.
SR-001: The system shall support ARINC 429.
SR-002: The system shall provide secure communication.
