# 🚀 Understanding the ArchTech Integrated AI Workflow

This guide provides a simplified breakdown of how the ArchTech AI pipeline functions and where its key components reside in your local environment.

---

## 🛠️ System Overview
The ArchTech Integrated system is an automated documentation and code generation engine. It uses a **Local RAG (Retrieval-Augmented Generation)** architecture powered by **Mistral 7B** via **Ollama**.

### 🏗️ Architecture at a Glance
1.  **Ingestion**: Reads PDFs from the `input/` folder.
2.  **Indexing**: Chunks text and creates vector embeddings for fast search.
3.  **Extraction**: Identifies technical requirements and classifies them (Functional, Non-Functional, etc.).
4.  **Generation**: Writes technical design prose (HLD/LLD) based on extracted context.
5.  **Assembly**: Populates Markdown templates to create Final Docs (SRS, SDD, SyRS).
6.  **Coding**: Generates boilerplate code (FastAPI, SQL) based on the design.

---

## 📂 Project Structure & Key Files

| Component | Path | Description |
| :--- | :--- | :--- |
| **Orchestrator** | `main.py` | The main script that runs the entire pipeline. |
| **Pipeline Logic** | `modules/` | Contains specialized scripts for extraction and generation. |
| **Vector Engine** | `RAG_engine/` | Handles the PDF chunking and context retrieval. |
| **Input Folder** | `input/` | **[USER ACTION]** Place your technical spec PDFs here. |
| **Output Folder** | `output/` | Where generated MD files and JSON data are stored. |
| **Sample Code** | `output/sample_code/` | Contains the AI-generated backend, schema, and README. |
| **Templates** | `templates/` | The base Markdown structures used for document generation. |

---

## ⚡ How to Run the Workflow

### 1. Set Up Environment
Ensure **Ollama** is running locally and you have the `mistral` model:
```bash
ollama run mistral
```

### 2. Prepare Input
Copy your PDF specification into the `input/` directory:
```bash
cp your_specification.pdf /home/arun/ArchTech_AI/ArchTech_Integrated/input/
```

### 3. Execute Pipeline
Run the main script from your terminal:
```bash
python3 main.py
```

### 4. Review Results
Check the `output/` folder for:
- `SRS_Generated.md` (System Requirements Specification)
- `SDD_Generated.md` (System Design Document)
- `extracted_requirements.json` (Structured data)
- `output/sample_code/` (Ready-to-use boilerplate)

---

## 💡 Pro Tips
- **RAG Context**: The system uses 800-character chunks with overlap. This ensures that even if a requirement spans two pages, the AI maintains the context.
- **Custom Templates**: You can modify files in the `templates/` folder to change the look and feel of your final documents.
- **JSON Schema**: The `extracted_requirements.json` file is perfect for importing into other tools like Jira or Azure DevOps.

---
*Created for ArchTech AI Integrated Development*
