import os
import json
import logging
from modules.pdf_extractor import extract_images_from_pdf
from modules.rag_engine import RAGEngine
from modules.ai_generator import AIContentGenerator
from modules.ollama_extractor import OllamaReqExtractor
from modules.doc_generator import DocGenerator
from modules.mermaid_generator import MermaidGenerator
from modules.code_generator import CodeGenerator
from modules.project_matcher import ProjectMatcher

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def main():
    logger.info("🚀 Starting Advanced ArchTech AI Pipeline with RAG")

    pdf_path = "input/SCD_tech_spec.pdf"

    # Init RAG Engine
    rag = RAGEngine(model="phi3")        
    
    # Init AI Generator
    ai_gen = AIContentGenerator(model="phi3", rag_engine=rag)

    # 1. Extract Isolated Images from PDF
    logger.info("📸 Stage 1: Image Extraction")
    try:
        image_paths = extract_images_from_pdf(pdf_path)
        logger.info(f"Extracted {len(image_paths)} isolated images.")
    except Exception as e:
        logger.error(f"Failed to extract images: {e}")
        image_paths = []

    # 2. Extract Requirements & Identify Subsystems
    logger.info("🧠 Stage 2: RAG-based Requirement Extraction")
    extractor = OllamaReqExtractor(model="phi3", rag_engine=rag)
    try:
        # A) Extraction Requirements (Uses RAG internally)
        req_data = extractor.extract_requirements(pdf_path)
        
        subsystems = extractor.identify_subsystems(pdf_path)
        logger.info(f"Identified {len(subsystems)} subsystems.")
        
        # D) Match against Dataset for Adoption
        logger.info("🔍 Step 2.5: Searching Dataset for similar projects...")
        matcher = ProjectMatcher(dataset_path="Dataset", model="phi3")
        matcher.build_fingerprints()
        
        # Use first FR/SYR as primary search query (or subsystem names)
        search_query = " ".join([s['name'] for s in subsystems])
        matched_path, score = matcher.find_match(search_query)
        
        # C) Generate Mermaid for each subsystem
        mermaid_gen = MermaidGenerator(model="phi3")
        for sub in subsystems:
            mermaid_code = mermaid_gen.generate_diagram(sub['name'], sub['description'])
            sub['mermaid'] = mermaid_code

        # Save extracted data for debugging
        with open("output/extracted_requirements.json", "w") as f:
            json.dump(req_data, f, indent=4)
            
    except Exception as e:
        logger.error(f"Failed in Stage 2: {e}")
        req_data = {}
        subsystems = []

    # 3. Generate Technical Documents
    logger.info("📄 Stage 3: Document Generation (detailed AI content)")
    generator = DocGenerator(templates_dir="templates", output_dir="output", ai_gen=ai_gen)
    try:
        generated_files = generator.generate_documents(
            req_data, 
            image_paths=image_paths, 
            subsystem_data=subsystems,
            matched_project_path=matched_path
        )
        for f in generated_files:
            logger.info(f"Generated Document: {f}")
    except Exception as e:
        logger.error(f"Failed to generate documents: {e}")

    # 4. Generate Sample Code
    logger.info("💻 Stage 4: Sample Code Generation")
    code_gen = CodeGenerator(model="phi3", rag_engine=rag)
    try:
        # Create a summary for context
        req_summary = f"Functional: {len(req_data.get('functional', []))}, System: {len(req_data.get('system_requirements', []))}"
        code_files = code_gen.generate_sample_code(req_summary, subsystems)
        for f in code_files:
            logger.info(f"Generated Code: {f}")
    except Exception as e:
        logger.error(f"Failed to generate sample code: {e}")

    logger.info("✅ ArchTech Pipeline Completed Successfully!")

if __name__ == "__main__":
    main()
