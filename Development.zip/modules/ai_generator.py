import ollama
import logging
import re

logger = logging.getLogger(__name__)

class AIContentGenerator:
    def __init__(self, model="phi3", rag_engine=None):
        self.model = model
        self.rag_engine = rag_engine

    def generate_section_content(self, section_name, section_description, context=None):
        """
        Generates detailed technical paragraphs for a document section.
        """
        logger.info(f"Generating content for section: {section_name}")
        
        # If RAG engine is available and no context provided, retrieve it
        if self.rag_engine and not context:
            query = f"{section_name}: {section_description}"
            context = self.rag_engine.get_context(query, top_k=3)

        prompt = f"""
        You are an expert systems engineer and technical writer. 
        Write a detailed technical description for the following section of a technical document.
        
        Section Name: {section_name}
        Section Purpose: {section_description}

        Relevant Technical Context:
        \"\"\"
        {context if context else "No direct context available. Infer based on standard engineering practices for similar systems."}
        \"\"\"

        Requirements:
        1. Write in clear, professional, passive-voice technical English.
        2. Provide specific details, don't just use generalities.
        3. Break into multiple paragraphs if needed.
        4. Do NOT include section headers or introductory phrases like "Here is the content".
        5. Focus only on the content for this specific section.

        Detailed Content:
        """

        try:
            response = ollama.chat(model=self.model, messages=[
                {'role': 'system', 'content': 'You are a professional technical documentation expert.'},
                {'role': 'user', 'content': prompt}
            ])
            return response['message']['content'].strip()
        except Exception as e:
            logger.error(f"Error generating AI content for {section_name}: {e}")
            return f"Error generating content for {section_name}. Please refer to the source documentation."

    def generate_hld_lld(self, subsystem_name, subsystem_description):
        """
        Generates High Level and Low Level Design descriptions.
        """
        logger.info(f"Generating HLD/LLD for: {subsystem_name}")
        
        context = ""
        if self.rag_engine:
            context = self.rag_engine.get_context(f"{subsystem_name} architecture design", top_k=5)

        hld_prompt = f"""
        Subsystem: {subsystem_name}
        Description: {subsystem_description}
        Context: {context}

        Task: Write a High-Level Design (HLD) overview for this subsystem.
        Describe the architecture, major components, and how they interact.
        Output only the description paragraphs.
        """

        lld_prompt = f"""
        Subsystem: {subsystem_name}
        Description: {subsystem_description}
        Context: {context}

        Task: Write a Low-Level Design (LLD) overview for this subsystem.
        Describe internal logic, data structures, specific algorithms, and internal interfaces.
        Output only the description paragraphs.
        """

        try:
            hld_res = ollama.chat(model=self.model, messages=[{'role': 'user', 'content': hld_prompt}])
            lld_res = ollama.chat(model=self.model, messages=[{'role': 'user', 'content': lld_prompt}])
            return {
                "hld": hld_res['message']['content'].strip(),
                "lld": lld_res['message']['content'].strip()
            }
        except Exception as e:
            logger.error(f"Error generating HLD/LLD: {e}")
            return {"hld": "TBD", "lld": "TBD"}
