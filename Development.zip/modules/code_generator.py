import ollama
import logging
import os
import re

logger = logging.getLogger(__name__)

class CodeGenerator:
    def __init__(self, model="phi3", rag_engine=None):
        self.model = model
        self.rag_engine = rag_engine

    def generate_sample_code(self, requirements_summary, subsystems, output_dir="output/sample_code"):
        """
        Generates a modular code package based on requirements and identified subsystems.
        """
        logger.info("Generating sample code package...")
        os.makedirs(output_dir, exist_ok=True)

        system_context = f"Requirements Summary: {requirements_summary}\nSubsystems: {subsystems}"
        
        # 1. Generate Architecture Overview / README
        readme_prompt = f"""
        Generate a README.md for a software implementation of the following system:
        {system_context}
        Include:
        - Technology Stack (Python, FastAPI, React recommended)
        - Directory Structure
        - Setup Instructions
        """
        
        # 2. Generate Backend (FastAPI Example)
        backend_prompt = f"""
        Generate a Python FastAPI 'main.py' that implements the API layer for these subsystems:
        {subsystems}
        Include Pydantic models for data inputs and basic endpoint logic.
        """

        # 3. Generate Database Schema (SQL)
        db_prompt = f"""
        Generate a PostgreSQL schema (DDL) for the data entities required by:
        {system_context}
        """

        prompts = {
            "README.md": readme_prompt,
            "main.py": backend_prompt,
            "schema.sql": db_prompt
        }

        generated_files = []
        for filename, prompt in prompts.items():
            try:
                logger.info(f"Generating {filename}...")
                response = ollama.chat(model=self.model, messages=[
                    {'role': 'system', 'content': 'You are a senior full-stack software engineer. Output code only.'},
                    {'role': 'user', 'content': prompt}
                ])
                content = response['message']['content']
                
                # Cleanup code blocks
                if "```" in content:
                    # Extract content between first and last ```
                    parts = re.split(r'```(?:\w+)?', content)
                    if len(parts) >= 3:
                        content = parts[1].strip()
                
                file_path = os.path.join(output_dir, filename)
                with open(file_path, "w") as f:
                    f.write(content)
                generated_files.append(file_path)
            except Exception as e:
                logger.error(f"Error generating {filename}: {e}")

        logger.info(f"Generated {len(generated_files)} code artifacts.")
        return generated_files
