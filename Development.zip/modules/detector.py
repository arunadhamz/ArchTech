import cv2

def detect_components(img):
    contours, _ = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    components = []

    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)

        if w > 50 and h > 30:  # block size filter
            components.append({
                "type": "block",
                "bbox": (x, y, w, h)
            })

    return components