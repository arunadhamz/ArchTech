import os
import re
from .ai_generator import AIContentGenerator

class DocGenerator:
    def __init__(self, templates_dir="templates", output_dir="output", ai_gen=None):
        self.templates_dir = templates_dir
        self.output_dir = output_dir
        self.ai_gen = ai_gen

    def generate_documents(self, data, image_paths=None, subsystem_data=None, product_info=None, matched_project_path=None):
        self.matched_project_path = matched_project_path
        if not product_info:
            product_info = {
                "PRODUCT_NAME": "Integrated ArchTech System",
                "PRODUCT_ID": "AT-2026-X1",
                "VERSION": "1.0",
                "DATE": "2026-04-15"
            }

        templates = ["SyRS_Template.md", "HRS_Template.md", "SRS_Template.md", "SDD_Template.md"]
        
        generated_files = []

        for template_name in templates:
            template_path = os.path.join(self.templates_dir, template_name)
            if not os.path.exists(template_path):
                print(f"Warning: Template {template_path} not found.")
                continue

            with open(template_path, "r") as f:
                content = f.read()

            # Global replacements
            content = content.replace("<PRODUCT NAME>", product_info["PRODUCT_NAME"])
            content = content.replace("<PRODUCT ID>", product_info["PRODUCT_ID"])
            content = content.replace("<VERSION>", product_info["VERSION"])
            content = content.replace("<DATE>", product_info["DATE"])
            content = content.replace("<BID/PID/SID>", product_info["PRODUCT_ID"])

            # 1. Fill sections with AI if markers exist
            content = self._fill_ai_sections(content)

            # 2. Adopt content from matched project if available
            if self.matched_project_path:
                content = self._adopt_project_content(content, template_name)

            # 3. Specific sections based on document type
            if "SyRS" in template_name:
                content = self._populate_syrs(content, data, image_paths, subsystem_data)
            elif "HRS" in template_name:
                content = self._populate_hrs(content, data)
            elif "SRS" in template_name:
                content = self._populate_srs(content, data)
            elif "SDD" in template_name:
                content = self._populate_sdd(content, data, subsystem_data)

            output_name = template_name.replace("_Template", "_Generated")
            output_path = os.path.join(self.output_dir, output_name)
            
            with open(output_path, "w") as f:
                f.write(content)
            
            generated_files.append(output_path)

        return generated_files

    def _fill_ai_sections(self, content):
        """
        Scans for comments like <!-- ... --> and attempts to fill them using AI.
        """
        if not self.ai_gen:
            return content

        # Regex to find all HTML comments
        markers = re.findall(r'<!-- (.*?) -->', content)
        for marker in markers:
            # Simple heuristic: if it looks like a description placeholder
            if any(word in marker.lower() for word in ["describe", "overview", "explain", "provide", "summary", "identify", "analyze"]):
                ai_text = self.ai_gen.generate_section_content(marker, marker)
                content = content.replace(f"<!-- {marker} -->", ai_text)
        
        return content

    def _adopt_project_content(self, content, template_name):
        """
        Attempts to find matching document files in the matched project path and merge them.
        """
        doc_type = template_name.split('_')[0].upper() # e.g. SYRS, HRS, SRS, SDD
        adopt_path = os.path.join(self.matched_project_path, doc_type)
        
        if not os.path.exists(adopt_path):
            return content

        print(f"Adopting content from {adopt_path}...")
        
        # Look for .md files in the matched doc folder
        for f in os.listdir(adopt_path):
            if f.endswith(".md"):
                try:
                    with open(os.path.join(adopt_path, f), 'r') as file:
                        adopted_text = file.read()
                        # Simple merge strategy: if the adopted file has specific headers, 
                        # we can try to find them in our content. 
                        # For now, we'll append "Adopted Baseline" to sections or replace placeholders.
                        content += f"\n\n## Adopted Baseline from {f}\n\n{adopted_text}"
                except Exception as e:
                    print(f"Error adopting {f}: {e}")
        
        return content

    def _populate_syrs(self, content, data, image_paths, subsystem_data):
        # 1. System Requirements Table
        sy_rows = ""
        for i, req in enumerate(data.get("system_requirements", [])[:15]):
            sy_rows += f"| SR-{i+1:03d} | Requirement | {req} |\n"
        
        if "<!-- System Requirements Table -->" in content:
            content = content.replace("<!-- System Requirements Table -->", sy_rows.strip())
        
        # 2. Constraints Table
        c_rows = ""
        for i, req in enumerate(data.get("constraints", [])[:10]):
            c_rows += f"| C-{i+1:03d} | Constraint | {req} |\n"
        if "<!-- Constraints Table -->" in content:
            content = content.replace("<!-- Constraints Table -->", c_rows.strip())

        # 3. Diagrams
        if image_paths and len(image_paths) > 0:
            img_filename = os.path.basename(image_paths[0])
            img_markdown = f"![System Block Diagram](images/{img_filename})\n"
            content = content.replace("<!-- Insert system diagram showing major components -->", img_markdown)

        return content

    def _populate_srs(self, content, data):
        # 1. Functional Requirements
        fr_rows = ""
        for i, req in enumerate(data.get("functional", [])[:20]):
            fr_rows += f"| FR-{i+1:03d} | Functional | {req} |\n"
        if "<!-- Functional Requirements Table -->" in content:
            content = content.replace("<!-- Functional Requirements Table -->", fr_rows.strip())

        # 2. Non-Functional Requirements
        nfr_rows = ""
        for i, req in enumerate(data.get("non_functional", [])[:15]):
            nfr_rows += f"| NFR-{i+1:03d} | Attribute | {req} |\n"
        if "<!-- Non-Functional Requirements Table -->" in content:
            content = content.replace("<!-- Non-Functional Requirements Table -->", nfr_rows.strip())

        # 3. Software Requirements
        swr_rows = ""
        for i, req in enumerate(data.get("software_requirements", [])[:15]):
            swr_rows += f"| SWR-{i+1:03d} | Software | {req} |\n"
        if "<!-- Software Requirements Table -->" in content:
            content = content.replace("<!-- Software Requirements Table -->", swr_rows.strip())

        # 4. Assumptions & Dependencies
        ad_rows = ""
        for i, req in enumerate(data.get("assumptions", [])):
            ad_rows += f"| A-{i+1:03d} | Assumption | {req} | High |\n"
        for i, req in enumerate(data.get("dependencies", [])):
            ad_rows += f"| D-{i+1:03d} | Dependency | {req} | High |\n"
        if "<!-- Assumptions and Dependencies Table -->" in content:
            content = content.replace("<!-- Assumptions and Dependencies Table -->", ad_rows.strip())

        return content

    def _populate_sdd(self, content, data, subsystem_data):
        if subsystem_data and self.ai_gen:
            sdd_sections = ""
            for i, sub in enumerate(subsystem_data):
                sec_num = i + 1
                designs = self.ai_gen.generate_hld_lld(sub['name'], sub['description'])
                
                sdd_sections += f"### {sec_num}. {sub['name']} Design\n\n"
                sdd_sections += f"#### {sec_num}.1 High-Level Design (HLD)\n\n"
                sdd_sections += f"{designs['hld']}\n\n"
                sdd_sections += f"#### {sec_num}.2 Low-Level Design (LLD)\n\n"
                sdd_sections += f"{designs['lld']}\n\n"
                
                if sub.get('mermaid'):
                    sdd_sections += f"#### {sec_num}.3 Interface Diagram\n\n"
                    sdd_sections += f"{sub['mermaid']}\n\n"

            if "<!-- Subsystem Designs -->" in content:
                content = content.replace("<!-- Subsystem Designs -->", sdd_sections)
            elif "<!-- Insert subsystem architecture details here -->" in content:
                 content = content.replace("<!-- Insert subsystem architecture details here -->", sdd_sections)

        return content

    def _populate_hrs(self, content, data):
        return content
