def generate_json(nodes, edges):
    return {
        "document_type": "Hardware Block Diagram",
        "extracted_nodes": nodes,
        "extracted_edges": edges
    }