import ollama
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MermaidGenerator:
    def __init__(self, model="phi3"):
        self.model = model

    def generate_diagram(self, subsystem_name, description):
        """
        Generates a Mermaid graph TD for a specific subsystem.
        """
        logger.info(f"Generating Mermaid diagram for {subsystem_name}...")
        
        prompt = f"""
        Given the following subsystem name and description, generate a simple Mermaid flowchart (graph TD).
        The diagram should show the internal components or data flow of this subsystem.

        Subsystem: {subsystem_name}
        Description: {description}

        Output ONLY the Mermaid code block. Example:
        ```mermaid
        graph TD
          A[Input] --> B[Process]
          B --> C[Output]
        ```
        """

        try:
            response = ollama.chat(model=self.model, messages=[
                {'role': 'system', 'content': 'You are a technical illustrator. Output Mermaid code blocks only.'},
                {'role': 'user', 'content': prompt}
            ])
            
            content = response['message']['content']
            if "```mermaid" in content:
                # Keep the whole block including ```mermaid
                content = "```mermaid" + content.split("```mermaid")[1].split("```")[0].strip() + "\n```"
                return content
            elif "graph TD" in content:
                return f"```mermaid\n{content.strip()}\n```"
            else:
                return f"```mermaid\ngraph TD\n  Start(({subsystem_name})) --> Role[\"{description}\"]\n```"

        except Exception as e:
            logger.error(f"Error generating Mermaid for {subsystem_name}: {e}")
            return ""

if __name__ == "__main__":
    mg = MermaidGenerator()
    # print(mg.generate_diagram("Power Module", "Converts 28V DC to 5V and 3.3V for internal components."))
