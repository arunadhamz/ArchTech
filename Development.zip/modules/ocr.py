import pytesseract

def extract_text(img):
    text = pytesseract.image_to_string(img)

    lines = [line.strip() for line in text.split("\n") if line.strip()]
    return lines