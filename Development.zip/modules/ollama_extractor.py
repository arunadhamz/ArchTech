import ollama
import json
import logging
import re
from .pdf_reader import extract_pdf
from .sentence_splitter import split_sentences
from concurrent.futures import ThreadPoolExecutor, as_completed

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OllamaReqExtractor:
    def __init__(self, model="phi3", rag_engine=None):
        self.model = model
        self.rag_engine = rag_engine

    def extract_requirements(self, pdf_path):
        logger.info(f"Extracting text from {pdf_path}...")
        pages = extract_pdf(pdf_path)
        
        all_text = ""
        for _, text in pages:
            all_text += text + "\n"
        
        # If RAG engine is provided, index the document first
        if self.rag_engine:
            self.rag_engine.index_document(all_text)
        
        sentences = split_sentences(all_text)
        logger.info(f"Found {len(sentences)} sentences. Processing with {self.model} and structured categorization...")

        extracted_data = {
            "functional": [],
            "non_functional": [],
            "system_requirements": [],
            "software_requirements": [],
            "constraints": [],
            "assumptions": [],
            "dependencies": []
        }

        # Categories for the prompt
        categories_desc = """
        - FR: Functional Requirement (What the system should do)
        - NFR: Non-Functional Requirement (Performance, Security, etc.)
        - SYR: System Requirement (High-level system needs)
        - SWR: Software Requirement (Specific software logic/needs)
        - C: Constraint (Limitations like hardware, technology)
        - A: Assumption (Things assumed to be true)
        - D: Dependency (External systems or components needed)
        """
        block_size = 15

        # Process blocks in parallel
        def process_block(i, block):
            text_block = "\n".join(block)
            context = ""
            if self.rag_engine:
                context = self.rag_engine.get_context(text_block, top_k=2)

            prompt = f"""
            Categories:
            {categories_desc}

            Context from elsewhere in the document:
            {context}

            Analyze the following text block and extract structured requirements.
            Text Block:
            \"\"\"
            {text_block}
            \"\"\"

            Output ONLY a valid JSON object:
            {{
                "FR": [],
                "NFR": [],
                "SYR": [],
                "SWR": [],
                "C": [],
                "A": [],
                "D": []
            }}
            """
            try:
                response = ollama.chat(model=self.model, messages=[
                    {'role': 'system', 'content': 'You are a precise technical requirement analyst. Output JSON only.'},
                    {'role': 'user', 'content': prompt}
                ])
                content = response['message']['content']
                # Basic cleanup
                if "```" in content:
                    content = re.sub(r'```(?:json)?', '', content).strip()
                
                start_match = re.search(r'\{', content)
                end_match = re.search(r'\}', content[::-1])
                if start_match and end_match:
                    start_idx = start_match.start()
                    end_idx = len(content) - end_match.start()
                    content = content[start_idx:end_idx]
                
                return json.loads(content)
            except Exception as e:
                logger.error(f"Error processing block {i}: {e}")
                return None

        blocks = [sentences[i:i + block_size] for i in range(0, len(sentences), block_size)]
        
        logger.info(f"Starting parallel processing of {len(blocks)} blocks...")
        with ThreadPoolExecutor(max_workers=4) as executor:
            future_to_block = {executor.submit(process_block, i, b): i for i, b in enumerate(blocks)}
            for future in as_completed(future_to_block):
                block_data = future.result()
                if block_data:
                    extracted_data["functional"].extend(block_data.get("FR", []))
                    extracted_data["non_functional"].extend(block_data.get("NFR", []))
                    extracted_data["system_requirements"].extend(block_data.get("SYR", []))
                    extracted_data["software_requirements"].extend(block_data.get("SWR", []))
                    extracted_data["constraints"].extend(block_data.get("C", []))
                    extracted_data["assumptions"].extend(block_data.get("A", []))
                    extracted_data["dependencies"].extend(block_data.get("D", []))

        return extracted_data

    def identify_subsystems(self, pdf_path):
        """
        Identify major hardware modules or software subsystems.
        """
        logger.info("Identifying subsystems...")
        pages = extract_pdf(pdf_path)
        all_text = "\n".join([text for _, text in pages])
        
        prompt = """
        Identify the major hardware modules or software subsystems described in the technical text below.
        
        Text:
        \"\"\"
        {text}
        \"\"\"

        Output ONLY a valid JSON list:
        [
            {"name": "Subsystem Name", "description": "High level description"}
        ]
        """
        
        try:
            # Only use first 5000 chars for identification to save context window
            response = ollama.chat(model=self.model, messages=[
                {'role': 'system', 'content': 'You are a system architect. Output JSON list only.'},
                {'role': 'user', 'content': prompt.format(text=all_text[:5000])}
            ])
            
            content = response['message']['content'].strip()
            if "```" in content:
                content = re.sub(r'```(?:json)?', '', content).strip()
            
            start_idx = content.find('[')
            end_idx = content.rfind(']')
            if start_idx != -1 and end_idx != -1:
                content = content[start_idx:end_idx+1]
                
            return json.loads(content)
        except Exception as e:
            logger.error(f"Error identifying subsystems: {e}")
            return []

