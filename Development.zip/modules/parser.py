def build_graph(detections, text_data):
    nodes = []
    edges = []

    # Assign nodes
    for i, det in enumerate(detections):
        nodes.append({
            "node_id": f"ND-{i+1:02}",
            "name": text_data[i] if i < len(text_data) else f"Block_{i}",
            "type": "Unknown"
        })

    # Simple sequential edge assumption (can improve)
    for i in range(len(nodes)-1):
        edges.append({
            "source": nodes[i]["node_id"],
            "target": nodes[i+1]["node_id"],
            "type": "Signal Flow"
        })

    return nodes, edges