import os
import subprocess
import glob

def extract_images_from_pdf(pdf_path, output_dir="output/images"):
    """
    Extracts only the embedded image objects from the PDF using pdfimages.
    This helps in getting the 'diagram alone' without page text.
    """
    os.makedirs(output_dir, exist_ok=True)
    
    # pdfimages [pdf-file] [image-root]
    # -png flag ensures we get PNG format
    image_root = os.path.join(output_dir, "img")
    
    cmd = ["pdfimages", "-png", pdf_path, image_root]
    
    try:
        subprocess.run(cmd, check=True)
        # Find all extracted images
        extracted_images = glob.glob(f"{image_root}-*.png")
        # Sort them by name
        extracted_images.sort()
        return extracted_images
    except subprocess.CalledProcessError as e:
        print(f"Error extracting images with pdfimages: {e}")
        return []

if __name__ == "__main__":
    pass
    # Test
    # images = extract_images_from_pdf("../input/SCD_tech_spec.pdf")
    # print(images)