import os
import logging
import json
from .rag_engine import RAGEngine

logger = logging.getLogger(__name__)

class ProjectMatcher:
    def __init__(self, dataset_path="Dataset", model="phi3"):
        self.dataset_path = dataset_path
        self.model = model
        self.rag = RAGEngine(model=model)
        self.project_fingerprints = {}

    def build_fingerprints(self):
        """
        Scans the dataset and builds a searchable index of projects.
        """
        logger.info(f"Scanning dataset folders in {self.dataset_path}...")
        if not os.path.exists(self.dataset_path):
            logger.warning(f"Dataset path {self.dataset_path} not found.")
            return

        for project_dir in os.listdir(self.dataset_path):
            project_path = os.path.join(self.dataset_path, project_dir)
            if not os.path.isdir(project_path):
                continue
                
            # Try to find a fingerprint (e.g., from SYRS or a README)
            fingerprint_text = self._extract_project_context(project_path)
            if fingerprint_text:
                self.project_fingerprints[project_dir] = fingerprint_text
                logger.info(f"Indexed project: {project_dir}")
            else:
                logger.info(f"Project folder {project_dir} is empty or contains no descriptive data.")

    def _extract_project_context(self, project_path):
        """
        Tries to extract a descriptive string for a project by lookng into its subfolders.
        """
        context = []
        # Check for any .md or .txt files in SYRS or main folder
        search_dirs = [project_path, os.path.join(project_path, "SYRS")]
        
        for d in search_dirs:
            if os.path.exists(d):
                for f in os.listdir(d):
                    if f.endswith((".md", ".txt")):
                        try:
                            with open(os.path.join(d, f), 'r') as file:
                                # Take the first 1000 chars as a summary
                                context.append(file.read(1000))
                        except:
                            continue
        
        return " ".join(context).strip()

    def find_match(self, current_requirement_text, threshold=0.6):
        """
        Matches current requirements against the project dataset using semantic similarity.
        """
        if not self.project_fingerprints:
            logger.warning("No projects indexed in dataset. Matching skipped.")
            return None, 0.0

        best_match = None
        highest_score = 0.0

        logger.info("Comparing current project against dataset...")
        
        for project_name, context in self.project_fingerprints.items():
            # Using simple keyword overlap or RAG similarity if implemented
            # For now, let's use a simple word set overlap as it's faster for local
            score = self._calculate_similarity(current_requirement_text, context)
            
            if score > highest_score:
                highest_score = score
                best_match = project_name

        if highest_score >= threshold:
            logger.info(f"Found best match: {best_match} (Score: {highest_score:.2f})")
            return os.path.join(self.dataset_path, best_match), highest_score
        
        logger.info("No high-confidence match found in dataset.")
        return None, highest_score

    def _calculate_similarity(self, text1, text2):
        """
        Simple Jaccard similarity implementation for local speed. 
        Could be upgraded to embedding-based similarity later.
        """
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
            
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        
        return len(intersection) / len(union)
