import logging
import os
from pathlib import Path
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.utils import embedding_functions

logger = logging.getLogger(__name__)

class RAGEngine:
    def __init__(self, model="phi3", db_path="RAG_engine/backend/chroma_db", model_path="RAG_engine/models/embedding"):
        """
        New RAG Engine using SentenceTransformers and ChromaDB.
        Standardized with the ArchTech RAG system.
        """
        self.model_path = model_path
        self.db_path = db_path
        
        # Load the model locally
        logger.info(f"Loading embedding model from {self.model_path}...")
        try:
            self.model = SentenceTransformer(self.model_path)
            self.embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(
                model_name=self.model_path
            )
        except Exception as e:
            logger.error(f"Failed to load sentence transformer: {e}")
            self.model = None

        # Initialize ChromaDB
        logger.info(f"Initializing ChromaDB at {self.db_path}...")
        try:
            self.chroma_client = chromadb.PersistentClient(path=self.db_path)
            self.collection = self.chroma_client.get_or_create_collection(
                name="requirements",
                embedding_function=self.embedding_function
            )
        except Exception as e:
            logger.error(f"Failed to initialize ChromaDB: {e}")
            self.collection = None

    def index_document(self, text, metadata=None):
        """
        Chunks and indexes a document. (Simplified wrapper)
        """
        if not self.collection:
            return
        
        # In this integrated version, indexing is usually handled by the backend /upload 
        # but we keep this for compatibility with the old pipeline if needed.
        # For now, we assume the requirements are already indexed or provide a simple chunking.
        chunks = self.chunk_text(text)
        ids = [f"chunk-{os.urandom(4).hex()}" for _ in chunks]
        self.collection.add(documents=chunks, ids=ids)
        logger.info(f"Indexed {len(chunks)} chunks.")

    def chunk_text(self, text, chunk_size=800, overlap=150):
        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]
            chunks.append(chunk)
            start += (chunk_size - overlap)
        return chunks

    def retrieve(self, query, top_k=5):
        """
        Retrieves the most relevant chunks for a given query using ChromaDB.
        """
        if not self.collection:
            logger.warning("No collection initialized. Search skipped.")
            return []

        try:
            results = self.collection.query(
                query_texts=[query],
                n_results=top_k
            )
            return results['documents'][0] if results['documents'] else []
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return []

    def get_context(self, query, top_k=5):
        """
        Returns a joined string of relevant chunks.
        """
        relevant_chunks = self.retrieve(query, top_k=top_k)
        return "\n\n---\n\n".join(relevant_chunks)
