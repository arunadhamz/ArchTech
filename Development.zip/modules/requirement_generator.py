from transformers import pipeline

# Global generator instance for persistence across calls
_generator = None

def get_generator():
    """Lazy-load the generative model only when needed."""
    global _generator
    if _generator is None:
        # Load google/flan-t5-base (approx 990MB)
        # It will download on the first run if not cached.
        _generator = pipeline("text2text-generation", model="google/flan-t5-base")
    return _generator

def generate_requirement(sentence):
    s = sentence.strip()
    if not s or len(s) < 10:
        return None

    s_lower = s.lower()

    # Pass through if it already looks like a requirement
    if any(k in s_lower for k in ["shall ", "must ", "should "]):
        return s

    # Use the local AI model to transform the sentence
    try:
        generator = get_generator()
        # Simpler, more direct prompt for Flan-T5
        prompt = f"Convert this technical specification into a formal requirement starting with 'The system shall': {s}"
        
        output = generator(prompt, max_new_tokens=128)[0]['generated_text']
        
        # Filter out trivial or incomplete outputs
        clean_output = output.strip()
        if clean_output.lower() in ["the system shall:", "the system shall", "none"]:
            return None
            
        if len(clean_output) < 15:
            return None

        return clean_output
    except Exception as e:
        print(f"AI Generation Error: {e}")
        return None


