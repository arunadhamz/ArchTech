from collections import defaultdict

def write_requirements(requirements):
    sections = defaultdict(list)

    for r in requirements:
        sections[r["type"]].append(r["text"])

    output = []
    for req_type, (title, prefix) in {
        "Functional": ("Functional Requirements", "FR"),
        "NonFunctional": ("Non-Functional Requirements", "NFR"),
        "Interface": ("Interface Requirements", "IR"),
        "Constraint": ("Constraint Requirements", "CR"),
        "Regulatory": ("Regulatory Requirements", "RR"),
    }.items():

        if req_type not in sections:
            continue

        output.append(f"\n{title}\n")
        for i, text in enumerate(sections[req_type], 1):
            output.append(f"{prefix}-{i:02d}: {text}")

    return "\n".join(output)

