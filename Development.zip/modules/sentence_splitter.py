def split_sentences(text):
    lines = text.split("\n")
    sentences = []

    for line in lines:
        line = line.strip()
        if len(line) > 25:
            sentences.append(line)

    return sentences

