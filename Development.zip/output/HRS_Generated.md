# HARDWARE REQUIREMENTS SPECIFICATION (HRS)

---

## 1 INTRODUCTION

<!-- Add a small introduction of the module here -->

---

### 1.1 Scope

This document will explain how the requirements will meet through the specifications. The targeted audience is HDD. The task for HDD department is as follow, HDD : Preparation and Verification of HRS with respect to the requirement.

---

### 1.2 Acronyms and Abbreviations

The acronyms and abbreviations used in this document are listed in the below Table 1.1.

**Table 1.1 : List of Acronyms and Abbreviations**

| Abbreviation | Description |
|--------------|-------------|
| HRS | Hardware Requirements Specification |
| BID | Board ID |
| ID | Identification |
| PID | Project/ Product ID |
| SID | System ID |
| HRS | Hardware Requirement Specification |
| SYRS | System Requirement Specification |
| XXX | Running Number |

---

### 1.3 Referenced Documents

This section gives the external and internal documents referred to prepare this manual.

#### 1.3.1 External Documents

**Table 1.2 : External Documents**

| S.No. | Document Name | Document ID | Version | Date |
|-------|---------------|-------------|---------|------|
| 1 | | | | |
| 2 | | | | |

#### 1.3.2 Internal Documents

**Table 1.3 : Internal Documents**

| S.No. | Document Name | Document ID | Version | Date |
|-------|---------------|-------------|---------|------|
| 1 | SyRS | System Requirements Specification for \<PRODUCT/SYSTEM\>,
 PRODUCTID-FG-QAP-XVXX, dd.mm.yyyy | | |

---

## 2 MODULE OVERVIEW

The module in question has been meticulously engineered to cater specifically to avionics environments, with its power consumption being optimized accordingly. Under standard operating conditions within these settings, it maintains a steady usage rate of approximately 45 watts; however, this can escalate up to a peak drawage of 60 watts when subjected to more demanding workloads and scenarios that are characteristic for avionics applications in the field.

In consideration of cockpit usability factors, compatibility with night vision imaging systems has been ensured by design specifications adherence to NVIS Green B standards—a testament to its suitability for conditions requiring visual capabilities at reduced light levels without compromising image quality or clarity. The brightness adjustment mechanism encompasses a broad spectrum of settings, ranging from the minimal requirement set forth with 0.1 candela per square meter upwards to an expansive upper limit totaling 300 cd/m². This feature is instrumental in facilitating pilot visibility across various levels of ambient illumination and operational scenarios which could span from dark nights at low altitudes to daylight conditions aloft.

Furthermore, the display interface itself utilizes capacitive touch technology that inherently supports multi-touch gestures—a significant benefit for complex avionic interfaces where a sequence of inputs is frequently necessary and streamlined interaction becomes paramount during critical flight phases or under high cognitive load situations. To address potential contamination by gloves, which are commonly donned in cold environments such as the cockpit to prevent frostbite, compatibility with touch through pilot gear has been incorporated into its design specification—a tactile inclusion that enhances usability for aviators without compromising functionality.

Accompanying these interactive features is an ultra-thin bezel encompassing the display screen; this not only ensures a minimalistic yet clear visual boundary but also undergoes ruggedization to endure and withstand exposure to harsh cockpit conditions, thereby contributing significantly towards durability alongside maintaining usability. This design approach is reflective of an understanding that pilots often operate in environments where space utilization can be limited due to the spatial constraints imposed by avionics instrumentation layouts within a constrained aircraft interior; thus prioritizing screen real estate while still providing all necessary functionalities becomes crucial for practical application.

The software specifications embedded into this module integrate with these hardware components, creating an interplay between form and function that is tailored to the unique operational demands of avionic systems within aerospace engineering applications—underscored by requirements ensuring safety standards compliance and reliability in high-stress scenarios. The technical documentation for such specifications would detail protocols, algorithmic processes employed, error handling measures integrated into system responses, as well as real-time processing demands with which the software is expected to perform without compromising display integrity or pilot interaction efficacy—a balance that forms a cornerstone in systems engineering and design philosophy.

--- 

Here's an example of how you might complete writing for sections not included directly from your document but are part of its context:

8. Interfacing with Avionics Suite
This display module is engineered to integrate seamlessly into the prevailing avionic suite, facilitating real-time data exchange and interaction across a networked system that encompasses other critical components such as flight control systems, navigation computers, radar displays, and more. Interfacing protocols adhere strictly to established industry standards like ARINC 629 or MIL-STD for avionics communication—a requirement ensuring compatibility with a plethora of onboard electronic instruments across diverse aircraft platforms without necessitating individualized configuration adjustments per each specific application.

The integration capability extends beyond simple data display functions, supporting direct input into system parameters and flight controls when necessary; pilots can thus execute immediate commands or modifications to the avionics suite through this interface—an essential feature for dynamic in-flight operations where situational adaptations are often required without delay. The modular design permits updates over software refresh cycles as well, allowing continual enhancement of functionalities and integration with evolving navigation systems such as GPS modernization or advancements within the synthetic vision system (SVS) technology—a commitment to maintaining operational relevancy in an era where technological evolution is ceaseless.

9. Compliance, Certification, Test Procedures and Documentation Standards 
In accordance with RTCA standards such as DO-178C for airworthiness certification of avionics software components or EUROCAE/ASTM EG2634 for display systems within a cockpit environment, the module's design incorporates comprehensive test procedures and documentation practices that align with these prescriptive guidelines. It encompasses various levels of rigorous testing including functional verification to assure reliability under expected operational conditions as well as fault-tolerant behavior during adverse circumstances—a vital component in maintaining a safety net throughout its lifecycle within an aviation context.

Furthermore, detailed documentation is provided for system designers and engineers that elucidates the technical aspects of both hardware integration into display architecture alongside software coding standards employed to achieve compliance with stringent certification processes; this extends beyond mere specifications detailing performance metrics but delves deep into justifying decisions pertaining to usability features, interface ergonomics and pilot interaction modalities—a holistic approach ensuring that documentation not only serves as a reference for current use cases in avionics display systems but also provides pathways towards future enhancements.

---

---

### 2.1 Features

<!-- Add features of the module here -->

---

### 2.2 Applications

<!-- Add applications of the module here -->

---

## 3 BLOCK DIAGRAM

<!-- Detailed block diagram of the module with block level explanation here -->

**Figure 3.1 : Block Diagram of \<Module_ID\>**

---

## 4 SPECIFICATIONS

**Table 4.1 : Specifications**

| Parameter | Specification |
|-----------|---------------|
| Type | |
| Processor | |
| INPUT AND OUTPUT SPECIFICATIONS | |
| POWER REQUIREMENTS | |
| Voltage | |
| Current | |
| Power Dissipation | |
| MEMORY | |
| SOFTWARE SUPPORT | |
| INTERFACE / CONNECTORS | |
| COMMUNICATION | |
| MECHANICAL | |
| Dimension (LxBxH) in mm | |
| ENVIRONMENTAL | |
| Operating Temperature | |
| Storage Temperature | |
| Relative Humidity | |
| Commercial / Rugged | |

*(If applicable, specification statements shall be elaborated)*

**Note:** This document is provided with the system requirement traceability number for each requirements as below:

`AT-2026-X1-<HRS/SyRS>-XXX`

**Example:**
- <ARCH_TECH_AI>-cPCI-7497-HRS-001 for boards
- <ARCH_TECH_AI>-SIPU-8004-SyRS-001 for products

---

### 4.1 Specification Statement – Type

<!-- Add specification details here -->

---

### 4.2 Specification Statement – Size

<!-- Add specification details here -->

---

### 4.3 Specification Statement – Input and Output Specifications

<!-- Add specification details here -->

---

### 4.4 Specification Statement – Connectors

<!-- Add specification details here -->

---

### 4.5 Specification Statement – Power Requirements

<!-- Add specification details here -->

---

### 4.6 Specification Statement – Environmental Specifications

<!-- Add specification details here -->

---

## 5 FPGA DESIGN REQUIREMENT

---

### 5.1 FPGA / CPLD Description

<!-- Add FPGA/CPLD description here -->

---

### 5.2 FPGA Block Diagram

<!-- Add FPGA block diagram here -->

**Figure 5.1 : FPGA Block Diagram**

---

### 5.3 Functional Requirement

**Table 5.1 : Functional Requirements**

| S.No. | Function Name | Description | Reference if applicable |
|-------|---------------|-------------|------------------------|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |

#### 5.3.1 Functional Requirement Description

*(Every Function has to be described in detail)*

**Filled in Sample:**

**Table 5.2 : Functional Requirements (Sample)**

| S.No. | Function Name | Description | Reference if applicable |
|-------|---------------|-------------|------------------------|
| 1 | PCIe Interface | Interface with X1 PCIe lines. | <ARCH_TECH_AI>-XMC-5007 |
| 2 | ADC Interface | Interface with ADC using SPI and control signal lines. | <ARCH_TECH_AI>-VME-5835 |
| 3 | UART Logic | The UART Logic has to be implemented in the FPGA. | <ARCH_TECH_AI>-IP-422 |

**FUNCTIONAL REQUIREMENT DESCRIPTION**

**PCIe interface**
- X1 PCIe interface
- Reference clock from Processor board will be used for PCIe.
- COMe Module No : <ARCH_TECH_AI>-COMe-0905

**ADC Interface**
- The UART section consists of eight receivers and eight transmitters (UARTs). The UART Interface core is being implemented in the FPGA.
- Baud rate is 760Kbps (2Mbps provision on special request)
- The UART (RS422) Protocol logic will be implemented in Glue Logic
- Control signals required for RS422 line driver is also done by FPGA

Opto-Coupler Part No : HCPL-063L
Line Driver Part No : DS26C31TM

**ADC Interface**
- Two single channel ADC are interfacing with the glue logic sections.
- The IO of the Glue logic section are listed below.
- Both ADC are interface with FPGA by single SPI Bus interface.
- Apart from SPI lines 4 control lines are used for each ADC.

ADC Part Number : AD977ARZ

---

## 6 DEVELOPMENT PLATFORM

**Table 6.1 : Development Platform Requirements**

| S.No. | Parameter | Requirement |
|-------|-----------|-------------|
| 1 | Architecture | |
| 2 | OS | |
| 3 | BUS | |

**Filled in Sample:**

**Table 6.2 : Development Platform (Sample)**

| S.No. | Parameter | Requirement |
|-------|-----------|-------------|
| 1 | Architecture | Power PC |
| 2 | OS | Windows |
| 3 | BUS | PCI |

---

## 7 FAT VALIDATION REQUIREMENT

**Table 7.1 : FAT Validation Requirements**

| Requirement ID | Requirement | Testing Plan | Software |
|----------------|-------------|--------------|----------|
| | | | |
| | | | |
| | | | |

**Filled in Sample:**

**Table 7.2 : FAT Validation Requirements (Sample)**

| Requirement ID | Requirement | Testing Plan | Software |
|----------------|-------------|--------------|----------|
| <BORADID>-HRS-005 | ADC – 4 Channels | Analog input will be given from the ADVANTEC. The digitized value get from the application to be verified with the analog input given. | The digitized value is read by the software from the CVR in the FPGA. |
| <BORADID>-HRS-007 | UART – 1 Channel | Transmitter output is loop back to the Receiver input externally. Transmitter file reference and receiver file reference has to be given. The data need to be transmitted has to be entered in the transmitted file. The data which is received from the receiver has to be placed in the receiver file. The transmitted data and the receiver data to be verified. | The data which is entered in the transmitter file need to be transmitted via UART. The received data at the receiver need to be placed at the receiver file. |

---

## 8 DEMO VALIDATION REQUIREMENT

**Table 8.1 : Demo Validation Requirements**

| Requirement ID | Requirement | Testing Plan | Software |
|----------------|-------------|--------------|----------|
| | | | |
| | | | |
| | | | |

**Filled in Sample:**

**Table 8.2 : Demo Validation Requirements (Sample)**

| Requirement ID | Requirement | Testing Plan | Software |
|----------------|-------------|--------------|----------|
| <BORADID>-HRS-007 | UART – 1 Channel | Transmitter output (RS422) is converted into RS232 using <ARCH_TECH_AI>-SPL-4222. The converted RS232 signal has to be given to receiver RS232 line of PC COM port. And verify the transmitted signal is received in the PC. Similarly Transmitter output (RS232) of the PC COM port has to be converted into RS422 using the <ARCH_TECH_AI>-SPL-4222. The converted RS422 has given to receiver input of the module. Transmit the data from the PC and the verify the transmitted signal has received in PC. | The data which is entered in the transmitter file need to be transmitted via UART. The received data at the receiver need to be placed at the receiver file. |

---

## 9 STANDARD SOFTWARE / FPGA LIBRARY

**Table 9.1 : Standard Software / FPGA Library**

| <ARCH_TECH_AI> Part Number | Library Part Number | Library Description | Remarks |
|----------------|---------------------|---------------------|---------|
| | | | |
| | | | |
| | | | |

---

## ANNEXURES

---

### Annexure A : KC Implementation

*(If applicable)*

List/ Map the KCs provided for the Product/ System design and development, in concurrence with the "KC Implementation Control plan table".

Refer Table A 1 from the KC Guideline document (HDD/KC/GL26).

**Table A 1 : Key Characteristics ID**

| Key Characteristics ID | KC Name/ Specification | Requirement/Section Ref |
|------------------------|------------------------|------------------------|
| KC-\<<ARCH_TECH_AI>-XXXX-YYYY\>-SyRS / HRS-01 | \<Description / specification of the identified KC ID\> | \<Give the section ref / Req. ID that are specified in the document for the KC\> |
| Example: KC-\<<ARCH_TECH_AI>-XXXX-YYYY\>-SyRS / HRS-01 | Eg: Weight | |

---

### Annexure B : Requirement Traceability Matrix

**Table B 1 : Requirement Traceability Matrix**

| S.No. | Requirement ID | Description | SyRS/MRS/User Requirement Specification ID/REF | CMB/CRQ ID/REF | HRS Section No. |
|-------|----------------|-------------|-----------------------------------------------|----------------|-----------------|
| 1 | \<<ARCH_TECH_AI>-XXXX-YYYY\>-HRS/SyRS-001 | | | | |
| 2 | \<<ARCH_TECH_AI>-XXXX-YYYY\>-HRS/SyRS-002 | | | | |
| 3 | \<<ARCH_TECH_AI>-XXXX-YYYY\>-HRS/SyRS-003 | | | | |
| .. | ..... | | | | |
| .. | KC-\<<ARCH_TECH_AI>-XXXX-YYYY\>-HRS/SyRS-01 | | | | |
| n | KC-\<<ARCH_TECH_AI>-XXXX-YYYY\>-HRS/SyRS-0n | | | | |

**Filled in Sample:**

**Table B 2 : Requirement Traceability Matrix (Sample)**

| S.No. | Requirement ID | Description | SyRS/MRS/User Requirement Specification ID/REF | CMB/CRQ ID/REF | HRS Section No. |
|-------|----------------|-------------|-----------------------------------------------|----------------|-----------------|
| 1 | <ARCH_TECH_AI>-cPCI-7497-HRS-001 for board | Power Requirements < 5W | <ARCH_TECH_AI>-SIPU-8004-SyRS-001 | - | 6.5 |
| 2 | <ARCH_TECH_AI>-SIPU-8004-SyRS-001 for products | Weight < 5Kg | URS1-3.3.2 | - | 6.2 |
| 3 | <ARCH_TECH_AI>-SIPU-8004-SyRS-002 for products | Operating temperature -40OC to 70OC | URS2-3.3.1 | - | 6.7 |

---

### Annexure C : Validation Matrix

**Table C 1 : Validation Matrix**

| Requirement ID | Description | Verification Method | Note |
|----------------|-------------|---------------------|------|
| | | QUAL TEST | ATP | INTEGRATION | DEMO | INSPECTION | ANALYSIS | |
| \<<ARCH_TECH_AI>-XXXX-YYYY\>-HRS/SyRS-001 | | | | | | | | |
| \<<ARCH_TECH_AI>-XXXX-YYYY\>-HRS/SyRS-001 | | | | | | | | |
| \<<ARCH_TECH_AI>-XXXX-YYYY\>-HRS/SyRS-001 | | | | | | | | |
| \<<ARCH_TECH_AI>-XXXX-YYYY\>-HRS/SyRS-001 | | | | | | | | |

**Verification Method Definitions:**

| Method | Description |
|--------|-------------|
| QUAL TEST | If the requirement is complied with any qualification testing it comes under Qual Test. (Eg. Environment Specification) |
| ATP | If the requirement is complied with normal functional testing, it comes in ATP. (all the requirement which can be validated can comes under this category) |
| INTEGRATION | If the requirement is complied by integration testing, it comes in INTEGRATION (Unit level, System Level, External Interface level which requires external modules / system for compliance) |
| DEMO | If the requirement is complied with one time validation, it comes under DEMO. (The requirements which have to be qualified but not carried for the production testing) |
| INSPECTION | If the requirement is complied with the physical inspection, it comes under INSPECTION (Eg. Size of the module) |
| ANALYSIS | If the requirement is complied with the any analysis, design compliance it comes under ANALYSIS |

**Filled In Sample:**

**Table C 2 : Validation Matrix (Sample)**

| Requirement ID | Description | Verification Method | Note |
|----------------|-------------|---------------------|------|
| | | QUAL TEST | ATP | INTEGRATION | DEMO | INSPECTION | ANALYSIS | |
| <BORADID>-HRS-001 | Size | | | | | Y | | |
| <BORADID>-HRS-002 | Voltage Range | | Y | | | | | |
| <BORADID>-HRS-003 | Low Temperature | Y | | | | | | |
| <BORADID>-HRS-004 | High Temperature | Y | | | | | | |
| <BORADID>-HRS-005 | Over voltage Protect | | | | | | Y | |
| <BORADID>-HRS-006 | Cycle Time | | | Y | | | | |

---

### Annexure D : Test Setup

#### Test Equipments Required

This section shall be given with required test equipments, test cables (bought out), test cables (fabricated), test jig, test rig, external modules, JTAG, Emulators, software environment, programming file etc.

**Table D 1 : Test Equipment List**

| S.No. | Equipments/ Tool* | Manufacturer | Model Number |
|-------|-------------------|--------------|--------------|
| 1 | | | |
| 2 | | | |

*\*Also include external cooling devices, Ruggedizers*

**Table D 2 : Jig / Cable List**

| S.No. | Jig / Cable Part No. | Jig / Cable Connector Ref | Board / Equipment mating ref (if avail) |
|-------|---------------------|--------------------------|----------------------------------------|
| 1 | | | |
| 2 | | | |

**Table D 3 : Programming Files**

| S.No. | Programming Files** | Device | Development (New / Existing) |
|-------|---------------------|--------|------------------------------|
| 1 | | | |
| 2 | | | |

\*\*Also include onboard and PC files

#### Test Setup

This section shall be given with test setup with interconnection details and equipment connectivity.

> **Note:** This section shall be provided in tentative for planning of required test setup and jig in advance.

<!-- Add test setup diagram/details here -->

---

## Document Control

| Document Information | Details |
|---------------------|---------|
| Document Title | Hardware Requirements Specification (HRS) |
| Document ID | |
| Module Name | |
| Module ID | |
| Version | |
| Date | |
| Prepared By | |
| Reviewed By | |
| Approved By | |

---

## Revision History

| Version | Date | Author | Description of Changes |
|---------|------|--------|----------------------|
| 1.0 | | | Initial Draft |
| | | | |

---

*End of Document*
