# SYSTEM REQUIREMENTS SPECIFICATION (SyRS)

---

## 1 INTRODUCTION

<!-- Add a small introduction of the product/system here -->

---

### 1.1 Scope

<!-- Add scope of the document here -->

This document will explain how the requirements will meet through the specifications. The targeted audience is HDD. The task for HDD department is as follow, HDD : Preparation and Verification of SyRS with respect to the requirement.

---

### 1.2 Referenced Documents

The documents referred to prepare the System Requirements Specification (SyRS) are listed in the below tables.

#### 1.2.1 External Documents

**Table 1.1 : External Referenced Documents**

| S.No. | Document Name | Document ID | Version | Date |
|-------|---------------|-------------|---------|------|
| 1 | | | | |
| 2 | | | | |

#### 1.2.2 Internal Documents

**Table 1.2 : Internal Referenced Documents**

| S.No. | Document Name | Document ID | Version | Date |
|-------|---------------|-------------|---------|------|
| 1 | SyRS | System Requirements Specification for \<PRODUCT NAME\>,
, PRODUCTID-FG-QAP-XVXX | Month dd, yyyy |

---

### 1.3 Acronyms and Abbreviations

The acronyms and abbreviations used in this document are given in the below table.

**Table 1.3 : List of Abbreviations and Acronyms**

| Abbreviation | Description |
|--------------|-------------|
| BID | Board ID |
| PID | Project/ Product ID |
| SID | System ID |
| SYRS | System Requirement Specification |
| XXX | Running Number |

---

## 2 SYSTEM OVERVIEW

The display system has been designed with a focus on cockpit usability, ensuring that pilots can interact effectively with their instruments and displays during flight operations. It incorporates compatibility with night vision imaging systems to facilitate the use of these devices in low-light conditions frequently encountered by aviators at high altitudes or latitudes where natural light is limited. The display adheres strictly to NVIS Green B standards, an industry benchmark for visibility and brightness under such circumstances.

The adjustable illumination function permits users a range of 0.1 candela per square meter as the minimum setting up to reaching full intensity at 300 cd/m². This feature ensures that pilots can maintain clear vision in various lighting conditions, from near-total darkness with night goggles or helmet cameras to overcast daylight scenarios when cockpit windows might not provide sufficient illumination.

A capacitive touch interface is provided for ease of operation and reliability within the aviation environment's high humidity levels that could interfere with resistive displays, potentially causing malfunctions or false readings during critical flight phases such as landing approaches in adverse weather conditions. The multi-touch gesture support allows complex input manipulations without physical contact to maintain a sterile interface and reduce the risk of contamination within sensitive avionics components.

Furthermore, glove compatibility is included for situations where pilots may require them—such as when dealing with ice or snow on hand controls in subzero temperatures typical during high-latitude operations; this feature ensures uninterrupted operation without the need to remove protective gear which could present safety risks.

The display's bezel has been made ultra-thin, a design choice that optimizes screen real estate by maximizing visible display area while also being ruggedized—an essential characteristic given frequent vibrations and potential impact from avionics components or environmental stresses within the cockpit. This contributes to an overall balance between durability required for continuous operation in challenging environments, such as those encountered during aerial firefighting missions at high altitudes where robustness is paramount alongside user-friendly features like touch interfaces and display brightness adjustments that cater specifically to the needs of aviators.

The software specifications dictate a system power consumption profile designed for optimal performance within an avionics energy budget, with operational wattage not exceeding 45 W while maintaining high responsiveness across all modes and functions; this is crucial in extended flight operations where efficient resource utilization can contribute to longer mission endurance. The peak load draw of up to 60 watts provides a buffer for situations requiring maximum computational resources, such as during complex sensor data processing or when executing advanced avionics tasks that demand substantial systemic energy without compromising the reliability standards essential in safety-critical environments where failure could lead to mission abort and potential loss.

In summary, this display not only fulfills stringent functional requirements aligned with aviation industry norms but also enhances pilot interaction by incorporating features attuned specifically for operation within challenging high altitude or polar conditions while maintaining power efficiency conducive to extended operational capabilities in demanding environments.

---

### 2.1 System Block Diagram

<!-- Add the detailed block diagram for the product or system here -->

**Figure 2.1 : System Block Diagram**

---

### 2.2 System Specifications

<!-- Add the system specification here -->

**Table 2.1 : System Specifications**

| Parameter | Specification |
|-----------|---------------|
| | |

---

## 3 SYSTEM LEVEL REQUIREMENTS

The product / system requirements are given in the below table.

**Note:** This document provides the system requirement traceability number for each requirements as below:

`AT-2026-X1-<SyRS>-XXX`

**Example:** 
- cPCI-7497-HRS-001 for boards
- SIPU-8004-SyRS-001 for products

**Table 3.1 : System Level Requirements**

| Requirement ID | Function Description |
|----------------|---------------------|
| \<BID/PID/SID\>-\<SyRS\>-XXX | Hardware requirements |
| \<BID/PID/SID\>-\<SyRS\>-XXX | Software requirements |
| \<BID/PID/SID\>-\<SyRS\>-XXX | External interface requirements |
| \<BID/PID/SID\>-\<SyRS\>-XXX | Mechanical requirements |
| \<BID/PID/SID\>-\<SyRS\>-XXX | Environmental requirements |

*(If applicable add the required requirements)*

The detailed requirements for the product/system are given in the subsequent sections.

---

### 3.1 Hardware Requirements Specification

**Requirement ID :** \<BID/PID/SID\>-\<SyRS\>-XXX

The hardware requirements specifications are given in the below table.

**Table 3.2 : Hardware Requirements Specifications**

| S. No. | Section | Specification |
|--------|---------|---------------|
| (3.1.1) | EMI Filter | |
| (3.1.2) | DC-DC Converter | |
| (3.1.3) | Processor | |
| (3.1.4) | Performance | |
| (3.1.5) | External Memory | |
| (3.1.6) | FPGA | |
| (3.1.7) | Communication Interface | |
| (3.1.8) | ADC | |
| (3.1.9) | External Interfaces | |
| (3.1.10) | Unit Start up time (apx.) | |
| (3.1.11) | Component Selection | |
| (3.1.12) | Operating Temperature | |

---

### 3.2 Software Requirements Specification

**Requirement ID :** \<BID/PID/SID\>-\<SyRS\>-XXX

<!-- Add software requirements specifications here -->

---

### 3.3 External Interface Requirements Specification

**Requirement ID :** \<BID/PID/SID\>-\<SyRS\>-XXX

The external interface requirements specifications are given in the below table.

**Table 3.3 : External Interface Requirements Specifications**

| S. No. | Connector | Signal Assignment | No. of Pins | No. of Connectors |
|--------|-----------|-------------------|-------------|-------------------|
| (3.3.1) | | | | |
| (3.3.2) | | | | |

---

### 3.4 Mechanical Requirements Specification

**Requirement ID :** \<BID/PID/SID\>-\<SyRS\>-XXX

The mechanical requirements specifications are given in the below table.

**Table 3.4 : Mechanical Requirements Specifications**

| S. No. | Specification | Requirement | Remarks |
|--------|---------------|-------------|---------|
| (3.4.1) | Overall Dimension (L x W x H) | | In mm |
| (3.4.2) | Weight | | In Kg |
| (3.4.3) | Mounting Arrangement | | |
| (3.4.4) | Material | | |
| (3.4.5) | Cooling | | |
| (3.4.6) | Finish | | |
| (3.4.7) | Connector Layout | | |
| (3.4.8) | System Mounting Requirement | | |

---

### 3.5 Environmental Requirements Specification

**Requirement ID :** \<BID/PID/SID\>-\<SyRS\>-XXX

**Table 3.5 : Environmental Requirements Specifications**

| Type of Test/ Standard Reference | Severity | Duration | Remarks |
|----------------------------------|----------|----------|---------|
| (3.5.1) | | | |

---

## 4 DETAILED DESCRIPTION

<!-- Add detailed description about the product/system here -->

---

### 4.1 Subsystem / Module 1

Inclusion of advanced graphics APIs, notably OpenGL ES, Vulkan, and CUDA, provides capabilities to render intricate visuals while also accelerating parallel computations through leveraging a substantial count of processing cores - precisely, 512 CUDA-enabled compute units. This enhancement is instrumental in delivering the advanced computational power necessary for high-performance applications that require intensive graphics rendering and real-time data analysis tasks within an avionics environment where responsiveness and visual clarity are paramount.

Fast storage solutions, specifically a 512 GB Solid State Drive (SSD), employing the NVMe PCIe Gen3 interface is utilized for rapid access to critical flight system information alongside real-time data processing demands. The use of this SSD not only ensures swift and reliable operation but also contributes significantly to meeting stringent avionics performance criteria that necessitate immediate read/write capability under various operational conditions.

To safeguard against potential errors in the flight system's memory, which could arise from electrical interference or hardware malfunction during critical phases of operation where data integrity is essential for safety and reliable functioning, 16 GB of LPDDR4X RAM with built-in Error-Correcting Code (ECC) capabilities has been incorporated. This feature provides an added layer of error detection and correction to maintain the fidelity of computations performed by flight software during periods when data is processed at a rapid pace or under duress due to environmental factors inherent in avionics applications.

The system's block diagram reveals meticulously designed communication interfaces tailored for avionics integration, where dual-redundant MIL-STD-1553 bus controllers are present alongside remote terminal capabilities. These features facilitate a secure and robust data exchange between the various components of an aircraft’s control systems at speeds up to 1 Mbps while also ensuring fault tolerance through redundant pathways for critical information flow, thus enhancing overall system reliability in potentially high-stress scenarios that aviation professionals routinely encounter.

In addition to the traditional bus controllers of standard protocols, an ARINC 818 interface supports ultrahigh bandwidth video transmission with resolution up to 4K UHD at rates exceeding industry norms for aerospace applications while maintaining exceptional signal integrity and fidelity crucial for pilot situational awareness. This capability ensures that even during the most demanding flight conditions, pilots receive crystal-clear visual data from cameras mounted on or near aircraft components to aid in decision-making processes without compromising performance due to latency or compression artifacts typically associated with high bandwidth content transmission atypical for non-aviation equipment.

**Figure 4.1 : Block Diagram for Sub-System/Module 1**

**Table 4.1 : Sub-System/Module 1 Specifications**

| Reference | Parameter | Specification |
|-----------|-----------|---------------|
| 4.1.1 | Type | |
| 4.1.2 | Size | |
| 4.1.3 | Features | |
| 4.1.4 | Input and Output Specifications | |
| 4.1.5 | Connectors | |
| 4.1.6 | Power Requirements | |
| 4.1.7 | Max. Power Dissipation | |
| 4.1.8 | Environmental Specifications | |
| ... | ... | |
| 4.1.n | ... | |

*(If applicable specification statements shall be elaborated)*

#### 4.1.1 Specification statement – Type

<!-- Add specification details here -->

#### 4.1.2 Specification statement – Size

<!-- Add specification details here -->

#### 4.1.3 Specification statement – Features

<!-- Add specification details here -->

#### 4.1.4 Specification statement – Input and Output Specifications

<!-- Add specification details here -->

#### 4.1.5 Specification statement – Connectors

<!-- Add specification details here -->

#### 4.1.6 Specification statement – Power Requirements

<!-- Add specification details here -->

#### 4.1.7 Specification statement – Max Power Dissipation

<!-- Add specification details here -->

#### 4.1.8 Specification statement – Environmental Specifications

<!-- Add specification details here -->

---

### 4.2 Subsystem/Module 2

The display subsystem has been engineered to prioritize cockpit usability and compatibility with night vision imaging systems, adhering strictly to NVIS Green B standards throughout its design process. The brightness levels of the screen are adjustable within a spectrum ranging from as low as 0.1 candela per square meter up to a maximum intensity of 300 cd/m². This wide adaptability ensures optimal visibility under diverse lighting conditions, which is crucial for pilots who operate in varying environments and times of day.

The touch interface incorporates capacitive technology that enables the recognition of multi-touch gestures — essential inputs during critical flight operations. In consideration of aviators' requirements to wear gloves while handling control equipment or other gear, this display is designed with a glove-compatible feature set, ensuring seamless operation and interaction without compromising safety protocols.

Furthermore, the screen boasts an ultra-thin bezel that provides uninterrupted visibility of information on both sides — enhancing situational awareness while minimizing physical obstructions within a confined cockpit space. The designers have taken this one step further by ruggedizing the display to endure extreme conditions typically found in aviation settings, ensuring that durability does not come at the expense of user-friendliness or functionality during flight operations.

In terms of power consumption specifications tailored for an avionics setting, it has been optimized with a typical usage value set at 45 watts and peaking capability to handle up to 60 watts under the most demanding conditions without failure, ensuring reliable performance in critical flight scenarios. The subsystem's power management systems are thus crucial for maintaining operational integrity within strict energy consumption parameters often mandated by aviation authorities.

---
Incorporating these display features and optimizing software specifications to support the hardware capabilities results in an integrated system designed with utmost attention to detail, providing pilots with a reliable cockpit tool that enhances flight safety while aligning with energy usage standards for modern avionics environments. The subsystem's design reflects not only functional requirements but also ergonomic considerations intrinsic to high-stress operational conditions found in aviation settings where attention and precision are paramount.

**Figure 4.2 : Block Diagram for Sub-System/Module 2**

**Table 4.2 : Sub-System/Module 2 Specifications**

| Reference | Parameter | Specification |
|-----------|-----------|---------------|
| 4.2.1 | Type | |
| 4.2.2 | Size | |
| 4.2.3 | Features | |
| 4.2.4 | Input and Output Specifications | |
| 4.2.5 | Connectors | |
| 4.2.6 | Power Requirements | |
| 4.2.7 | Max. Power Dissipation | |
| 4.2.8 | Environmental Specifications | |
| ... | ... | |
| 4.2.n | ... | |

---

### 4.3 Subsystem/Module 3

The display subsystem has been engineered to prioritize cockpit usability and compatibility with night vision imaging systems, adhering strictly to NVIS Green B standards throughout its design process. The brightness levels of the screen are adjustable within a spectrum ranging from as low as 0.1 candela per square meter up to a maximum intensity of 300 cd/m². This wide adaptability ensures optimal visibility under diverse lighting conditions, which is crucial for pilots who operate in varying environments and times of day.

The touch interface incorporates capacitive technology that enables the recognition of multi-touch gestures — essential inputs during critical flight operations. In consideration of aviators' requirements to wear gloves while handling control equipment or other gear, this display is designed with a glove-compatible feature set, ensuring seamless operation and interaction without compromising safety protocols.

Furthermore, the screen boasts an ultra-thin bezel that provides uninterrupted visibility of information on both sides — enhancing situational awareness while minimizing physical obstructions within a confined cockpit space. The designers have taken this one step further by ruggedizing the display to endure extreme conditions typically found in aviation settings, ensuring that durability does not come at the expense of user-friendliness or functionality during flight operations.

In terms of power consumption specifications tailored for an avionics setting, it has been optimized with a typical usage value set at 45 watts and peaking capability to handle up to 60 watts under the most demanding conditions without failure, ensuring reliable performance in critical flight scenarios. The subsystem's power management systems are thus crucial for maintaining operational integrity within strict energy consumption parameters often mandated by aviation authorities.

---
Incorporating these display features and optimizing software specifications to support the hardware capabilities results in an integrated system designed with utmost attention to detail, providing pilots with a reliable cockpit tool that enhances flight safety while aligning with energy usage standards for modern avionics environments. The subsystem's design reflects not only functional requirements but also ergonomic considerations intrinsic to high-stress operational conditions found in aviation settings where attention and precision are paramount.

**Figure 4.3 : Block Diagram for Sub-System/Module 3**

**Table 4.3 : Sub-System/Module 3 Specifications**

| Reference | Parameter | Specification |
|-----------|-----------|---------------|
| 4.3.1 | Type | |
| 4.3.2 | Size | |
| 4.3.3 | Features | |
| 4.3.4 | Input and Output Specifications | |
| 4.3.5 | Connectors | |
| 4.3.6 | Power Requirements | |
| 4.3.7 | Max. Power Dissipation | |
| 4.3.8 | Environmental Specifications | |
| ... | ... | |
| 4.3.n | ... | |

---

### 4.4 Subsystem/ Module N

The display subsystem has been engineered to prioritize cockpit usability and compatibility with night vision imaging systems, adhering strictly to NVIS Green B standards throughout its design process. The brightness levels of the screen are adjustable within a spectrum ranging from as low as 0.1 candela per square meter up to a maximum intensity of 300 cd/m². This wide adaptability ensures optimal visibility under diverse lighting conditions, which is crucial for pilots who operate in varying environments and times of day.

The touch interface incorporates capacitive technology that enables the recognition of multi-touch gestures — essential inputs during critical flight operations. In consideration of aviators' requirements to wear gloves while handling control equipment or other gear, this display is designed with a glove-compatible feature set, ensuring seamless operation and interaction without compromising safety protocols.

Furthermore, the screen boasts an ultra-thin bezel that provides uninterrupted visibility of information on both sides — enhancing situational awareness while minimizing physical obstructions within a confined cockpit space. The designers have taken this one step further by ruggedizing the display to endure extreme conditions typically found in aviation settings, ensuring that durability does not come at the expense of user-friendliness or functionality during flight operations.

In terms of power consumption specifications tailored for an avionics setting, it has been optimized with a typical usage value set at 45 watts and peaking capability to handle up to 60 watts under the most demanding conditions without failure, ensuring reliable performance in critical flight scenarios. The subsystem's power management systems are thus crucial for maintaining operational integrity within strict energy consumption parameters often mandated by aviation authorities.

---
Incorporating these display features and optimizing software specifications to support the hardware capabilities results in an integrated system designed with utmost attention to detail, providing pilots with a reliable cockpit tool that enhances flight safety while aligning with energy usage standards for modern avionics environments. The subsystem's design reflects not only functional requirements but also ergonomic considerations intrinsic to high-stress operational conditions found in aviation settings where attention and precision are paramount.

**Figure 4.4 : Block Diagram for Sub-System/Module N**

**Table 4.4 : Sub-System/Module N Specifications**

| Reference | Parameter | Specification |
|-----------|-----------|---------------|
| 4.4.1 | Type | |
| 4.4.2 | Size | |
| 4.4.3 | Features | |
| 4.4.4 | Input and Output Specifications | |
| 4.4.5 | Connectors | |
| 4.4.6 | Power Requirements | |
| 4.4.7 | Max. Power Dissipation | |
| 4.4.8 | Environmental Specifications | |
| ... | ... | |
| 4.4.n | ... | |

---

## ANNEXURES

---

### Annexure A - KC Implementation

*(if applicable)*

List/ Map the KCs provided for the product/ system design and development in concurrence with the "KC implementation control plan table".

Use the KC Guideline document (HDD/KC/GL26) and refer Table 1.1.

**Table A1 : Key Characteristics ID**

| Key Characteristics ID | KC Name/ Specification | Requirement/Section Ref |
|------------------------|------------------------|------------------------|
| KC-\<XXXX-YYYY\>-SyRS-01 | \<Description / specification of the identified KC ID\> | \<Give the section ref / Req. ID that are specified in the document for the KC\> |
| Example: KC-\<XXXX-YYYY\>-SyRS-01 | Eg: Weight | |

---

### Annexure B - Requirement Traceability Matrix

**Table B1 : Requirement Traceability Matrix**

| S. No. | Requirement ID | Description | SyRS/MRS/User Requirement Specification ID/Ref | CMB/CRQ ID/Ref | HRS Section No. | SyRS Section No. |
|--------|----------------|-------------|-----------------------------------------------|----------------|-----------------|------------------|
| 1 | \<XXXX-YYYY\>-SyRS-001 | | | | | |
| 2 | \<XXXX-YYYY\>-SyRS-002 | | | | | |
| 3 | \<XXXX-YYYY\>-SyRS-003 | | | | | |
| .. | ..... | | | | | |
| .. | KC-\<XXXX-YYYY\>-SyRS-01 | | | | | |
| n | KC-\<XXXX-YYYY\>-SyRS-0n | | | | | |

**Filled In Sample:**

| S. No. | Requirement ID | Description | SyRS/MRS/User Requirement Specification ID/Ref | CMB/CRQ ID/Ref | HRS Section No. | SyRS Section No. |
|--------|----------------|-------------|-----------------------------------------------|----------------|-----------------|------------------|
| 1 | cPCI-7497-HRS-001 for board | Power requirements < 5W | SIPU-8004-SyRS-001 | | | |
| 2 | SIPU-8004-SyRS-001 for products | Weight < 5Kg | URS1-3.3.2 | | | |
| 3 | SIPU-8004-SyRS-002 for products | Operating temperature -40ºC to 70ºC | URS2-3.3.1 | | | |

---

### Annexure C – MRS – Modules

| Module Document ID |
|-------------------|
| \<<ARCH_TECH_AI>/IT\>-\<PID\>-HDD-MRS-XVYY-\<BA1\>-00 |
| \<<ARCH_TECH_AI>/IT\>-\<PID\>-HDD-MRS-XVYY-\<BA2\>-00 |
| \<<ARCH_TECH_AI>/IT\>-\<PID\>-HDD-MRS-XVYY-\<BA3\>-00 |
| .......... |
| \<<ARCH_TECH_AI>/IT\>-\<PID\>-HDD-MRS-XVYY-\<BAn\>-00 |

---

### Annexure D – SyRS – Subsystem

| Subsystem Document ID |
|----------------------|
| \<<ARCH_TECH_AI>/IT\>-\<PID\>-HDD-SyRS-XVYY-\<PA2/SA2\>-00 |
| \<<ARCH_TECH_AI>/IT\>-\<PID\>-HDD-SyRS-XVYY-\<PA3/SA3\>-00 |
| \<<ARCH_TECH_AI>/IT\>-\<PID\>-HDD-SyRS-XVYY-\<PA4/SA4\>-00 |
| .......... |
| \<<ARCH_TECH_AI>/IT\>-\<PID\>-HDD-SyRS-XVYY-\<PAn/SAn\>-00 |

---

### Annexure E : Validation Matrix

**Table E5.1 : Validation Matrix**

| Requirement ID | Description | Verification Method | Note |
|----------------|-------------|---------------------|------|
| | | QUAL TEST | ATP | INTEGRATION | DEMO | INSPECTION | ANALYSIS | |
| \<XXXX-YYYY\>-HRS/SyRS-001 | | | | | | | | |
| \<XXXX-YYYY\>-HRS/SyRS-001 | | | | | | | | |
| \<XXXX-YYYY\>-HRS/SyRS-001 | | | | | | | | |
| \<XXXX-YYYY\>-HRS/SyRS-001 | | | | | | | | |

**Verification Method Definitions:**

| Method | Description |
|--------|-------------|
| QUAL TEST | If the requirement is complied with any qualification testing it comes under Qual Test. (Eg. Environment Specification) |
| ATP | If the requirement is complied with normal functional testing, it comes in ATP. (All the requirement which can be validated can comes under this category) |
| INTEGRATION | If the requirement is complied by integration testing, it comes in INTEGRATION (Unit level, System Level, External Interface level which requires external modules / system for compliance) |
| DEMO | If the requirement is complied with one time validation, it comes under DEMO. (The requirements which have to be qualified but not carried for the production testing) |
| INSPECTION | If the requirement is complied with the physical inspection, it comes under INSPECTION (Eg. Size of the module) |
| ANALYSIS | If the requirement is complied with the any analysis, design compliance it comes under ANALYSIS |

**Filled In Sample:**

| Requirement ID | Description | Verification Method | Note |
|----------------|-------------|---------------------|------|
| | | QUAL TEST | ATP | INTEGRATION | DEMO | INSPECTION | ANALYSIS | |
| <BOARDID>-HRS-001 | Size | | | | | Y | | |
| <BOARDID>-HRS-002 | Voltage Range | | Y | | | | | |
| <BOARDID>-HRS-003 | Low Temperature | Y | | | | | | |
| <BOARDID>-HRS-004 | High Temperature | Y | | | | | | |
| <BOARDID>-HRS-005 | Over voltage Protect | | | | | | Y | |
| <BOARDID>-HRS-006 | Cycle Time | | | Y | | | | |

---

### Annexure F : Test Setup

#### Test Equipments Required

This section shall be given with required test equipments, test cables (bought out), test cables (fabricated), test jig, test rig, external modules, JTAG, Emulators, software environment, programming file etc.

**Table F6.1 : Test Equipment List**

| S. No. | Equipments/ Tool* | Manufacturer | Model Number |
|--------|-------------------|--------------|--------------|
| 1 | | | |
| 2 | | | |

*\*Also include external cooling devices, Ruggedizers*

**Table F6.2 : Jig / Cable List**

| S. No. | Jig / Cable Part No. | Jig / Cable Connector Ref | Board / Equipment mating ref (if avail) |
|--------|---------------------|--------------------------|----------------------------------------|
| 1 | | | |
| 2 | | | |

**Table F6.3 : Programming Files**

| S. No. | Programming Files** | Device | Development (New / Existing) |
|--------|---------------------|--------|------------------------------|
| 1 | | | |
| 2 | | | |

\*\*Also include onboard and PC files

#### Test Setup

This section shall be given with test setup with interconnection details and equipment connectivity.

> **Note:** This section shall be provided in tentative for planning of required test setup and jig in advance.

<!-- Add test setup diagram/details here -->

---

## Document Control

| Document Information | Details |
|---------------------|---------|
| Document Title | System Requirements Specification (SyRS) |
| Document ID | |
| Product Name | |
| Product ID | |
| Version | |
| Date | |
| Prepared By | |
| Reviewed By | |
| Approved By | |

---

## Revision History

| Version | Date | Author | Description of Changes |
|---------|------|--------|----------------------|
| 1.0 | | | Initial Draft |
| | | | |

---

*End of Document*
