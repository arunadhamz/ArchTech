/*---------------------------------------------------------------------------
 * Copyright (C) 2023 Data Patterns (India) Ltd.,  All rights reserved.
 *--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/**
 * @file dpbram.c
 *
 * This is the sample application to open, close and access the AXI BRAM device.
 *
 * MODIFICATION HISTORY:
 *
 * Ver   Who                    Date            Changes
 * ----- ----------------       --------        ----------------------------
 * 0V01  Vishnu Ram (2364)      13/03/2023      Initial Version
 *
 * </pre>
 *
 *----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "../../lib/include/dpbram_lib.h"

void dp_help()
{
	printf("\nwrite -  dpbram -w <Offset> <data>\n");
	printf("read  -  dpbram -r <Offset>\n\n");
}


int main(int argc, char **argv)
{
	char *pcOperation = NULL;
	char *pcOffset = NULL;
	char *pcData = NULL;
	
	int iRetVal = 0;

	unsigned int uiHandle = 0;

	unsigned int uiOffset = 0;
	unsigned int uiData = 0;
        char *pcDev = "/dev/dpbram";

#if 0
	// -- axi bram open
        if(argc > 5 || argc < 4){
                dp_help();
                return -1;
        }       
#endif
	uiHandle = dpbram_open(pcDev);
	if(uiHandle <= 0)
	{
		printf("[Error] - Device open failed\n");
		return -1;
	}

	pcOperation = (char*)calloc(10, sizeof(char));
        pcOffset = (char*)calloc(10, sizeof(char));
        pcData = (char*)calloc(10, sizeof(char));
#if 0	
	do
	{
		if(argc > 1)
		{
			strcpy(pcOperation, argv[1]);

			// -- write operation

			if((strcmp(pcOperation, "--write") == 0) || 
					(strcmp(pcOperation, "-w") == 0))
			{
				if(argc == 4)
				{
					strcpy(pcOffset, argv[2]);
					sscanf(pcOffset, "0x%X", &uiOffset);

					strcpy(pcData, argv[3]);
					sscanf(pcData, "0x%X", &uiData);

					iRetVal = dpbram_write_reg(uiHandle, uiOffset, uiData);
					if(iRetVal != 0)
					{
						printf("[Error] - bram write failed \n");
						break;
					}
				}
				else
				{
					dp_help();
				}
			}

			// -- read operation

			else if((strcmp(pcOperation, "--read") == 0) ||
					(strcmp(pcOperation, "-r") == 0))
			{
				if(argc == 3)
				{
					strcpy(pcOffset, argv[2]);
					sscanf(pcOffset, "0x%X", &uiOffset);

					iRetVal = dpbram_read_reg(uiHandle, uiOffset, &uiData);
					if(iRetVal != 0)
					{
						printf("[Error] - bram read failed\n");
						break;		
					}

					printf("0x%08X: 0x%08X\n", (uiOffset + 0xA0000000), uiData);
				}
				else
				{
					dp_help();
				}
			}

			else
			{
				dp_help();
			}
		}

		else
		{
			dp_help();
		}
	}while(0);


        if(pcOperation != NULL)free(pcOperation);
        if(pcOffset != NULL)free(pcOffset);
        if(pcData != NULL)free(pcData);
#else
        iRetVal = dpbram_read_reg(uiHandle, 0x0, &uiData);
        if(iRetVal != 0)
        {
                printf("[Error] - bram read failed\n");
                return -1;
        }

        printf("0x%08X: 0x%08X\n", (uiOffset + 0xA0000000), uiData);

#endif
        // -- axi bram close

        dpbram_close(uiHandle);


        return 0;
}
