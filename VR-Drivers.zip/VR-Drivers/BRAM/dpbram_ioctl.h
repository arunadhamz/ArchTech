#ifndef DPBRAM_IOCTL_H
#define DPBRAM_IOCTL_H


#define DP_EVENT_CONDITION      1
#define DP_EVENT_TIMEOUT        0

/**
*\struct dpbram_wr
*/

struct dpbram_wr
{
	unsigned int uiOffset;		/*!< Offset Address */
	unsigned int uiData;		/*!< input data */
};

/**
*\struct dpbram_rd
*/

struct dpbram_rd
{
	unsigned int uiOffset;		/*!< Offset Address */
	unsigned int *puiData;		/*!< Output data */
};


#define DPBRAM_MAGIC_NO         'x'
#define	DPBRAM_REG_WR			_IOWR(DPBRAM_MAGIC_NO, 1, struct dpbram_wr)
#define DPBRAM_REG_RD			_IOWR(DPBRAM_MAGIC_NO, 2, struct dpbram_rd)
#define DPBRAM_IRQWAIT          _IOWR(DPBRAM_MAGIC_NO, 3, unsigned long)        
#endif

