
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/io.h>
#include <linux/interrupt.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/irq.h>
#include <linux/wait.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/of_device.h>
#include <linux/of_platform.h>

#include "../dpbram_ioctl.h"

#define DRIVER_NAME "dpbram"


struct dpbram_local {

        struct platform_device *m_pdev;

        void __iomem *m_pRegs;
        unsigned int m_uiMem_start;
        unsigned int m_uiMem_end;
        unsigned int m_uiMem_size;

        dev_t m_dev_num;
        unsigned int m_uiMajor_num;
        unsigned int m_uiMinor_num;
        struct cdev m_cdev;
        struct class *m_pClass;

        int m_iIrq;

        // -- wait queue
        wait_queue_head_t m_waitqueue;
        int m_iWaitqueue_flag;        

};

/**
 * dpbram_reg_write - function for writing Block RAM registers.
 * @lp:          Pointer to dpbram_local structure
 * @uiOffset     address offset
 * @uiData       data
 *
 */
static int dpbram_reg_write(struct dpbram_local *lp, unsigned int uiOffset, unsigned int uiData)
{
        writel(uiData, (lp->m_pRegs + uiOffset));
        return 0;
}

/**
 * dpbram_reg_read - function for reading Block RAM registers.
 * @lp:          Pointer to dpbram_local structure
 * @uiOffset     address offset
 *
 */
static int dpbram_reg_read(struct dpbram_local *lp, unsigned int uiOffset)
{
        return  readl(lp->m_pRegs + uiOffset);
}

static int dpbram_eventwait(struct dpbram_local *lp, unsigned long ulTimeout)
{
        int iStatus = 0;

        lp->m_iWaitqueue_flag = 0;
        do {
                wait_event_interruptible_timeout(lp->m_waitqueue,
                                (lp->m_iWaitqueue_flag != 0),
                                msecs_to_jiffies(ulTimeout));

                if(lp->m_iWaitqueue_flag != 0) {
                        iStatus = DP_EVENT_CONDITION;
                        break;
                }

                iStatus = DP_EVENT_TIMEOUT;
                break;
        }while(0);
        return iStatus;
}

/**
 * dpbram_ioctl - ioctl function.
 * @file:  Pointer to file structure
 * @cmd:   IOCTL command
 * @arg:   arguments form the user space
 *
 * Return: 0, on success.
 *  Non-zero error value on failure.
 */
static long dpbram_ioctl (struct file *filp, unsigned int cmd, 
                unsigned long arg)
{      
        int iRet = 0; 
        void *pvBuffer = NULL;
        unsigned int uiOffset = 0;
        unsigned int uiData = 0;
        char send_flag = 0;
        struct dpbram_local *lp = filp->private_data;

        pvBuffer = kzalloc(_IOC_SIZE(cmd), GFP_KERNEL);
        if(!pvBuffer){
                return -ENOMEM;
        }

        if((copy_from_user((unsigned long*)pvBuffer, (unsigned long*)arg,
                                        _IOC_SIZE(cmd)))) {
                iRet = -EFAULT;
        }

        switch (cmd)
        {
                case DPBRAM_REG_WR: // register write

                        uiOffset = ((struct dpbram_wr*)pvBuffer)->uiOffset;
                        uiData = ((struct dpbram_wr*)pvBuffer)->uiData;

                        dpbram_reg_write(lp, uiOffset, uiData);
                        break;

                case DPBRAM_REG_RD: // register read

                        uiOffset = ((struct dpbram_rd*)pvBuffer)->uiOffset;
                        *((struct dpbram_rd*)pvBuffer)->puiData = dpbram_reg_read(lp, uiOffset);

                        send_flag = 1;
                        break;

                case DPBRAM_IRQWAIT: // irq event wait

                        iRet = dpbram_eventwait(lp,*((unsigned long*)pvBuffer));
                        break;

                default:
                        pr_info("Invalid IOCTL\n");
                        iRet = -EINVAL;
                        break;
        }

        if(send_flag == 1) {
                if((copy_to_user((unsigned long*)arg, (unsigned long*)pvBuffer,
                                                _IOC_SIZE(cmd)))) {
                        iRet = -EFAULT;
                }
        }

        if(pvBuffer)
                kfree(pvBuffer);
        return iRet;
}
/**
 * dpbram_irq_handler - BRAM Interrupt service routine.
 * @irq:	irq number
 * @lp:	        pointer to the dpbram_local structure.
 *
 * Return: IRQ_HANDLED if device generated a core interrupt, IRQ_NONE otherwise.
 *
 * Handle miscellaneous conditions indicated by notifier IRQ.
 */

static irqreturn_t dpbram_irq_handler(int irq, void *vlp)
{
        struct dpbram_local *lp = vlp;

        // -- waking up the wait quque
        lp->m_iWaitqueue_flag = 1;
        wake_up_interruptible(&lp->m_waitqueue);

        return IRQ_HANDLED;
}



/**
 * dpbram_open - Driver open routine.
 * @in_pInode:	Pointer to inode structure
 * @in_pfile:   Pointer to file structure
 *
 * Return: 0, on success.
 *	    non-zero error value on failure
 *
 * This is the driver open routine. it allocates interrupt service routines, 
 * enables the interrupt lines and ISR handling. Resets the BRAM core
 */
static int dpbram_open (struct inode *in_pInode, struct file *in_pfile)
{
        struct dpbram_local *lp;
        int iRet = 0;
        struct device_node *np = NULL;
        struct device *dev = NULL;

        lp = container_of(in_pInode->i_cdev, struct dpbram_local, m_cdev);
        in_pfile->private_data = lp;
        dev = &lp->m_pdev->dev;
        np = lp->m_pdev->dev.of_node;

        // request irq
        if(!(lp->m_iIrq <= 0)){
                iRet = request_irq(lp->m_iIrq, 
                                dpbram_irq_handler,
                                IRQF_TRIGGER_RISING | IRQF_SHARED,
                                np->name,
                                lp);
                /*if(iRet){
                        dev_err(dev, "request irq for %s failed\n",
                                        np->name);
                }*/

                /* Initializing wait quque */
                lp->m_iWaitqueue_flag = 0;
                init_waitqueue_head(&lp->m_waitqueue);
        }

        return 0;
}

/**
 * dpbram_release - Driver release routine.
 * @in_pInode:  Pointer to inode structure
 * @in_pfile:   Pointer to file structure
 *
 * Return: 0, on success.
 *
 * This is the driver stop routine. It removes the interrupt handlers
 * and disables the interrupts.
 */
static int dpbram_release (struct inode *in_pInode, struct file *in_pfile)
{
        struct dpbram_local *lp;

        lp = in_pfile->private_data;
        if(lp->m_iIrq){
                free_irq(lp->m_iIrq, lp);
        }

        in_pfile->private_data = NULL;
        return 0;
}


static struct file_operations dpbram_fops = {
        .open = dpbram_open,
        .release = dpbram_release,
        .unlocked_ioctl = dpbram_ioctl,
        .owner = THIS_MODULE,
};

/**
 * dpbram_reg_chrdev - char device register function.
 * @pdev:  Pointer to platform_device structure
 *
 * Return: 0, on success.
 *  Non-zero error value on failure.
 *
 * This is the char device register routine. It registers the bram device
 * with the kernel and creates a device file.
 */
static int dpbram_reg_chrdev(struct platform_device *pdev)
{
        int iRet = 0;
        dev_t dev_num = 0;
        struct dpbram_local *lp = platform_get_drvdata(pdev);
        struct device_node *np = pdev->dev.of_node;

        iRet = alloc_chrdev_region(&dev_num, 0, 1, np->name);
        if(iRet != 0) {
                return iRet;
        }

        lp->m_dev_num = dev_num;
        lp->m_uiMajor_num = MAJOR(dev_num);
        lp->m_uiMinor_num = MINOR(dev_num);

        cdev_init(&lp->m_cdev, &dpbram_fops);
        iRet = cdev_add(&lp->m_cdev, lp->m_dev_num, 1);
        if(iRet != 0) {
                unregister_chrdev_region(lp->m_dev_num, 1);
                return iRet;
        }

        if(IS_ERR(lp->m_pClass = class_create(THIS_MODULE, np->name))) {
                cdev_del(&lp->m_cdev);
                unregister_chrdev_region(lp->m_dev_num, 1);
                return -EINVAL;
        }

        if(IS_ERR(device_create(lp->m_pClass, NULL, lp->m_dev_num, NULL,
                                        np->name))) {
                class_destroy(lp->m_pClass);
                cdev_del(&lp->m_cdev);
                unregister_chrdev_region(lp->m_dev_num, 1);
                return -EINVAL;
        }

        return 0;
}

/**
 * dpbram_unreg_chrdev - char device unregister function.
 * @pdev:  Pointer to platform_device structure
 *
 * This is the char device unregister routine. It unregisters the bram device
 * with the kernel and removes the device file.
 */
static void dpbram_unreg_chrdev(struct platform_device *pdev)
{
        struct dpbram_local *lp = platform_get_drvdata(pdev);

        device_destroy(lp->m_pClass, lp->m_dev_num);
        class_destroy(lp->m_pClass);
        cdev_del(&lp->m_cdev);
        unregister_chrdev_region(lp->m_dev_num, 1);
        return;
}

/**
 * dpbram_probe - probe function.
 * @pdev:	Pointer to platform device structure.
 *
 * Return: 0, on success
 *	    Non-zero error value on failure.
 *
 * This is the probe routine for BRAM driver. This is called before
 * any other driver routines are invoked. It allocates and sets up the BRAM
 * device. Parses through device tree and populates the local structure.
 * It registers the bram device.
 */
static int dpbram_probe(struct platform_device *pdev)
{
        int iRet = 0;
        struct dpbram_local *lp;
        struct device_node *np;
        struct resource r_mem; /* IO mem resources */
        struct device *dev = &pdev->dev;

        // parscing device tree node
        np = of_parse_phandle(pdev->dev.of_node, "connected-axistream", 0);
        if(!np) {
                dev_err(dev, "missing connected-axistream property\n");
                return -EINVAL;
        }

        // get IO memory space
        iRet = of_address_to_resource(np, 0, &r_mem);
        if(iRet < 0) {
                dev_err(dev, "unable to get BRAM resources\n");
                return -ENODEV;
        }

        lp = devm_kzalloc(&pdev->dev, sizeof(struct dpbram_local), GFP_KERNEL);
        if(!lp) {
                return -ENOMEM;
        }

        if (!devm_request_mem_region(dev, r_mem.start,
                                resource_size(&r_mem), DRIVER_NAME)) {
                return -EBUSY;
        }

        lp->m_pdev = pdev;
        lp->m_uiMem_start = r_mem.start;
        lp->m_uiMem_end = r_mem.end;
        lp->m_uiMem_size = resource_size(&r_mem);

        lp->m_pRegs = devm_ioremap(dev, r_mem.start, resource_size(&r_mem));
        if (!lp->m_pRegs) {
                return -ENOMEM;
        }

        platform_set_drvdata(pdev, lp);

        lp->m_iIrq = platform_get_irq(pdev, 0);

        // register chrdev
        iRet = dpbram_reg_chrdev(pdev);
        if(iRet){
                dev_err(dev, "failed to register chrdev\n");
                platform_set_drvdata(pdev, NULL);
                return iRet;
        }
        return 0;
}

/**
 * dpbram_remove - remove function.
 * @pdev:	Pointer to platform device structure.
 *
 * Return: 0, on success
 *	    Non-zero error value on failure.
 *
 * This is the remove routine for BRAM driver. This is called when the driver
 * got removed, it deletes the bram device file.
 */
static int dpbram_remove(struct platform_device *pdev)
{
        dpbram_unreg_chrdev(pdev);
        return 0;
}


static struct of_device_id dpbram_of_match[] = {
        { .compatible = "dp,bram", },
        {},
};
MODULE_DEVICE_TABLE(of, dpbram_of_match);

static struct platform_driver dpbram_driver = {
        .driver = {
                .name = DRIVER_NAME,
                .owner = THIS_MODULE,
                .of_match_table	= dpbram_of_match,
        },
        .probe		= dpbram_probe,
        .remove		= dpbram_remove,
};

static int __init dpbram_init(void)
{
        return platform_driver_register(&dpbram_driver);
}

static void __exit dpbram_exit(void)
{
        platform_driver_unregister(&dpbram_driver);
}

module_init(dpbram_init);
module_exit(dpbram_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Data Patterns India Ltd., Vishnu Ram G");
MODULE_DESCRIPTION("BRAM driver for zynq MPSoC/RFSoC");
