#ifndef DPBRAM_LIB_H
#define DPBRAM_LIB_H

#define DP_EVENT        1

int dpbram_open(char *pszDeviceName);
void dpbram_close(int iHandle);
int dpbram_read_reg(int iHandle, unsigned int uiOffset, unsigned int *puiData);
int dpbram_write_reg(int iHandle, unsigned int uiOffset, unsigned int uiData);
int dpbram_eventwait(int iHandle, unsigned long ulTimeout);



#endif
