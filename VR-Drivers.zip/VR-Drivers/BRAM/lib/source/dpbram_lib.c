#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "../../dpbram_ioctl.h"
#include <dpbram_lib.h>

int dpbram_open(char *pszDeviceName)
{
        int iHandle = 0;

        if(!pszDeviceName) {
                printf("Invalid pointer\n");
                return -1;
        }

        iHandle = open(pszDeviceName, O_RDWR);
        if(iHandle < 0){
                perror("open() ");
                printf("failed to open %s\n", pszDeviceName);
                return -1;
        }

        return iHandle;
}

void dpbram_close(int iHandle)
{
        if(iHandle < 0) {
                printf("Invalid Handle\n");
        }else {
                close(iHandle);
        }
        return;
}

int dpbram_read_reg(int iHandle, unsigned int uiOffset, unsigned int *puiData)
{
        int err = 0;
        struct dpbram_rd rd = {0};

        if(iHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        if(!puiData){
                printf("Invalid Pointer");
                return -1;
        } 
        if((uiOffset % 4) != 0) {
                printf("Invalid address offset\n");
                return -1;
        }

        rd.uiOffset = uiOffset;
        rd.puiData = puiData;

        err = ioctl(iHandle, DPBRAM_REG_RD, (unsigned int *)&rd);
        if(err != 0) {
                perror("ioctl() ");
                printf("Failed to read BRAM Registers\n");
                return -1;
        }

        return 0;
}

int dpbram_write_reg(int iHandle, unsigned int uiOffset, unsigned int uiData)
{
        int err = 0;
        struct dpbram_wr wr = {0};

        if(iHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        if((uiOffset % 4) != 0) {
                printf("Invalid address offset\n");
                return -1;
        }

        wr.uiOffset = uiOffset;
        wr.uiData = uiData;
        err = ioctl(iHandle, DPBRAM_REG_WR, (unsigned long*)&wr);
        if(err != 0) {
                perror("ioctl() ");
                printf("Failed to write BRAM Registers\n");
                return -1;
        }

        return 0;
}


int dpbram_eventwait(int iHandle, unsigned long ulTimeout)
{
        int err = 0;

        if(iHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }
       
        err = ioctl(iHandle, DPBRAM_IRQWAIT, &ulTimeout);
        if(err < 0) {
                perror("ioctl() ");
                printf("BRAM event waitfailed\n");
                return -1;
        }
        
        if(err == DP_EVENT_CONDITION)
                return DP_EVENT;
        
        return 0;
        
}

