#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <sys/mman.h>

#include "../lib/include/dpdma_lib.h"

#define DP_DMA_DEV   "/dev/dpdma_queue0"

#define RX_DMA_SZ       2*1024*1024

int main()
{
        int iRet = 0;
        unsigned int iHandle = 0;
        unsigned long uiRxPhyaddr = 0;
        unsigned long uiTxPhyaddr = 0;
        unsigned long *puiRxViraddr = 0;
        unsigned long *puiTxViraddr = 0;
        unsigned int uiDiscriptor;
        // -- DMA fpga to memory
        iHandle = dpdma_open(DP_DMA_DEV);
        if(iHandle < 0 )
        {
                printf("failed to open device");
                return -1;
        }
        
        uiDiscriptor = 1;
        iRet = dpdma_get_rx_phyaddr(iHandle, uiDiscriptor, &uiRxPhyaddr);
        if(iRet) {
                printf("dpdma_get_rx_phyaddr failed for discriptor %d\n", uiDiscriptor);
                return -1;
        }

        iRet = dpdma_get_tx_phyaddr(iHandle, uiDiscriptor, &uiTxPhyaddr);
        if(iRet) {
                printf("dpdma_get_tx_phyaddr failed for discriptor %d\n", uiDiscriptor);
                return -1;
        }
        
        puiRxViraddr = mmap(0, RX_DMA_SZ, PROT_READ | PROT_WRITE, MAP_SHARED, iHandle, uiRxPhyaddr);
        if(puiRxViraddr == NULL) {
                printf("failed to map memory");
                return -1;
        }

        puiTxViraddr = mmap(0, RX_DMA_SZ, PROT_READ | PROT_WRITE, MAP_SHARED, iHandle, uiTxPhyaddr);
        if(puiTxViraddr == NULL) {
                printf("failed to map memory");
                return -1;
        }
       
        printf("RX Phy - %lx\n", uiRxPhyaddr);
        printf("TX Phy - %lx\n", uiTxPhyaddr);
        
        iRet = dpdma_tx_config(iHandle, uiDiscriptor);
        if(iRet) {
                printf("dpdma_tx_config failed for discriptor %d\n", uiDiscriptor);
                return -1;
        }

        iRet = dpdma_rx_config(iHandle, uiDiscriptor);
        if(iRet) {
                printf("dpdma_rx_config failed for discriptor %d\n", uiDiscriptor);
                return -1;
        }

        while(1)
        {
                sleep(1);
                printf("RX - %lx TX - %lx\n", *puiRxViraddr, *puiTxViraddr);
        }
        
        dpdma_close(iHandle);
        return 0;
}
