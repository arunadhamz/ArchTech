#ifndef DPDMA_IOCTL_H
#define DPDMA_IOCTL_H


#define BD_MAX_SIZE             2*1024*1024

#define DP_EVENT_CONDITION      1
#define DP_EVENT_TIMEOUT        0


/**
*\struct dpdma_phyaddr
*/

struct dpdma_phyaddr
{
        unsigned int uiDescriptor;
	unsigned long *pulPhyAddr;	
};

#define DPDMA_MAGIC_NO         'R'
#define DPDMA_GET_TX_PHYADDR	_IOWR(DPDMA_MAGIC_NO, 1, struct dpdma_phyaddr)
#define DPDMA_GET_RX_PHYADDR	_IOWR(DPDMA_MAGIC_NO, 2, struct dpdma_phyaddr)
#define DPDMA_TX_CONFIG         _IOWR(DPDMA_MAGIC_NO, 3, unsigned int)
#define DPDMA_RX_CONFIG         _IOWR(DPDMA_MAGIC_NO, 4, unsigned int)
#define DPDMA_TX_XMIT           _IOWR(DPDMA_MAGIC_NO, 5, unsigned int)
#define DPDMA_RX_XMIT           _IOWR(DPDMA_MAGIC_NO, 6, unsigned int)
#define DPDMA_TX_IRQWAIT           _IOWR(DPDMA_MAGIC_NO, 7, unsigned long)        
#define DPDMA_RX_IRQWAIT           _IOWR(DPDMA_MAGIC_NO, 8, unsigned long)        

#endif

