
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/io.h>
#include <linux/interrupt.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/irq.h>
#include <linux/dma-mapping.h>
#include <linux/wait.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/of_device.h>
#include <linux/of_platform.h>
#include <linux/delay.h>

#include "dpdma.h"
#include "../dpdma_ioctl.h"

//#define DMA_INTERRUPT  // enable this if AXI DMA interrupt is used

#define DRIVER_NAME "dpdma"


struct dpdma_bd {
        size_t size;                // Size of the buffer
        void *kern_addr;            // Kernel virtual address of the buffer
        dma_addr_t dma_addr;        // DMA bus address of the buffer
        int descriptor;
};

struct dpdma_local {
        struct platform_device *pdev;

        struct device_node *node;

        void __iomem *regs;
        unsigned int mem_start;
        unsigned int mem_end;
        unsigned int mem_size;

        dev_t dev_num;
        unsigned int major_num;
        unsigned int minor_num;
        struct cdev cdev;
        struct class *class;
        int irq;

        unsigned char dma_chan_count;
        unsigned char dma_rx_chan;
        unsigned char dma_tx_chan;
        int dma_mask;        
        int rx_irq;
        int tx_irq;

        struct dpdma_bd *tx_bd; 
        struct dpdma_bd *rx_bd; 
        void *tx_kern_vir_addr;
        void *rx_kern_vir_addr;
        dma_addr_t tx_dma_addr;
        dma_addr_t rx_dma_addr;
        unsigned int tx_buf_size;        
        unsigned int rx_buf_size;       
        unsigned int tx_bd_count; 
        unsigned int rx_bd_count; 
        unsigned int rx_curr_bd_index;
        unsigned int tx_curr_bd_index;
        unsigned long rx_curr_bd_addr;
        unsigned long tx_curr_bd_addr;
        struct tasklet_struct tx_dma_err_tasklet;
        struct tasklet_struct rx_dma_err_tasklet;

        // -- wait queue
        wait_queue_head_t m_txwaitqueue;
        int m_itxWaitqueue_flag;        
        wait_queue_head_t m_rxwaitqueue;
        int m_irxWaitqueue_flag;        
};

/**
 * dpdma_reg_write - function for writing dma registers.
 * @lp:          Pointer to dpdma_local structure
 * @uiOffset     address offset
 * @uiData       data
 *
 * This is used to write the dma registers.
 */
static int dpdma_reg_write(struct dpdma_local *lp, unsigned int uiOffset, unsigned int uiData)
{
        writel(uiData, (lp->regs + uiOffset));
        return 0;
}

/**
 * dpdma_reg_read - function for reading dma registers.
 * @lp:          Pointer to dpdma_local structure
 * @uiOffset     address offset
 *
 * This is used to read the dma registers.
 */
static int dpdma_reg_read(struct dpdma_local *lp, unsigned int uiOffset)
{
        return  readl(lp->regs + uiOffset);
}

/**
 * dpdma_tx_xmit - function for transmitting data from memory to stream.
 * @lp:          Pointer to dpdma_local structure
 * @uiSize       size of the data to be transmitted
 * 
 * This is used to initialize data transmission between memory and stream (mm2s).
 */
static int dpdma_tx_xmit(struct dpdma_local *lp, unsigned int uiSize)
{
        unsigned int sr_reg = 0;
        unsigned int uiTimeout;
        struct device *dev = &lp->pdev->dev;

        if(uiSize < 0 || uiSize > lp->tx_buf_size) {
                dev_err(&lp->pdev->dev, "DMA Tx Invalid buffer size, max buffer size  %d\n",
                                lp->tx_buf_size);
                return -1;
        }

        /* check the DMA halt status */
        uiTimeout = 1000;
        do {
                /* read the dma status */
                sr_reg = dpdma_reg_read(lp, DPDMA_TX_SR_REG);
                udelay(1);
                if(--uiTimeout == 0) {
                        dev_err(&lp->pdev->dev, "DMA Tx channel Halt timeout\n");
                        return -1;
                }

        }while((sr_reg & DPDMA_SR_HALT_MASK) == DPDMA_SR_HALT_MASK);
        dpdma_reg_write(lp, DPDMA_TX_LENGTH_REG, uiSize);

        return 0;
}

/**
 * dpdma_rx_xmit - function for receiving data from stream to memory.
 * @lp:          Pointer to dpdma_local structure
 * @uiSize       size of the data to be received
 *
 * This is used to initialize data reception between stream and memory (s2mm).
 */
static int dpdma_rx_xmit(struct dpdma_local *lp, unsigned int uiSize)
{
        unsigned int sr_reg = 0;
        unsigned int uiTimeout;
        struct device *dev = &lp->pdev->dev;

        if(uiSize < 0 || uiSize > lp->rx_buf_size) {
                dev_err(&lp->pdev->dev, "DMA Rx Invalid buffer size, max buffer size  %d\n",
                                lp->rx_buf_size);
                return -1;
        }
        /* check the DMA halt status */
        uiTimeout = 1000;
        do {
                /* read the dma status */
                sr_reg = dpdma_reg_read(lp, DPDMA_RX_SR_REG);
                udelay(1);
                if(--uiTimeout == 0) {
                        dev_err(&lp->pdev->dev, "DMA Rx channel Halt timeout\n");
                        return -1;
                }

        }while((sr_reg & DPDMA_SR_HALT_MASK) == DPDMA_SR_HALT_MASK);

        dpdma_reg_write(lp, DPDMA_RX_LENGTH_REG, uiSize);

        return 0;
}

/**
 * dpdma_tx_config - function for configuring descriptor for the data transmission form
 * memory to stream.
 *
 * @lp:          Pointer to dpdma_local structure
 * @uiDescriptor descriptor in which the data to be buffered
 *
 * This is used to configure the buffer descriptor for the data to be transmitted between 
 * memory to stream (mm2s) .
 */
static int dpdma_tx_config(struct dpdma_local *lp, unsigned int uiDescriptor)
{
        unsigned int cr_reg = 0;
        unsigned int sr_reg = 0;
        unsigned int uiTimeout;
        struct device *dev = &lp->pdev->dev;
        int iIndex;

        /* validating buffer descriptor */
        if(uiDescriptor < 1 || uiDescriptor > lp->tx_bd_count){
                dev_err(&lp->pdev->dev, "DMA Tx Invalid buffer descriptor, max bd %d\n",
                                lp->tx_bd_count);
                return -1;
        }

        if(lp->tx_bd == NULL){
                dev_err(dev, "Tx buffer descriptor not initialized\n");
                return -ENOMEM;
        }

        // First iterate over DMA buffers allocated by this driver
        for(iIndex = 0; iIndex < lp->tx_bd_count; iIndex++) {
                if(lp->tx_bd[iIndex].descriptor == uiDescriptor){
                        lp->tx_curr_bd_addr = (unsigned long)lp->tx_bd[iIndex].dma_addr;
                        lp->tx_curr_bd_index = (unsigned int)lp->tx_bd[iIndex].descriptor;
                        break;
                }
        }

        /* check the DMA halt status */
        uiTimeout = 1000;
        do {
                /* read the dma status */
                sr_reg = dpdma_reg_read(lp, DPDMA_TX_SR_REG);
                udelay(1);
                if(--uiTimeout == 0) {
                        dev_err(&lp->pdev->dev, "DMA Tx channel Halt timeout\n");
                        return -1;
                }

        }while((sr_reg & DPDMA_SR_HALT_MASK) == DPDMA_SR_HALT_MASK);

        /* write the valid destination address*/
        dpdma_reg_write(lp, DPDMA_TX_SA_LSB_REG,
                        (unsigned int)(lp->tx_curr_bd_addr & 0xffffffff));
        if(lp->dma_mask == 64)
                dpdma_reg_write(lp, DPDMA_TX_SA_MSB_REG,
                                (unsigned int)((lp->tx_curr_bd_addr >> 32) & 0xffffffff));

        return 0;
}

/**
 * dpdma_rx_config - function for configuring descriptor for the data reception form
 * stream to memory.
 *
 * @lp:          Pointer to dpdma_local structure
 * @uiDescriptor descriptor in which the data to be buffered
 *
 * This is used to configure the buffer descriptor for the data to be received from 
 * stream to memory (mm2s).
 */
static int dpdma_rx_config(struct dpdma_local *lp, unsigned int uiDescriptor)
{
        unsigned int cr_reg = 0;
        unsigned int sr_reg = 0;
        unsigned int uiTimeout;
        struct device *dev = &lp->pdev->dev;
        int iIndex;

        /* validating buffer descriptor */
        if(uiDescriptor < 1 || uiDescriptor > lp->rx_bd_count){
                dev_err(&lp->pdev->dev, "DMA Rx Invalid buffer descriptor, max bd %d\n",
                                lp->rx_bd_count);
                return -1;
        }

        if(lp->rx_bd == NULL){
                dev_err(dev, "Rx buffer descriptor not initialized\n");
                return -ENOMEM;
        }

        // First iterate over DMA buffers allocated by this driver
        for(iIndex = 0; iIndex < lp->rx_bd_count; iIndex++) {
                if(lp->rx_bd[iIndex].descriptor == uiDescriptor){
                        lp->rx_curr_bd_addr = (unsigned long)lp->rx_bd[iIndex].dma_addr;
                        lp->rx_curr_bd_index = (unsigned int)lp->rx_bd[iIndex].descriptor;
                        break;
                }
        }

        /* check the DMA halt status */
        uiTimeout = 1000;
        do {
                /* read the dma status */
                sr_reg = dpdma_reg_read(lp, DPDMA_RX_SR_REG);
                udelay(1);
                if(--uiTimeout == 0) {
                        dev_err(&lp->pdev->dev, "DMA Rx channel Halt timeout\n");
                        return -1;
                }

        }while((sr_reg & DPDMA_SR_HALT_MASK) == DPDMA_SR_HALT_MASK);

        /* write the valid destination address*/
        dpdma_reg_write(lp, DPDMA_RX_DA_LSB_REG,
                        (unsigned int)(lp->rx_curr_bd_addr & 0xffffffff));
        if(lp->dma_mask == 64)
                dpdma_reg_write(lp, DPDMA_RX_DA_MSB_REG,
                                (unsigned int)((lp->rx_curr_bd_addr >> 32) & 0xffffffff));

        return 0;
}

/**
 * dpdma_core_reset - function for resetting the AXI DMA IP core
 *
 * @lp:          Pointer to dpdma_local structure
 *
 * This is used to reset the entire AXI DMA IP core
 */
static int dpdma_core_reset(struct dpdma_local *lp)
{
        unsigned int uiTimeout;
        /* Note that even though both TX and RX have their own reset register,
         * they both reset the entire DMA core.
         */
        if(lp->dma_rx_chan > 0) {
                dpdma_reg_write(lp, DPDMA_RX_CR_REG, DPDMA_CR_RESET_MASK);
                uiTimeout = 1000;       // 1 milli seconds

                while(dpdma_reg_read(lp, DPDMA_RX_CR_REG) & DPDMA_CR_RESET_MASK) {
                        udelay(1);
                        if(--uiTimeout == 0) {
                                dev_err(&lp->pdev->dev, "DMA Tx reset timeout\n");
                                return -1;
                        }
                }
        }

        if(lp->dma_tx_chan > 0) {
                dpdma_reg_write(lp, DPDMA_TX_CR_REG, DPDMA_CR_RESET_MASK);
                uiTimeout = 1000;       // 1 milli seconds

                while(dpdma_reg_read(lp, DPDMA_TX_CR_REG) & DPDMA_CR_RESET_MASK) {
                        udelay(1);
                        if(--uiTimeout == 0) {
                                dev_err(&lp->pdev->dev, "DMA Rx reset timeout\n");
                                return -1;
                        }
                }

        }
        return 0;
}

/**
 * dpdma_tx_chan_init - function for initializing the tx channel (mm2s)
 *
 * @lp:          Pointer to dpdma_local structure
 *
 * This is used to initialize tx channel with the configured buffer descriptor 
 * for the data to be transmitted from memory to stream (mm2s).
 */
static int dpdma_tx_chan_init(struct dpdma_local *lp)
{
        unsigned int cr_reg;
        unsigned int sr_reg;
        unsigned int uiTimeout;

        /* Updating interrupts in the TX configuration registers */
        cr_reg = dpdma_reg_read(lp, DPDMA_TX_CR_REG);
        cr_reg |= DPDMA_IRQ_ALL_MASK;
        /* Start the dma engine */
        cr_reg |= DPDMA_CR_RUNSTOP_MASK;
        dpdma_reg_write(lp, DPDMA_TX_CR_REG, cr_reg);

        uiTimeout = 1000;
        do {
                /* read the dma status */
                sr_reg = dpdma_reg_read(lp, DPDMA_TX_SR_REG);
                udelay(1);
                if(--uiTimeout == 0) {
                        dev_err(&lp->pdev->dev, "DMA Tx channel Halt timeout\n");
                        break;
                }
        }while((sr_reg & DPDMA_SR_HALT_MASK) == DPDMA_SR_HALT_MASK);

        return 0;
}

/**
 * dpdma_rx_chan_init - function for initializing the rx channel (s2mm)
 *
 * @lp:          Pointer to dpdma_local structure
 *
 * This is used to initialize rx channel with the configured buffer descriptor
 * for the data to be received from stream to memory (s2mm).
 */
static int dpdma_rx_chan_init(struct dpdma_local *lp)
{
        unsigned int cr_reg;
        unsigned int sr_reg;
        unsigned int uiTimeout;

        /* Updating interrupts in the RX configuration registers */
        cr_reg = dpdma_reg_read(lp, DPDMA_RX_CR_REG);
        cr_reg |= DPDMA_IRQ_ALL_MASK;
        /* Start the dma engine */
        cr_reg |= DPDMA_CR_RUNSTOP_MASK;
        dpdma_reg_write(lp, DPDMA_RX_CR_REG, cr_reg);

        uiTimeout = 1000;
        do {
                /* read the dma status */
                sr_reg = dpdma_reg_read(lp, DPDMA_RX_SR_REG);
                udelay(1);
                if(--uiTimeout == 0) {
                        dev_err(&lp->pdev->dev, "DMA Rx channel Halt timeout\n");
                        break;
                }
        }while((sr_reg & DPDMA_SR_HALT_MASK) == DPDMA_SR_HALT_MASK);

        return 0;
}

/**
 * dpdma_tx_chan_deinit - function for deinitializing the tx channel (mm2s)
 *
 * @lp:          Pointer to dpdma_local structure
 *
 * This is used to deinitialize tx channel memory to stream (mm2s).
 */

static void dpdma_tx_chan_deinit(struct dpdma_local *lp)
{
        unsigned int cr_reg;

        /* disable interrupts in the TX configuration registers */
        cr_reg = dpdma_reg_read(lp, DPDMA_TX_CR_REG);
        cr_reg &= ~DPDMA_IRQ_ALL_MASK;
        /* Stop the dma engine */
        cr_reg &= ~DPDMA_CR_RUNSTOP_MASK;
        dpdma_reg_write(lp, DPDMA_TX_CR_REG, cr_reg);
        
        return ;
}

/**
 * dpdma_rx_chan_deinit - function for deinitializing the rx channel (s2mm)
 *
 * @lp:          Pointer to dpdma_local structure
 *
 * This is used to deinitialize rx channel stream to memory (s2mm).
 */
static void dpdma_rx_chan_deinit(struct dpdma_local *lp)
{
        unsigned int cr_reg;

        /* disable interrupts in the RX configuration registers */
        cr_reg = dpdma_reg_read(lp, DPDMA_RX_CR_REG);
        cr_reg &= ~DPDMA_IRQ_ALL_MASK;
        /* Stop the dma engine */
        cr_reg &= ~DPDMA_CR_RUNSTOP_MASK;
        dpdma_reg_write(lp, DPDMA_RX_CR_REG, cr_reg);

        return ;
}

/**
 * dpdma_core_init - function for initializing the AXI DMA core
 *
 * @lp:          Pointer to dpdma_local structure
 *
 * This is used to initialize the AXI DMA IP core.
 */
static int dpdma_core_init(struct dpdma_local *lp)
{       
        int iRet = 0;
        struct device *dev = &lp->pdev->dev;
        int iIndex;

        /* reset DMA core */
        iRet = dpdma_core_reset(lp);
        if(iRet){
                dev_err(dev, "DMA core reset failed\n");
                return iRet;
        }

        /* Initializing TX channel */
        if(lp->dma_tx_chan > 0){

                lp->tx_buf_size = BD_MAX_SIZE;
                lp->tx_bd_count = BD_MAX_COUNT;

                /* allocating memory for the bd */
                lp->tx_bd = (struct dpdma_bd*)kzalloc(sizeof(struct dpdma_bd) * lp->tx_bd_count, GFP_KERNEL);
                if(!lp->tx_bd) {
                        dev_err(dev, "unable to allocate memory\n");
                        return -ENOMEM;
                }

                /* Allocating contigious memory */
                lp->tx_kern_vir_addr = dma_alloc_coherent(dev, lp->tx_buf_size * lp->tx_bd_count,
                                &lp->tx_dma_addr, GFP_KERNEL);
                if(!lp->tx_kern_vir_addr) {
                        dev_err(dev, "unable to allocate contiguous memory for size %zu\n",
                                        lp->tx_buf_size);
                        return -ENOMEM;
                }

                /* assigning memory to the descriptor form the allocated memory */
                for(iIndex = 0; iIndex < lp->tx_bd_count; iIndex++) {
                        lp->tx_bd[iIndex].kern_addr = lp->tx_kern_vir_addr + (lp->tx_buf_size * iIndex);
                        lp->tx_bd[iIndex].dma_addr = lp->tx_dma_addr + (lp->tx_buf_size * iIndex);
                        lp->tx_bd[iIndex].descriptor = iIndex + 1;
                        lp->tx_bd[iIndex].size = lp->tx_buf_size;
                }

                /* Channel initialization */
                iRet = dpdma_tx_chan_init(lp);
                if(iRet) {
                        dev_err(dev, "failed to initialize DMA Tx channel\n");
                        return -1;
                }
        }

        /* Initializing RX channel */
        if(lp->dma_rx_chan > 0){

                lp->rx_buf_size = BD_MAX_SIZE;
                lp->rx_bd_count = BD_MAX_COUNT;

                /* allocating memory for the bd */
                lp->rx_bd = (struct dpdma_bd*)kzalloc(sizeof(struct dpdma_bd) * lp->rx_bd_count, GFP_KERNEL);
                if(!lp->rx_bd) {
                        dev_err(dev, "unable to allocate memory\n");
                        return -ENOMEM;
                }

                /* Allocating contigious memory */
                lp->rx_kern_vir_addr = dma_alloc_coherent(dev, lp->rx_buf_size * lp->rx_bd_count,
                                &lp->rx_dma_addr, GFP_KERNEL);
                if(!lp->rx_kern_vir_addr) {
                        dev_err(dev, "unable to allocate contiguous memory for size %zu\n",
                                        lp->rx_buf_size);
                        return -ENOMEM;
                }

                 /* assigning memory to the descriptor form the allocated memory */
                for(iIndex = 0; iIndex < lp->rx_bd_count; iIndex++) {
                        lp->rx_bd[iIndex].kern_addr = lp->rx_kern_vir_addr + (lp->rx_buf_size * iIndex);
                        lp->rx_bd[iIndex].dma_addr = lp->rx_dma_addr + (lp->rx_buf_size * iIndex);
                        lp->rx_bd[iIndex].descriptor = iIndex + 1;
                        lp->rx_bd[iIndex].size = lp->rx_buf_size;
                }

                /* Channel initialization */
                iRet = dpdma_rx_chan_init(lp);
                if(iRet) {
                        dev_err(dev, "failed to initialize DMA Rx channel\n");
                        return -1;
                }
        }

        return 0;
}

/**
 * dpdma_core_deinit - function for deinitializing the AXI DMA core
 *
 * @lp:          Pointer to dpdma_local structure
 *
 * This is used to deinitialize the AXI DMA IP core.
 */

static int dpdma_core_deinit(struct dpdma_local *lp)
{
        int iRet = 0;
        struct device *dev = &lp->pdev->dev;

        /* deinitializing TX channel */
        if(lp->dma_tx_chan > 0){
                dma_free_coherent(dev, lp->tx_buf_size * lp->tx_bd_count,
                                lp->tx_kern_vir_addr,
                                lp->tx_dma_addr);
                kfree(lp->tx_bd);

                /* Channel deinitialization */
                dpdma_tx_chan_deinit(lp);
        }

        /* deinitializing RX channel */
        if(lp->dma_rx_chan > 0){
                dma_free_coherent(dev, lp->rx_buf_size * lp->rx_bd_count,
                                lp->rx_kern_vir_addr,
                                lp->rx_dma_addr);
                kfree(lp->rx_bd);

                /* Channel deinitialization */
                dpdma_rx_chan_deinit(lp);
        }

        return 0;
}

/**
 * dpdma_get_tx_phyaddr - function for getting the physical address for the given descriptor
 *
 * @lp:          Pointer to dpdma_local structure
 * @uiDescriptor descriptor number to get the physical address
 * @rpulPhyaddr  Physical address in which the data to be buffered
 *
 * This is used to get the physical address for the given descriptor where the data
 * to be buffered.
 */

static int dpdma_get_tx_phyaddr(struct dpdma_local *lp, unsigned int uiDescriptor,
                unsigned long *pulPhyaddr)
{
        struct list_head *iter;
        struct device *dev = &lp->pdev->dev;
        int iIndex;

        if((uiDescriptor <= 0) || (uiDescriptor > lp->tx_bd_count)){
                dev_err(dev, "Invalid descriptor, Max count %d\n", lp->tx_bd_count);
                return -EINVAL;
        }

        if(lp->tx_bd == NULL){
                dev_err(dev, "Tx buffer descriptor not initialized\n");
                return -ENOMEM;
        }

        // First iterate over DMA buffers allocated by this driver
        for(iIndex = 0; iIndex < lp->tx_bd_count; iIndex++) {
                if(lp->tx_bd[iIndex].descriptor == uiDescriptor){
                        *pulPhyaddr =(unsigned long)lp->tx_bd[iIndex].dma_addr;
                        return 0;
                }
        }
        return -EBADR;
}

/**
 * dpdma_get_rx_phyaddr - function for getting the physical address for the given descriptor
 *
 * @lp:          Pointer to dpdma_local structure
 * @uiDescriptor descriptor number to get the physical address
 * @pulPhyaddr   Physical address in which the data to be buffered
 *
 * This is used to get the physical address for the given descriptor where the data
 * to be buffered.
 */
static int dpdma_get_rx_phyaddr(struct dpdma_local *lp, unsigned int uiDescriptor,
                unsigned long *pulPhyaddr)
{
        struct list_head *iter;
        struct device *dev = &lp->pdev->dev;
        int iIndex;
        if((uiDescriptor <= 0) || (uiDescriptor > lp->rx_bd_count)){
                dev_err(dev, "Invalid descriptor, Max count %d\n", lp->rx_bd_count);
                return -EINVAL;
        }

        if(lp->rx_bd == NULL){
                dev_err(dev, "Rx buffer descriptor not initialized\n");
                return -ENOMEM;
        }

        // First iterate over DMA buffers allocated by this driver
        for(iIndex = 0; iIndex < lp->rx_bd_count; iIndex++) {
                if(lp->rx_bd[iIndex].descriptor == uiDescriptor){
                        *pulPhyaddr =(unsigned long)lp->rx_bd[iIndex].dma_addr;
                        return 0;
                }
        }
        return -EBADR;
}

// ------------------------------------------------------------------------------ //
/**
 * dpdma_rx_irq_handler - rx channel irq hadler (ISR)
 *
 * @return - IRQ_NONE, IRQ_HANDLED
 *
 * This is used to perform operations based on the IRQ received
 * IOC - interrupt on complete: indicates that the data transfer completed
 * ERROR - Indicates that there is an error occured in the DMA core.
 */

static irqreturn_t dpdma_rx_irq_handler(int irq, void *vlp)
{
        struct dpdma_local *lp = vlp;
        unsigned int uiStatus;
        unsigned int cr_reg;

        uiStatus = dpdma_reg_read(lp, DPDMA_RX_SR_REG);
        if(uiStatus & DPDMA_IRQ_IOC_MASK) {

                // -- waking up the wait quque
                lp->m_irxWaitqueue_flag = 1;
                wake_up_interruptible(&lp->m_rxwaitqueue);

                /* clear the pending interrupt */
                dpdma_reg_write(lp, DPDMA_RX_SR_REG, uiStatus);
        }

        if(!(uiStatus & DPDMA_IRQ_ALL_MASK)){
                return IRQ_NONE;
        }

        if(uiStatus & DPDMA_IRQ_ERROR_MASK) {

                dev_err(&lp->pdev->dev, "DMA Rx error 0x%x\n", uiStatus);

                cr_reg = dpdma_reg_read(lp, DPDMA_RX_CR_REG);
                /* Disable all the interrupts */
                cr_reg &= ~DPDMA_IRQ_ALL_MASK;
                dpdma_reg_write(lp, DPDMA_RX_CR_REG, cr_reg);

                cr_reg = dpdma_reg_read(lp, DPDMA_TX_CR_REG);
                /* Disable all the interrupts */
                cr_reg &= ~DPDMA_IRQ_ALL_MASK;
                dpdma_reg_write(lp, DPDMA_TX_CR_REG, cr_reg);

                /* Scheduling tasklet for error handling */
                tasklet_schedule(&lp->rx_dma_err_tasklet);

                /* clear the pending interrupt */
                dpdma_reg_write(lp, DPDMA_RX_SR_REG, uiStatus);

        }

        return IRQ_HANDLED;
}
/**
 * dpdma_tx_irq_handler - tx channel irq hadler (ISR)
 *
 * @return - IRQ_NONE, IRQ_HANDLED
 *
 * This is used to perform operations based on the IRQ received
 * IOC - interrupt on complete: indicates that the data transfer completed
 * ERROR - Indicates that there is an error occured in the DMA core.
 */
static irqreturn_t dpdma_tx_irq_handler(int irq, void *vlp)
{
        struct dpdma_local *lp = vlp;
        unsigned int uiStatus;
        unsigned int cr_reg;

        uiStatus = dpdma_reg_read(lp, DPDMA_TX_SR_REG);
        if(uiStatus & DPDMA_IRQ_IOC_MASK) {

                // -- waking up the wait quque
                lp->m_itxWaitqueue_flag = 1;
                wake_up_interruptible(&lp->m_txwaitqueue);

                /* clear the pending interrupt */
                dpdma_reg_write(lp, DPDMA_TX_SR_REG, uiStatus);
        }

        if(!(uiStatus & DPDMA_IRQ_ALL_MASK)){
                return IRQ_NONE;
        }

        if(uiStatus & DPDMA_IRQ_ERROR_MASK) {

                dev_err(&lp->pdev->dev, "DMA Tx error 0x%x\n", uiStatus);

                cr_reg = dpdma_reg_read(lp, DPDMA_TX_CR_REG);
                /* Disable all the interrupts */
                cr_reg &= ~DPDMA_IRQ_ALL_MASK;
                dpdma_reg_write(lp, DPDMA_TX_CR_REG, cr_reg);

                cr_reg = dpdma_reg_read(lp, DPDMA_RX_CR_REG);
                /* Disable all the interrupts */
                cr_reg &= ~DPDMA_IRQ_ALL_MASK;
                dpdma_reg_write(lp, DPDMA_RX_CR_REG, cr_reg);

                /* Scheduling tasklet for error handling */
                tasklet_schedule(&lp->tx_dma_err_tasklet);
                /* clear the pending interrupt */
                dpdma_reg_write(lp, DPDMA_TX_SR_REG, uiStatus);
        }

        return IRQ_HANDLED;
}

/**
 * dpdma_err_handler - error handler
 *
 * This function is invoked from the ISR when IRQ_ERROR occured.
 * This will reset the core and initialize it with the current
 * settings.
 */

void __maybe_unused dpdma_err_handler(unsigned long data)
{
        int iRet;
        unsigned int cr_reg;
        unsigned int sr_reg;
        unsigned int uiTimeout;
        struct dpdma_local *lp = (struct dpdma_local *)data;

        /* resetting DMA core */
        dpdma_core_reset(lp);

        /* Start updating the Rx channel control register */
        cr_reg = dpdma_reg_read(lp, DPDMA_RX_CR_REG);
        /* Enabling Interrupts */
        cr_reg |= DPDMA_IRQ_ALL_MASK;
        /* Start the dma engine */
        cr_reg |= DPDMA_CR_RUNSTOP_MASK;
        dpdma_reg_write(lp, DPDMA_RX_CR_REG, cr_reg);

        /* check the DMA halt status */
        uiTimeout = 1000;
        do {
                /* read the dma status */
                sr_reg = dpdma_reg_read(lp, DPDMA_RX_SR_REG);
                udelay(1);
                if(--uiTimeout == 0) {
                        dev_err(&lp->pdev->dev, "DMA Rx channel Halt timeout\n");
                        return;
                }

        }while((sr_reg & DPDMA_SR_HALT_MASK) == DPDMA_SR_HALT_MASK);

        /* update the last used dma address in the dma engine*/
        /* write the valid destination address*/
        dpdma_reg_write(lp, DPDMA_RX_DA_LSB_REG,
                        (unsigned int)(lp->rx_curr_bd_addr & 0xffffffff));
        if(lp->dma_mask == 64)
                dpdma_reg_write(lp, DPDMA_RX_DA_MSB_REG,
                                (unsigned int)((lp->rx_curr_bd_addr >> 32) & 0xffffffff));

        /* Start updating the Tx channel control register */
        cr_reg = dpdma_reg_read(lp, DPDMA_TX_CR_REG);
        /* Enabling Interrupts */
        cr_reg |= DPDMA_IRQ_ALL_MASK;
        /* Start the dma engine */
        cr_reg |= DPDMA_CR_RUNSTOP_MASK;
        dpdma_reg_write(lp, DPDMA_TX_CR_REG, cr_reg);

        /* update the last used dma address in the dma engine*/
        /* check the DMA halt status */
        uiTimeout = 1000;
        do {
                /* read the dma status */
                sr_reg = dpdma_reg_read(lp, DPDMA_TX_SR_REG);
                udelay(1);
                if(--uiTimeout == 0) {
                        dev_err(&lp->pdev->dev, "DMA Tx channel Halt timeout\n");
                        return;
                }

        }while((sr_reg & DPDMA_SR_HALT_MASK) == DPDMA_SR_HALT_MASK);

        /* write the valid destination address*/
        dpdma_reg_write(lp, DPDMA_TX_SA_LSB_REG,
                        (unsigned int)(lp->tx_curr_bd_addr & 0xffffffff));
        if(lp->dma_mask == 64)
                dpdma_reg_write(lp, DPDMA_TX_SA_MSB_REG,
                                (unsigned int)((lp->tx_curr_bd_addr >> 32) & 0xffffffff));

        return;
}

/**
 * dpdma_rx_eventwait - function for notifying the user space
 *
 * @return      DP_EVENT_CONDITION upon IRQ_IOC occurred
 *              DP_EVENT_TIMEOUT upon timeout occurrs
 *
 * This will notify the user space when DPDMA_RX_IRQWAIT IOCTL
 * is called in the user space upon receiving IRQ_IOC.
 */

static int dpdma_rx_eventwait(struct dpdma_local *lp, unsigned long ulTimeout)
{
        int iStatus = 0;

        lp->m_irxWaitqueue_flag = 0;
        do {
                wait_event_interruptible_timeout(lp->m_rxwaitqueue,
                                (lp->m_irxWaitqueue_flag != 0),
                                msecs_to_jiffies(ulTimeout));

                if(lp->m_irxWaitqueue_flag != 0) {
                        iStatus = DP_EVENT_CONDITION;
                        break;
                }

                iStatus = DP_EVENT_TIMEOUT;
                break;
        }while(0);
        return iStatus;
}

/**
 * dpdma_tx_eventwait - function for notifying the user space
 *
 * @return      DP_EVENT_CONDITION upon IRQ_IOC occurred
 *              DP_EVENT_TIMEOUT upon timeout occurrs
 *
 * This will notify the user space when DPDMA_TX_IRQWAIT IOCTL
 * is called in the user space upon receiving IRQ_IOC.
 */

static int dpdma_tx_eventwait(struct dpdma_local *lp, unsigned long ulTimeout)
{
        int iStatus = 0;

        lp->m_itxWaitqueue_flag = 0;
        do {
                wait_event_interruptible_timeout(lp->m_txwaitqueue,
                                (lp->m_itxWaitqueue_flag != 0),
                                msecs_to_jiffies(ulTimeout));

                if(lp->m_itxWaitqueue_flag != 0) {
                        iStatus = DP_EVENT_CONDITION;
                        break;
                }

                iStatus = DP_EVENT_TIMEOUT;
                break;
        }while(0);
        return iStatus;
}

/**
 * dpdma_open - Driver open routine.
 * @in_pInode:	Pointer to inode structure
 * @in_pfile:   Pointer to file structure
 *
 * Return: 0, on success.
 *	    non-zero error value on failure
 *
 * This is the driver open routine. it allocates interrupt service routines, 
 * enables the interrupt lines and ISR handling. Resets the DMA core
 */
static int dpdma_open (struct inode *in_pInode, struct file *in_pfile)
{
        struct dpdma_local *lp;
        int iRet = 0;
        struct device_node *np = NULL;
        struct device *dev = NULL;
        char dev_name[20] = {0};

        lp = container_of(in_pInode->i_cdev, struct dpdma_local, cdev);
        in_pfile->private_data = lp;
        dev = &lp->pdev->dev;
        np = lp->pdev->dev.of_node;

        /* requesting S2MM(Rx) interrupt */
        if((lp->dma_rx_chan > 0) && lp->rx_irq > 0){

                /* Initializing tasklet for error handling  */
                tasklet_init(&lp->rx_dma_err_tasklet,
                                dpdma_err_handler, 
                                (unsigned long)lp);

                iRet = request_irq(lp->rx_irq, dpdma_rx_irq_handler,
                                IRQF_TRIGGER_HIGH | IRQF_SHARED,
                                np->name, lp);
                if(iRet){
                        dev_err(dev, "request irq for %s rx channel failed\n",
                                        np->name);
                }
        }

        /* requesting MM2S(Tx) interrupt */
        if((lp->dma_tx_chan > 0) && lp->tx_irq > 0){

                /* Initializing tasklet for error handling  */
                tasklet_init(&lp->tx_dma_err_tasklet,
                                dpdma_err_handler, 
                                (unsigned long)lp);

                iRet = request_irq(lp->tx_irq, dpdma_tx_irq_handler,
                                IRQF_TRIGGER_HIGH | IRQF_SHARED,
                                np->name, lp);
                if(iRet){
                        dev_err(dev, "request irq for %s tx channel failed\n",
                                        np->name);
                }
        }

        /* Initializing DMA core */
        dpdma_core_init(lp);

        /* Initializing wait quque */
        lp->m_itxWaitqueue_flag = 0;
        init_waitqueue_head(&lp->m_txwaitqueue);
        lp->m_irxWaitqueue_flag = 0;
        init_waitqueue_head(&lp->m_rxwaitqueue);

        return 0;
}


/**
 * dpdma_release - Driver release routine.
 * @in_pInode:  Pointer to inode structure
 * @in_pfile:   Pointer to file structure
 *
 * Return: 0, on success.
 *
 * This is the driver stop routine. It removes the interrupt handlers
 * and disables the interrupts.
 */
static int dpdma_release (struct inode *in_pInode, struct file *in_pfile)
{
        struct dpdma_local *lp;
        lp = in_pfile->private_data;

        if((lp->dma_rx_chan > 0) && lp->rx_irq > 0){
                free_irq(lp->rx_irq, lp);
        }
        if((lp->dma_tx_chan > 0) && lp->tx_irq > 0){
                free_irq(lp->tx_irq, lp);
        }

        dpdma_core_deinit(lp);
        in_pfile->private_data = NULL;

        return 0;
}

/**
 * dpdma_mmap - mmap function.
 * @file:  Pointer to file structure
 * @vma:   Pointer to vma_area_strct structure
 *
 * Return: 0, on success.
 *  Non-zero error value on failure.
 *
 * This is the mmap callback function. This is called when mmap function
 * is called from the user space. It will get the user virtual address
 * and size, allocate a region of contiguous memory and map the contiguous
 * memory with the user virtual memory.
 */
static int dpdma_mmap(struct file * file, struct vm_area_struct * vma)
{
        struct dpdma_alloc *mem_alloc = NULL;
        int err;
        struct dpdma_local *lp = file->private_data;
        struct device *dev = &lp->pdev->dev;
        unsigned long phyaddr = vma->vm_pgoff << PAGE_SHIFT;

        /* map the region to userspace*/
        vma->vm_flags    |= VM_IO;
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);

        err = remap_pfn_range(vma,
                        vma->vm_start,
                        vma->vm_pgoff,  //pfn
                        vma->vm_end - vma->vm_start,
                        vma->vm_page_prot);
        if(err < 0) {
                dev_err(dev, "Unable to remap address %lx to userspace address %lx, size "
                                "%ld.\n", phyaddr, vma->vm_start,
                                vma->vm_end - vma->vm_start);
                return err;
        }

        return 0;
}

/**
 * dpdma_ioctl - ioctl function.
 * @file:  Pointer to file structure
 * @cmd:   IOCTL command
 * @arg:   arguments form the user space
 *
 * Return: 0, on success.
 *  Non-zero error value on failure.
 *
 * This is the ioctl callback function. This is called when ioctl function
 * is called in the user space. perform operations based on the IOCTL commands
 * sent from the user space and the process the data present in the arg.
 */
static long dpdma_ioctl (struct file *filp, unsigned int cmd, 
                unsigned long arg)
{      
        int iRet = 0; 
        void *pvBuffer = NULL;
        unsigned int uiOffset = 0;
        unsigned int uiData = 0;
        char send_flag = 0;
        struct dpdma_local *lp = filp->private_data;

        pvBuffer = kzalloc(_IOC_SIZE(cmd), GFP_KERNEL);
        if(!pvBuffer){
                return -ENOMEM;
        }

        if((copy_from_user((unsigned long*)pvBuffer, (unsigned long*)arg,
                                        _IOC_SIZE(cmd)))) {
                iRet = -EFAULT;
        }

        switch (cmd)
        {
                case DPDMA_GET_TX_PHYADDR: // get tx_physical address

                        iRet = dpdma_get_tx_phyaddr(lp, 
                                        ((struct dpdma_phyaddr*)pvBuffer)->uiDescriptor,
                                        ((struct dpdma_phyaddr*)pvBuffer)->pulPhyAddr);
                        send_flag = 1;
                        break;

                case DPDMA_GET_RX_PHYADDR: // get tx_physical address

                        iRet = dpdma_get_rx_phyaddr(lp, 
                                        ((struct dpdma_phyaddr*)pvBuffer)->uiDescriptor,
                                        ((struct dpdma_phyaddr*)pvBuffer)->pulPhyAddr);
                        send_flag = 1;
                        break;

                case DPDMA_TX_CONFIG: // config

                        iRet = dpdma_tx_config(lp,*((unsigned int*)pvBuffer));
                        break;

                case DPDMA_RX_CONFIG: // config

                        iRet = dpdma_rx_config(lp,*((unsigned int*)pvBuffer));
                        break;

                case DPDMA_TX_XMIT: 

                        iRet = dpdma_tx_xmit(lp,*((unsigned int*)pvBuffer));
                        break;

                case DPDMA_RX_XMIT: 

                        iRet = dpdma_rx_xmit(lp,*((unsigned int*)pvBuffer));
                        break;

                case DPDMA_TX_IRQWAIT: // irq event wait

                        iRet = dpdma_tx_eventwait(lp,*((unsigned long*)pvBuffer));
                        break;
                
                case DPDMA_RX_IRQWAIT: // irq event wait

                        iRet = dpdma_rx_eventwait(lp,*((unsigned long*)pvBuffer));
                        break;


                default:
                        pr_info("Invalid IOCTL\n");
                        iRet = -EINVAL;
                        break;
        }

        if(send_flag == 1) {
                if((copy_to_user((unsigned long*)arg, (unsigned long*)pvBuffer,
                                                _IOC_SIZE(cmd)))) {
                        iRet = -EFAULT;
                }
        }

        if(pvBuffer)
                kfree(pvBuffer);
        return iRet;
}

static struct file_operations dpdma_fops = {
        .open = dpdma_open,
        .release = dpdma_release,
        .unlocked_ioctl = dpdma_ioctl,
        .mmap = dpdma_mmap,
        .owner = THIS_MODULE,
};

/**
 * dpdma_reg_chrdev - char device register function.
 * @pdev:  Pointer to platform_device structure
 *
 * Return: 0, on success.
 *  Non-zero error value on failure.
 *
 * This is the char device register routine. It registers the dma device
 * with the kernel and creates a device file.
 */
static int dpdma_reg_chrdev(struct platform_device *pdev)
{
        int iRet = 0;
        dev_t dev_num = 0;
        struct dpdma_local *lp = platform_get_drvdata(pdev);
        struct device_node *np = pdev->dev.of_node;

        iRet = alloc_chrdev_region(&dev_num, 0, 1, np->name);
        if(iRet != 0) {
                return iRet;
        }

        lp->dev_num = dev_num;
        lp->major_num = MAJOR(dev_num);
        lp->minor_num = MINOR(dev_num);

        cdev_init(&lp->cdev, &dpdma_fops);
        iRet = cdev_add(&lp->cdev, lp->dev_num, 1);
        if(iRet != 0) {
                unregister_chrdev_region(lp->dev_num, 1);
                return iRet;
        }

        if(IS_ERR(lp->class = class_create(THIS_MODULE, np->name))) {
                cdev_del(&lp->cdev);
                unregister_chrdev_region(lp->dev_num, 1);
                return -EINVAL;
        }

        if(IS_ERR(device_create(lp->class, NULL, lp->dev_num, NULL,
                                        np->name))) {
                class_destroy(lp->class);
                cdev_del(&lp->cdev);
                unregister_chrdev_region(lp->dev_num, 1);
                return -EINVAL;
        }

        return 0;
}

/**
 * dpdma_unreg_chrdev - char device unregister function.
 * @pdev:  Pointer to platform_device structure
 *
 * This is the char device unregister routine. It unregisters the dma device
 * with the kernel and removes the device file.
 */
static void dpdma_unreg_chrdev(struct platform_device *pdev)
{
        struct dpdma_local *lp = platform_get_drvdata(pdev);

        device_destroy(lp->class, lp->dev_num);
        class_destroy(lp->class);
        cdev_del(&lp->cdev);
        unregister_chrdev_region(lp->dev_num, 1);
        return;
}


/**
 * dpdma_probe - probe function.
 * @pdev:	Pointer to platform device structure.
 *
 * Return: 0, on success
 *	    Non-zero error value on failure.
 *
 * This is the probe routine for DMA driver. This is called before
 * any other driver routines are invoked. It allocates and sets up the DMA
 * device. Parses through device tree and populates the local structure.
 * It registers the dma device.
 */
static int dpdma_probe(struct platform_device *pdev)
{
        int iRet = 0;
        struct dpdma_local *lp;
        struct device_node *child_node;
        struct resource r_mem; /* IO mem resources */
        struct device *dev = &pdev->dev;
        struct of_phandle_args phandle_args;
        int iChan = 0;

        /* Allocate memory to the local pointer */
        lp = devm_kzalloc(&pdev->dev, sizeof(struct dpdma_local), GFP_KERNEL);
        if(!lp) {
                return -ENOMEM;
        }

        lp->pdev = pdev;
        lp->node = of_parse_phandle(pdev->dev.of_node, "connected-stream", iChan);
        if(lp->node == NULL){
                dev_err(dev, "failed to parse phandle for channel %d\n", iChan);
                return -ENODEV;
        }

        // get IO memory space
        iRet = of_address_to_resource(lp->node, 0, &r_mem);
        if(iRet < 0) {
                dev_err(dev, "unable to get DMA resources\n");
                return -ENODEV;
        }

        lp->mem_start = r_mem.start;
        lp->mem_end = r_mem.end;
        lp->mem_size = resource_size(&r_mem);

        /* mapping the IO memory to the virtual space*/
        lp->regs = devm_ioremap(dev, lp->mem_start, lp->mem_size);
        if (!lp->regs) {
                dev_err(dev, "unable to map DMA resources\n");
                return -ENOMEM;
        }

        /* setting DMA mask */
        lp->dma_mask = 32;

        iRet = dma_set_mask_and_coherent(dev, DMA_BIT_MASK(lp->dma_mask));
        if(iRet != 0){
                dev_err(dev, "dma_set_mask_and_coherent failed, aborting\n");
                return iRet;
        }

        /* parsing the child nodes */
        for_each_child_of_node (lp->node, child_node){
                if (of_device_is_compatible(child_node, "xlnx,axi-dma-mm2s-channel") > 0) {
                        lp->dma_chan_count += 1;
                        lp->dma_tx_chan = 1;

                        // Channel Interrupt
                        lp->tx_irq = irq_of_parse_and_map(child_node, 0);
                        if(lp->tx_irq <= 0) {
                                dev_err(dev, "irq number for tx channel is not available");
                                return -EINVAL;
                        }

                        pr_info("%s irq number for axi-dma-mm2s-channel - %d \n", pdev->dev.of_node->name, lp->tx_irq);
                } 
                else if (of_device_is_compatible(child_node, "xlnx,axi-dma-s2mm-channel") > 0) {
                        lp->dma_chan_count += 1;
                        lp->dma_rx_chan = 1;

                        // Channel Interrupt
                        lp->rx_irq = irq_of_parse_and_map(child_node, 0);
                        if(lp->rx_irq <= 0) {
                                dev_err(dev, "irq number for rx channel is not available");
                                return -EINVAL;
                        }
                        pr_info("%s irq number for  axi-dma-s2mm-channel - %d \n", pdev->dev.of_node->name, lp->rx_irq);
                } 
                else {
                }
        }

        platform_set_drvdata(pdev, lp);

        // register chrdev
        iRet = dpdma_reg_chrdev(pdev);
        if(iRet){
                dev_err(dev, "failed to register chrdev\n");
                platform_set_drvdata(pdev, NULL);
                return iRet;
        }

        return 0;
}

/**
 * dpdma_remove - remove function.
 * @pdev:	Pointer to platform device structure.
 *
 * Return: 0, on success
 *	    Non-zero error value on failure.
 *
 * This is the remove routine for DMA driver. This is called when the driver
 * got removed, it deletes the dma device file.
 */
static int dpdma_remove(struct platform_device *pdev)
{
        dpdma_unreg_chrdev(pdev);
        return 0;
}


static struct of_device_id dpdma_of_match[] = {
        { .compatible = "dp,dma-0v02", },
        {},
};
MODULE_DEVICE_TABLE(of, dpdma_of_match);

static struct platform_driver dpdma_driver = {
        .driver = {
                .name = DRIVER_NAME,
                .owner = THIS_MODULE,
                .of_match_table	= dpdma_of_match,
        },
        .probe		= dpdma_probe,
        .remove		= dpdma_remove,
};

static int __init dpdma_init(void)
{
        return platform_driver_register(&dpdma_driver);
}

static void __exit dpdma_exit(void)
{
        platform_driver_unregister(&dpdma_driver);
}

module_init(dpdma_init);
module_exit(dpdma_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Data Patterns India Ltd., Vishnu Ram G");
MODULE_DESCRIPTION("AXI DMA driver for zynq MPSoC/RFSoC");
