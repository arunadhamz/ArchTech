#ifndef DPDMA_H
#define DPDMA_H

#define BD_MAX_COUNT                    5

#define DPDMA_MM2S_BASE                 0x0
#define DPDMA_S2MM_BASE                 0x30

#define DPDMA_TX_CR_REG               DPDMA_MM2S_BASE + 0x00 /* Channel control */
#define DPDMA_TX_SR_REG               DPDMA_MM2S_BASE + 0x04 /* Status */
#define DPDMA_TX_SA_LSB_REG           DPDMA_MM2S_BASE + 0x18 /* Source Address */
#define DPDMA_TX_SA_MSB_REG           DPDMA_MM2S_BASE + 0x1C /* Source Address MSB*/
#define DPDMA_TX_LENGTH_REG           DPDMA_MM2S_BASE + 0x28 /* Length */

#define DPDMA_RX_CR_REG               DPDMA_S2MM_BASE + 0x00 /* Channel control */
#define DPDMA_RX_SR_REG               DPDMA_S2MM_BASE + 0x04 /* Status */
#define DPDMA_RX_DA_LSB_REG           DPDMA_S2MM_BASE + 0x18 /* Destination Address */
#define DPDMA_RX_DA_MSB_REG           DPDMA_S2MM_BASE + 0x1C /* Destination Address MSB*/
#define DPDMA_RX_LENGTH_REG           DPDMA_S2MM_BASE + 0x28 /* Length */

#define DPDMA_CR_RUNSTOP_MASK		0x00000001 /* Start/stop DMA channel */
#define DPDMA_CR_RESET_MASK		0x00000004 /* Reset DMA engine */

#define DPDMA_SR_HALT_MASK		0x00000001 /* Indicates DMA channel halted */

#define DPDMA_IRQ_IOC_MASK		0x00001000 /* Completion intr */
#define DPDMA_IRQ_ERROR_MASK		0x00004000 /* Error interrupt */
#define DPDMA_IRQ_ALL_MASK		0x00005000 /* All interrupts */

#endif
