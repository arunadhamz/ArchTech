#ifndef DPDMA_LIB_H
#define DPDMA_LIB_H

#define DP_EVENT        1

unsigned int dpdma_open(char *pszDeviceName);
void dpdma_close(unsigned int uiHandle);
int dpdma_get_tx_phyaddr(unsigned int uiHandle, unsigned int uiDescriptor, unsigned long *pulPhyAddr);
int dpdma_get_rx_phyaddr(unsigned int uiHandle, unsigned int uiDescriptor, unsigned long *pulPhyAddr);
int dpdma_tx_config(unsigned int uiHandle, unsigned int uiDescriptor);
int dpdma_rx_config(unsigned int uiHandle, unsigned int uiDescriptor);
int dpdma_tx_xmit(unsigned int uiHandle, unsigned int uiSize);
int dpdma_rx_xmit(unsigned int uiHandle, unsigned int uiSize);
int dpdma_tx_eventwait(unsigned int uiHandle, unsigned long ulTimeout);
int dpdma_rx_eventwait(unsigned int uiHandle, unsigned long ulTimeout);


#endif
