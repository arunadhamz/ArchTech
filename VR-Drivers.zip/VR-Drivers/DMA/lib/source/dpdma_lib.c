#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "../../dpdma_ioctl.h"
#include <dpdma_lib.h>

unsigned int dpdma_open(char *pszDeviceName)
{
        unsigned int uiHandle = 0;

        if(!pszDeviceName) {
                printf("Invalid pointer\n");
                return -1;
        }

        uiHandle = open(pszDeviceName, O_RDWR);
	if(uiHandle < 0){
		perror("open() ");
	        printf("failed to open %s\n", pszDeviceName);
                return -1;
        }

        return uiHandle;
}

void dpdma_close(unsigned int uiHandle)
{
        if(uiHandle < 0) {
                printf("Invalid Handle\n");
        }else {
                close(uiHandle);
        }
        return;
}

int dpdma_get_rx_phyaddr(unsigned int uiHandle, unsigned int uiDescriptor, unsigned long *pulPhyAddr)
{
        int err = 0;
        struct dpdma_phyaddr addrinfo = {0};

        if(uiHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        if(!(pulPhyAddr)){
                printf("Invalid Pointer\n");
                return -1;
        }

        addrinfo.uiDescriptor = uiDescriptor;
        addrinfo.pulPhyAddr = pulPhyAddr;

        err = ioctl(uiHandle, DPDMA_GET_RX_PHYADDR, (unsigned long *)&addrinfo);
        if(err != 0) {
                perror("ioctl() ");
                printf("failed to get rx DMA physical address\n");
                return -1;
        }

        return 0;
}

int dpdma_get_tx_phyaddr(unsigned int uiHandle, unsigned int uiDescriptor, unsigned long *pulPhyAddr)
{
        int err = 0;
        struct dpdma_phyaddr addrinfo = {0};

        if(uiHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        if(!(pulPhyAddr)){
                printf("Invalid Pointer\n");
                return -1;
        }

        addrinfo.uiDescriptor = uiDescriptor;
        addrinfo.pulPhyAddr = pulPhyAddr;

        err = ioctl(uiHandle, DPDMA_GET_TX_PHYADDR, (unsigned long *)&addrinfo);
        if(err != 0) {
                perror("ioctl() ");
                printf("failed to get tx DMA physical address\n");
                return -1;
        }

        return 0;
}

int dpdma_tx_config(unsigned int uiHandle, unsigned int uiDescriptor)
{
        int err = 0;

        if(uiHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        err = ioctl(uiHandle, DPDMA_TX_CONFIG, (unsigned long *)&uiDescriptor);
        if(err != 0) {
                perror("ioctl() ");
                printf("failed to config tx DMA channel\n");
                return -1;
        }

        return 0;
}

int dpdma_rx_config(unsigned int uiHandle, unsigned int uiDescriptor)
{
        int err = 0;

        if(uiHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        err = ioctl(uiHandle, DPDMA_RX_CONFIG, (unsigned long *)&uiDescriptor);
        if(err != 0) {
                perror("ioctl() ");
                printf("failed to config rx DMA channel\n");
                return -1;
        }

        return 0;
}


int dpdma_tx_xmit(unsigned int uiHandle, unsigned int uiSize)
{
        int err = 0;

        if(uiHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        err = ioctl(uiHandle, DPDMA_TX_XMIT, (unsigned long *)&uiSize);
        if(err != 0) {
                perror("ioctl() ");
                printf("failed to start tx DMA channel\n");
                return -1;
        }

        return 0;
}

int dpdma_rx_xmit(unsigned int uiHandle, unsigned int uiSize)
{
        int err = 0;

        if(uiHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        err = ioctl(uiHandle, DPDMA_RX_XMIT, (unsigned long *)&uiSize);
        if(err != 0) {
                perror("ioctl() ");
                printf("failed to start rx DMA channel\n");
                return -1;
        }

        return 0;
}

int dpdma_tx_eventwait(unsigned int uiHandle, unsigned long ulTimeout)
{
        int err = 0;

        if(uiHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        err = ioctl(uiHandle, DPDMA_TX_IRQWAIT, &ulTimeout);
        if(err < 0) {
                perror("ioctl() ");
                printf("DMA event waitfailed\n");
                return -1;
        }

        if(err == DP_EVENT_CONDITION)
                return DP_EVENT;

        return 0;

}
int dpdma_rx_eventwait(unsigned int uiHandle, unsigned long ulTimeout)
{
        int err = 0;

        if(uiHandle < 0) {
                printf("Invalid Handle\n");
                return -1;
        }

        err = ioctl(uiHandle, DPDMA_RX_IRQWAIT, &ulTimeout);
        if(err < 0) {
                perror("ioctl() ");
                printf("DMA event waitfailed\n");
                return -1;
        }

        if(err == DP_EVENT_CONDITION)
                return DP_EVENT;

        return 0;

}
