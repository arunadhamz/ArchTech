/*
 * Definitions for Axi Ethernet device driver.
 *
 * <pre>
 * MODIFICATION HISTORY:
 *
 * Ver   Who    	   Date        Changes
 * ----- ----------------- ----------  ---------------------------------------
 * 1V00  Vishnu Ram (2364) 04/09/2024  Initial Version
 *
 * </pre>
 *
 */

#ifndef XILINX_AXIENET_H
#define XILINX_AXIENET_H

#include <linux/netdevice.h>
#include <linux/spinlock.h>
#include <linux/interrupt.h>
#include <linux/if_vlan.h>
#include <linux/net_tstamp.h>
#include <linux/phy.h>
#include <linux/of_platform.h>

// --------------------------------------------------------------------------------------------------

#define DPETH_MAC_MSB				0xC0
#define DPETH_MAC_LSB				0xC4

#define DPETH_FIFO_DATA_WR			0xC8
#define DPETH_FIFO_COUNT_WR			0xCC
#define DPETH_FIFO_COUNT_RD			0xD8
#define DPETH_FIFO_RESET			0xD0

#define DPETH_PCSPMA_RESET			0xD4
#define DPETH_PCSPMA_STATUS			0xDC

// --------------------------------------------------------------------------------------------------
/* Packet size info */
#define XAE_HDR_SIZE				14 /* Size of Ethernet header */
#define XAE_TRL_SIZE			 	4 /* Size of Ethernet trailer (FCS) */
#define XAE_MTU			      		1500 /* Max MTU of an Ethernet frame */
#define XAE_JUMBO_MTU		      	9000 /* Max MTU of a jumbo Eth. frame */

#define XAE_MAX_FRAME_SIZE	 		(XAE_MTU + XAE_HDR_SIZE + XAE_TRL_SIZE)
#define XAE_MAX_VLAN_FRAME_SIZE  	(XAE_MTU + VLAN_ETH_HLEN + XAE_TRL_SIZE)
#define XAE_MAX_JUMBO_FRAME_SIZE 	(XAE_JUMBO_MTU + XAE_HDR_SIZE + XAE_TRL_SIZE)

/* DMA address width min and max range */
#define XAE_DMA_MASK_MIN			32
#define XAE_DMA_MASK_MAX			64

/* In AXI DMA Tx and Rx queue count is same */
#define for_each_tx_dma_queue(lp, var) \
        for ((var) = 0; (var) < (lp)->num_tx_queues; (var)++)

#define for_each_rx_dma_queue(lp, var) \
        for ((var) = 0; (var) < (lp)->num_rx_queues; (var)++)

/* Axi DMA Register definitions */

#define XAXIDMA_TX_CR_OFFSET		0x00000000 /* Channel control */
#define XAXIDMA_TX_SR_OFFSET		0x00000004 /* Status */
#define XAXIDMA_TX_CDESC_OFFSET		0x00000008 /* Current descriptor pointer */
#define XAXIDMA_TX_TDESC_OFFSET		0x00000010 /* Tail descriptor pointer */

#define XAXIDMA_RX_CR_OFFSET		0x00000030 /* Channel control */
#define XAXIDMA_RX_SR_OFFSET		0x00000034 /* Status */
#define XAXIDMA_RX_CDESC_OFFSET		0x00000038 /* Current descriptor pointer */
#define XAXIDMA_RX_TDESC_OFFSET		0x00000040 /* Tail descriptor pointer */

#define XAXIDMA_CR_RUNSTOP_MASK		0x00000001 /* Start/stop DMA channel */
#define XAXIDMA_CR_RESET_MASK		0x00000004 /* Reset DMA engine */

#define XAXIDMA_SR_HALT_MASK		0x00000001 /* Indicates DMA channel halted */

#define XAXIDMA_BD_NDESC_OFFSET		0x00 /* Next descriptor pointer */
#define XAXIDMA_BD_BUFA_OFFSET		0x08 /* Buffer address */
#define XAXIDMA_BD_CTRL_LEN_OFFSET	0x18 /* Control/buffer length */
#define XAXIDMA_BD_STS_OFFSET		0x1C /* Status */
#define XAXIDMA_BD_USR0_OFFSET		0x20 /* User IP specific word0 */
#define XAXIDMA_BD_USR1_OFFSET		0x24 /* User IP specific word1 */
#define XAXIDMA_BD_USR2_OFFSET		0x28 /* User IP specific word2 */
#define XAXIDMA_BD_USR3_OFFSET		0x2C /* User IP specific word3 */
#define XAXIDMA_BD_USR4_OFFSET		0x30 /* User IP specific word4 */
#define XAXIDMA_BD_ID_OFFSET		0x34 /* Sw ID */
#define XAXIDMA_BD_HAS_STSCNTRL_OFFSET	0x38 /* Whether has stscntrl strm */
#define XAXIDMA_BD_HAS_DRE_OFFSET	0x3C /* Whether has DRE */

#define XAXIDMA_BD_HAS_DRE_SHIFT	8 /* Whether has DRE shift */
#define XAXIDMA_BD_HAS_DRE_MASK		0xF00 /* Whether has DRE mask */
#define XAXIDMA_BD_WORDLEN_MASK		0xFF /* Whether has DRE mask */

#define XAXIDMA_BD_CTRL_LENGTH_MASK	0x007FFFFF /* Requested len */
#define XAXIDMA_BD_CTRL_TXSOF_MASK	0x08000000 /* First tx packet */
#define XAXIDMA_BD_CTRL_TXEOF_MASK	0x04000000 /* Last tx packet */
#define XAXIDMA_BD_CTRL_ALL_MASK	0x0C000000 /* All control bits */

#define XAXIDMA_DELAY_MASK			0xFF000000 /* Delay timeout counter */
#define XAXIDMA_COALESCE_MASK		0x00FF0000 /* Coalesce counter */

#define XAXIDMA_DELAY_SHIFT			24
#define XAXIDMA_COALESCE_SHIFT		16

#define XAXIDMA_IRQ_IOC_MASK		0x00001000 /* Completion intr */
#define XAXIDMA_IRQ_DELAY_MASK		0x00002000 /* Delay interrupt */
#define XAXIDMA_IRQ_ERROR_MASK		0x00004000 /* Error interrupt */
#define XAXIDMA_IRQ_ALL_MASK		0x00007000 /* All interrupts */

/* Default TX/RX Threshold and waitbound values for SGDMA mode */
#define XAXIDMA_DFT_TX_THRESHOLD	24
#define XAXIDMA_DFT_TX_WAITBOUND	254
#define XAXIDMA_DFT_RX_THRESHOLD	1
#define XAXIDMA_DFT_RX_WAITBOUND	254

#define XAXIDMA_BD_CTRL_TXSOF_MASK	0x08000000 /* First tx packet */
#define XAXIDMA_BD_CTRL_TXEOF_MASK	0x04000000 /* Last tx packet */
#define XAXIDMA_BD_CTRL_ALL_MASK	0x0C000000 /* All control bits */

#define XAXIDMA_BD_STS_ACTUAL_LEN_MASK	0x007FFFFF /* Actual len */
#define XAXIDMA_BD_STS_COMPLETE_MASK	0x80000000 /* Completed */
#define XAXIDMA_BD_STS_DEC_ERR_MASK	0x40000000 /* Decode error */
#define XAXIDMA_BD_STS_SLV_ERR_MASK	0x20000000 /* Slave error */
#define XAXIDMA_BD_STS_INT_ERR_MASK	0x10000000 /* Internal err */
#define XAXIDMA_BD_STS_ALL_ERR_MASK	0x70000000 /* All errors */
#define XAXIDMA_BD_STS_RXSOF_MASK	0x08000000 /* First rx pkt */
#define XAXIDMA_BD_STS_RXEOF_MASK	0x04000000 /* Last rx pkt */
#define XAXIDMA_BD_STS_ALL_MASK		0xFC000000 /* All status bits */

#define XAXIDMA_BD_MINIMUM_ALIGNMENT	0x40

#define DELAY_OF_ONE_MILLISEC		1000
#define XAXIENET_NAPI_WEIGHT		64

/* Macros used when AXI DMA h/w is configured without DRE */
#define XAE_TX_BUFFERS				64
#define XAE_MAX_PKT_LEN				8192


/**
 * struct axidma_bd - Axi Dma buffer descriptor layout
 * @next:         MM2S/S2MM Next Descriptor Pointer
 * @reserved1:    Reserved and not used for 32-bit
 * @phys:         MM2S/S2MM Buffer Address
 * @reserved2:    Reserved and not used for 32-bit
 * @reserved3:    Reserved and not used
 * @reserved4:    Reserved and not used
 * @cntrl:        MM2S/S2MM Control value
 * @status:       MM2S/S2MM Status value
 * @app0:         MM2S/S2MM User Application Field 0.
 * @app1:         MM2S/S2MM User Application Field 1.
 * @app2:         MM2S/S2MM User Application Field 2.
 * @app3:         MM2S/S2MM User Application Field 3.
 * @app4:         MM2S/S2MM User Application Field 4.
 * @sw_id_offset: MM2S/S2MM Sw ID
 * @ptp_tx_skb:   If timestamping is enabled used for timestamping skb
 *		  Otherwise reserved.
 * @ptp_tx_ts_tag: Tag value of 2 step timestamping if timestamping is enabled
 *		   Otherwise reserved.
 * @tx_skb:	  Transmit skb address
 * @tx_desc_mapping: Tx Descriptor DMA mapping type.
 */
struct axidma_bd {
        phys_addr_t next;	/* Physical address of next buffer descriptor */
#ifndef CONFIG_PHYS_ADDR_T_64BIT
        u32 reserved1;
#endif
        phys_addr_t phys;
#ifndef CONFIG_PHYS_ADDR_T_64BIT
        u32 reserved2;
#endif
        u32 reserved3;
        u32 reserved4;
        u32 cntrl;
        u32 status;
        u32 app0;
        u32 app1;	/* TX start << 16 | insert */
        u32 app2;	/* TX csum seed */
        u32 app3;
        u32 app4;
        phys_addr_t sw_id_offset; /* first unused field by h/w */
        phys_addr_t ptp_tx_skb;
        u32 ptp_tx_ts_tag;
        phys_addr_t tx_skb;
        u32 tx_desc_mapping;
} __aligned(XAXIDMA_BD_MINIMUM_ALIGNMENT);


#define DESC_DMA_MAP_SINGLE 0
#define DESC_DMA_MAP_PAGE 1

#define XAE_MAX_QUEUES		1

/**
 * struct axienet_local - axienet private per device data
 * @ndev:	Pointer for net_device to which it will be attached.
 * @dev:	Pointer to device structure
 * @phy_node:	Pointer to device node structure
 * @clk:	AXI bus clock
 * @mii_bus:	Pointer to MII bus structure
 * @mii_clk_div: MII bus clock divider value
 * @regs_start: Resource start for axienet device addresses
 * @regs:	Base address for the axienet_local device address space
 * @mcdma_regs:	Base address for the aximcdma device address space
 * @napi:	Napi Structure array for all dma queues
 * @num_tx_queues: Total number of Tx DMA queues
 * @num_rx_queues: Total number of Rx DMA queues
 * @dq:		DMA queues data
 * @phy_mode:	Phy type to identify between MII/GMII/RGMII/SGMII/1000 Base-X
 * @is_tsn:	Denotes a tsn port
 * @num_tc:	Total number of TSN Traffic classes
 * @timer_priv: PTP timer private data pointer
 * @ptp_tx_irq: PTP tx irq
 * @ptp_rx_irq: PTP rx irq
 * @rtc_irq:	PTP RTC irq
 * @qbv_irq:	QBV shed irq
 * @ptp_ts_type: ptp time stamp type - 1 or 2 step mode
 * @ptp_rx_hw_pointer: ptp rx hw pointer
 * @ptp_rx_sw_pointer: ptp rx sw pointer
 * @ptp_txq:	PTP tx queue header
 * @tx_tstamp_work: PTP timestamping work queue
 * @ptp_tx_lock: PTP tx lock
 * @dma_err_tasklet: Tasklet structure to process Axi DMA errors
 * @eth_irq:	Axi Ethernet IRQ number
 * @options:	AxiEthernet option word
 * @last_link:	Phy link state in which the PHY was negotiated earlier
 * @features:	Stores the extended features supported by the axienet hw
 * @tx_bd_num:	Number of TX buffer descriptors.
 * @rx_bd_num:	Number of RX buffer descriptors.
 * @max_frm_size: Stores the maximum size of the frame that can be that
 *		  Txed/Rxed in the existing hardware. If jumbo option is
 *		  supported, the maximum frame size would be 9k. Else it is
 *		  1522 bytes (assuming support for basic VLAN)
 * @rxmem:	Stores rx memory size for jumbo frame handling.
 * @csum_offload_on_tx_path:	Stores the checksum selection on TX side.
 * @csum_offload_on_rx_path:	Stores the checksum selection on RX side.
 * @coalesce_count_rx:	Store the irq coalesce on RX side.
 * @coalesce_count_tx:	Store the irq coalesce on TX side.
 * @phy_flags:	Phy interface flags.
 * @eth_hasnobuf: Ethernet is configured in Non buf mode.
 * @eth_hasptp: Ethernet is configured for ptp.
 * @axienet_config: Ethernet config structure
 * @tx_ts_regs:	  Base address for the axififo device address space.
 * @rx_ts_regs:	  Base address for the rx axififo device address space.
 * @tstamp_config: Hardware timestamp config structure.
 * @tx_ptpheader: Stores the tx ptp header.
 * @aclk: AXI4-Lite clock for ethernet and dma.
 * @eth_sclk: AXI4-Stream interface clock.
 * @eth_refclk: Stable clock used by signal delay primitives and transceivers.
 * @eth_dclk: Dynamic Reconfiguration Port(DRP) clock.
 * @dma_sg_clk: DMA Scatter Gather Clock.
 * @dma_rx_clk: DMA S2MM Primary Clock.
 * @dma_tx_clk: DMA MM2S Primary Clock.
 * @qnum:     Axi Ethernet queue number to be operate on.
 * @chan_num: MCDMA Channel number to be operate on.
 * @chan_id:  MCMDA Channel id used in conjunction with weight parameter.
 * @weight:   MCDMA Channel weight value to be configured for.
 * @dma_mask: Specify the width of the DMA address space.
 * @usxgmii_rate: USXGMII PHY speed.
 * @mrmac_rate: MRMAC speed.
 * @gt_pll: Common GT PLL mask control register space.
 * @gt_ctrl: GT speed and reset control register space.
 * @phc_index: Index to corresponding PTP clock used.
 * @gt_lane: MRMAC GT lane index used.
* @ptp_os_cf: CF TS of PTP PDelay req for one step usage.
*/
#if 1
struct axienet_local {
        struct net_device *ndev;
        struct device *dev;
        /* Clock for AXI bus */
        struct clk *clk;
        /* IO registers, dma functions and IRQs */
        resource_size_t regs_start;
        void __iomem *regs;
        struct tasklet_struct dma_err_tasklet[XAE_MAX_QUEUES];
        struct napi_struct napi[XAE_MAX_QUEUES];	/* NAPI Structure */
        u16    num_rx_queues;	/* Number of RX DMA queues */
        struct axienet_dma_q *dq[XAE_MAX_QUEUES];	/* DMA queue data*/
        int eth_irq;
        int link_alive;
        u32 rx_bd_num;
        u32 max_frm_size;
        int csum_offload_on_rx_path;
        u32 coalesce_count_rx;
        const struct axienet_config *axienet_config;
        struct clk *dma_sg_clk;
        struct clk *dma_rx_clk;
        struct clk *dma_clk;


        u8 dma_mask;
};
#endif
/**
 * struct axienet_dma_q - axienet private per dma queue data
 * @lp:		Parent pointer
 * @dma_regs:	Base address for the axidma device address space
 * @tx_irq:	Axidma TX IRQ number
 * @rx_irq:	Axidma RX IRQ number
 * @tx_lock:	Spin lock for tx path
 * @rx_lock:	Spin lock for tx path
 * @tx_bd_v:	Virtual address of the TX buffer descriptor ring
 * @tx_bd_p:	Physical address(start address) of the TX buffer descr. ring
 * @rx_bd_v:	Virtual address of the RX buffer descriptor ring
 * @rx_bd_p:	Physical address(start address) of the RX buffer descr. ring
 * @tx_buf:	Virtual address of the Tx buffer pool used by the driver when
 *		DMA h/w is configured without DRE.
 * @tx_bufs:	Virutal address of the Tx buffer address.
 * @tx_bufs_dma: Physical address of the Tx buffer address used by the driver
 *		 when DMA h/w is configured without DRE.
 * @eth_hasdre: Tells whether DMA h/w is configured with dre or not.
 * @tx_bd_ci:	Stores the index of the Tx buffer descriptor in the ring being
 *		accessed currently. Used while alloc. BDs before a TX starts
 * @tx_bd_tail:	Stores the index of the Tx buffer descriptor in the ring being
 *		accessed currently. Used while processing BDs after the TX
 *		completed.
 * @rx_bd_ci:	Stores the index of the Rx buffer descriptor in the ring being
 *		accessed currently.
 * @chan_id:    MCDMA channel to operate on.
 * @rx_offset:	MCDMA S2MM channel starting offset.
 * @txq_bd_v:	Virtual address of the MCDMA TX buffer descriptor ring
 * @rxq_bd_v:	Virtual address of the MCDMA RX buffer descriptor ring
 * @tx_packets: Number of transmit packets processed by the dma queue.
 * @tx_bytes:   Number of transmit bytes processed by the dma queue.
 * @rx_packets: Number of receive packets processed by the dma queue.
 * @rx_bytes:	Number of receive bytes processed by the dma queue.
 */
struct axienet_dma_q {
        struct axienet_local	*lp; /* parent */
        void __iomem *dma_regs;

        int rx_irq;
        spinlock_t rx_lock;		/* rx lock */

        /* Buffer descriptors */
        struct axidma_bd *tx_bd_v;
        struct axidma_bd *rx_bd_v;
        dma_addr_t rx_bd_p;
        bool eth_hasdre;
        u32 rx_bd_ci;
        u16 chan_id;
        u32 rx_offset;
        struct aximcdma_bd *rxq_bd_v;
        unsigned long rx_packets;
        unsigned long rx_bytes;
};


/**
 * axienet_ior - Memory mapped Axi Ethernet register read
 * @lp:         Pointer to axienet local structure
 * @offset:     Address offset from the base address of Axi Ethernet core
 *
 * Return: The contents of the Axi Ethernet register
 *
 * This function returns the contents of the corresponding register.
 */
static inline u32 axienet_ior(struct axienet_local *lp, off_t offset)
{
        return ioread32(lp->regs + offset);
}



/**
 * axienet_iow - Memory mapped Axi Ethernet register write
 * @lp:         Pointer to axienet local structure
 * @offset:     Address offset from the base address of Axi Ethernet core
 * @value:      Value to be written into the Axi Ethernet register
 *
 * This function writes the desired value into the corresponding Axi Ethernet
 * register.
 */
static inline void axienet_iow(struct axienet_local *lp, off_t offset,
                u32 value)
{
        iowrite32(value, lp->regs + offset);
}

/**
 * axienet_dma_in32 - Memory mapped Axi DMA register read
 * @q:		Pointer to DMA queue structure
 * @reg:	Address offset from the base address of the Axi DMA core
 *
 * Return: The contents of the Axi DMA register
 *
 * This function returns the contents of the corresponding Axi DMA register.
 */
static inline u32 axienet_dma_in32(struct axienet_dma_q *q, off_t reg)
{
        return ioread32(q->dma_regs + reg);
}

/**
 * axienet_dma_out32 - Memory mapped Axi DMA register write.
 * @q:		Pointer to DMA queue structure
 * @reg:	Address offset from the base address of the Axi DMA core
 * @value:	Value to be written into the Axi DMA register
 *
 * This function writes the desired value into the corresponding Axi DMA
 * register.
 */
static inline void axienet_dma_out32(struct axienet_dma_q *q,
                off_t reg, u32 value)
{
        iowrite32(value, q->dma_regs + reg);
}

/**
 * axienet_dma_bdout - Memory mapped Axi DMA register Buffer Descriptor write.
 * @q:		Pointer to DMA queue structure
 * @reg:	Address offset from the base address of the Axi DMA core
 * @value:	Value to be written into the Axi DMA register
 *
 * This function writes the desired value into the corresponding Axi DMA
 * register.
 */
static inline void axienet_dma_bdout(struct axienet_dma_q *q,
                off_t reg, dma_addr_t value)
{
#if defined(CONFIG_PHYS_ADDR_T_64BIT)
        writeq(value, (q->dma_regs + reg));
#else
        writel(value, (q->dma_regs + reg));
#endif
}

void __maybe_unused axienet_bd_free(struct net_device *ndev,
                struct axienet_dma_q *q);
int __maybe_unused axienet_dma_q_init(struct net_device *ndev,
                struct axienet_dma_q *q);
void axienet_dma_err_handler(unsigned long data);
irqreturn_t __maybe_unused axienet_tx_irq(int irq, void *_ndev);
irqreturn_t __maybe_unused axienet_rx_irq(int irq, void *_ndev);

void axienet_dma_bd_release(struct net_device *ndev);
void __axienet_device_reset(struct axienet_dma_q *q);
void axienet_set_mac_address(struct net_device *ndev, const void *address);

int xaxienet_rx_poll(struct napi_struct *napi, int quota);

int axienet_queue_xmit(struct sk_buff *skb, struct net_device *ndev,
                u16 map);


#endif /* XILINX_AXI_ENET_H */
