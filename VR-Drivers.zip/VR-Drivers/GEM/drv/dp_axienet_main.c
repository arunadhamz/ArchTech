/*
 * Axi Ethernet device driver
 *
 * This is a driver for the Axi Ethernet which is used in the ZynqMPSoC/RFSoC.
 * Note: This driver includes the logics for DMA driver, so this xilinx provided standard
 * AXI DMA driver is not required to be loaded. 
 *
 *Note: This driver includes the logics for AXI DMA, so the xilinx provided standard
 *AXI DMA driver is not required to be loaded. 
 *	- change the compatible property to "not" and status to "disabled" to 
 *	avoid loading the AXI DMA Driver which is provided by xilinx
 *	- check the "pl.dtsi" in "<project>/omponents/plnx_workspace/devicetree/devicetree"
 *	and look for the axi dma device tree node. 
 *
 *- The below mentioned device tree node should be added in the system-user.dtsi located
 * in "<project>/proj-spec/meta-user/recipe-bsp/device-tree/files/"
 *
 *&dp_eth_axi_dma_0 {
 *	compatible = "not";
 *	status = "disabled";
 *	xlnx,addrwidth = [20];
 *};
 *
 *&amba_pl {
 *	
 *	dp_eth_0: dp_eth@0 {
 * 		compatible = "dp,dp-ethernet-1.0";
 *		status = "okay";
 *		reg = <0x00 0xa0004000 0x00 0xff>;	
 *		axistream-connected = <&dp_eth_axi_dma_0>;
 *		interrupt-names = "pcspma_introut";
 *		interrupt-parent = <&dp_eth_axi_intc_0>;
 *		interrupts = <11 2>;
 *		local-mac-address = [00 08 2d ff 00 00];
 *		};
 * };
 *
 *+-----------------------------------------------------------------------------------------------------------------+
 *| Property            | Type         | Description                                                                |
 *+---------------------+--------------+----------------------------------------------------------------------------+
 *| compatible          | string       | "Must be ""dp,dp-ethernet-1.0"". Identifies the specific hardware driver." |
 *| status              | string       | "Set to ""okay"" to enable the device; ""disabled"" to ignore it."         |
 *| reg                 | 64-bit pair  | The base address (0xa0004000) and the address range size (0xff).           |
 *| axistream-connected | phandle      | Link to the AXI DMA engine responsible for RX/TX data transfers.           |
 *| interrupts          | index/type   | Specifies IRQ line 11.                                                     |
 *| interrupt-parent    | phandle      | Reference to the AXI Interrupt Controller managing this device.            |
 *| local-mac-address   | byte array   | The unique 6-byte Hardware (MAC) address for the interface.                |
 *+-----------------------------------------------------------------------------------------------------------------+
 * 
 * <pre>
 * MODIFICATION HISTORY:
 *
 * Ver   Who    	   Date        Changes
 * ----- ----------------- ----------  ---------------------------------------
 * 1V00  Vishnu Ram (2364) 04/09/2024  Initial Version
 * 
 * </pre>
 *
 */

#include <linux/clk.h>
#include <linux/circ_buf.h>
#include <linux/delay.h>
#include <linux/etherdevice.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/of_mdio.h>
#include <linux/of_net.h>
#include <linux/of_platform.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/skbuff.h>
#include <linux/spinlock.h>
#include <linux/phy.h>
#include <linux/mii.h>
#include <linux/ethtool.h>
#include <linux/iopoll.h>
#include <linux/ptp_classify.h>
#include <linux/net_tstamp.h>
#include <linux/random.h>
#include <net/sock.h>
#include <linux/xilinx_phy.h>
#include <linux/clk.h>
#include <linux/ip.h>          /* struct iphdr */
#include <linux/tcp.h>         /* struct tcphdr */

#include "dp_axienet.h"

/* Descriptors defines for Tx and Rx DMA */
#define TX_BD_NUM_DEFAULT		64
#define RX_BD_NUM_DEFAULT		128

/**
 * axienet_dma_bd_release - Release buffer descriptor rings
 * @ndev:	Pointer to the net_device structure
 *
 * This function is used to release the descriptors allocated in
 * axienet_dma_bd_init. axienet_dma_bd_release is called when Axi Ethernet
 * driver stop api is called.
 */
void axienet_dma_bd_release(struct net_device *ndev)
{
        int i;
        struct axienet_local *lp = netdev_priv(ndev);

        for_each_rx_dma_queue(lp, i) {
                axienet_bd_free(ndev, lp->dq[i]);
        }
}

/**
 * axienet_dma_bd_init - Setup buffer descriptor rings for Axi DMA
 * @ndev:	Pointer to the net_device structure
 *
 * Return: 0, on success -ENOMEM, on failure -EINVAL, on default return
 *
 * This function is called to initialize the Rx and Tx DMA descriptor
 * rings. This initializes the descriptors with required default values
 * and is called when Axi Ethernet driver reset is called.
 */
static int axienet_dma_bd_init(struct net_device *ndev)
{
        int i, ret = -EINVAL;
        struct axienet_local *lp = netdev_priv(ndev);

        for_each_rx_dma_queue(lp, i) {
                ret = axienet_dma_q_init(ndev, lp->dq[i]);
                if (ret != 0) {
                        netdev_err(ndev, "%s: Failed to init DMA buf %d\n", __func__, ret);
                        break;
                }
        }

        return ret;
}

/**
 * axienet_set_mac_address - Write the MAC address
 * @ndev:	Pointer to the net_device structure
 * @address:	6 byte Address to be written as MAC address
 *
 * This function is called to initialize the MAC address of the Axi Ethernet
 * core. It writes to the UAW0 and UAW1 registers of the core.
 */
void axienet_set_mac_address(struct net_device *ndev,
                const void *address)
{
        struct axienet_local *lp = netdev_priv(ndev);

        if (address)
                ether_addr_copy(ndev->dev_addr, address);
        if (!is_valid_ether_addr(ndev->dev_addr))
                eth_hw_addr_random(ndev);

        axienet_iow(lp, DPETH_MAC_MSB, ndev->dev_addr[3] |
                        ndev->dev_addr[2] << 8|
                        ndev->dev_addr[1] << 16|
                        ndev->dev_addr[0] << 24);

        axienet_iow(lp, DPETH_MAC_LSB, ndev->dev_addr[5] |
                        ndev->dev_addr[4] << 8);

}

/**
 * netdev_set_mac_address - Write the MAC address (from outside the driver)
 * @ndev:	Pointer to the net_device structure
 * @p:		6 byte Address to be written as MAC address
 *
 * Return: 0 for all conditions. Presently, there is no failure case.
 *
 * This function is called to initialize the MAC address of the Axi Ethernet
 * core. It calls the core specific axienet_set_mac_address. This is the
 * function that goes into net_device_ops structure entry ndo_set_mac_address.
 */
static int netdev_set_mac_address(struct net_device *ndev, void *p)
{
        struct sockaddr *addr = p;
        axienet_set_mac_address(ndev, addr->sa_data);

        return 0;
}

void __axienet_device_reset(struct axienet_dma_q *q)
{
        u32 timeout;
        /* Reset Axi DMA. This would reset Axi Ethernet core as well. The reset
         * process of Axi DMA takes a while to complete as all pending
         * commands/transfers will be flushed or completed during this
         * reset process.
         * Note that even though both TX and RX have their own reset register,
         * they both reset the entire DMA core, so only one needs to be used.
         */

        axienet_dma_out32(q, XAXIDMA_RX_CR_OFFSET, XAXIDMA_CR_RESET_MASK);
        timeout = DELAY_OF_ONE_MILLISEC;

        while (axienet_dma_in32(q, XAXIDMA_RX_CR_OFFSET) &
                        XAXIDMA_CR_RESET_MASK) {
                udelay(1);
                if (--timeout == 0) {
                        netdev_err(q->lp->ndev, "%s: DMA reset timeout!\n",
                                        __func__);
                        break;
                }
        }
}

static void axienet_fifo_reset(struct net_device *ndev)
{
        struct axienet_local *lp = netdev_priv(ndev);

        axienet_iow(lp, DPETH_FIFO_RESET, 0x8);
        axienet_iow(lp, DPETH_FIFO_RESET, 0);
}

static void axienet_pcspma_set(struct axienet_local *lp, char value)
{
        axienet_iow(lp, DPETH_PCSPMA_RESET, value);
}

static void axienet_pcspma_reset(struct net_device *ndev)
{
        struct axienet_local *lp = netdev_priv(ndev);

        axienet_pcspma_set(lp, 0x1);
        axienet_pcspma_set(lp, 0);
}

/**
 * axienet_device_reset - Reset and initialize the Axi Ethernet hardware.
 * @ndev:	Pointer to the net_device structure
 *
 * Return: 0 on success, Negative value on errors
 *
 * This function is called to reset and initialize the Axi Ethernet core. This
 * is typically called during initialization. It does a reset of the Axi DMA
 * Rx/Tx channels and initializes the Axi DMA BDs. Since Axi DMA reset lines
 * areconnected to Axi Ethernet reset lines, this in turn resets the Axi
 * Ethernet core. No separate hardware reset is done for the Axi Ethernet
 * core.
 */
static int axienet_device_reset(struct net_device *ndev)
{
        struct axienet_local *lp = netdev_priv(ndev);
        struct axienet_dma_q *q;
        u32 i;
        int ret;

        for_each_rx_dma_queue(lp, i) {
                q = lp->dq[i];
                __axienet_device_reset(q);
        }

        lp->max_frm_size = XAE_MAX_VLAN_FRAME_SIZE;

        ret = axienet_dma_bd_init(ndev);
        if (ret < 0) {
                netdev_err(ndev, "%s: descriptor allocation failed\n",
                                __func__);
                return ret;
        }

        axienet_fifo_reset(ndev);
        axienet_pcspma_reset(ndev);
        axienet_set_mac_address(ndev, NULL);

        netif_trans_update(ndev);

        return 0;
}


int axienet_queue_xmit(struct sk_buff *skb,
                struct net_device *ndev, u16 map)
{
        struct axienet_local *lp = netdev_priv(ndev);
        skb_frag_t *frag;
        int cur_frag;
        u32 num_frag;    
        unsigned int *uiData = NULL;

        u32 size = 0;
        u32 packets = 0;
        int packet_len = 0;
        char * packet_buf;
        int packet_index = 0;
        char * frag_buf = 0;
        int frag_len = 0;
        int cur_index = 0;

        /* reseting fifo */
        axienet_fifo_reset(ndev);

        packet_buf = (char*)kzalloc((sizeof(char) * skb->len), GFP_KERNEL);

        // -- check for non linear packets (paged data or fragments) eg: tcp
        if(skb_is_nonlinear(skb)) {
                packet_len = skb_headlen(skb);
        }
        else {
                packet_len = skb->len;
        }

        memcpy(packet_buf, skb->data, packet_len);

        // -- check for the available fragments       
        num_frag = skb_shinfo(skb)->nr_frags;
        if(num_frag) {

                for (cur_frag = 0; cur_frag < num_frag; cur_frag++)  {

                        frag = &skb_shinfo(skb)->frags[cur_frag];
                        frag_buf = (char*)skb_frag_address(frag);
                        frag_len = skb_frag_size(frag);

                        memcpy((packet_buf + packet_len), frag_buf, frag_len);

                        packet_len += frag_len;
                }
        }

        packet_index = packet_len/4;
        if(packet_len % 4 != 0){
                packet_index++;
        }

        uiData = (unsigned int*)packet_buf; 		

        for (cur_index = 0; cur_index < packet_index; cur_index++) {
                axienet_iow(lp, DPETH_FIFO_DATA_WR, uiData[cur_index]);		
        }

        /* data length */
        axienet_iow(lp, DPETH_FIFO_COUNT_WR, packet_len);

        // free the packet buffer
        kfree(packet_buf);

        packets++;
        size = packet_len;

        ndev->stats.tx_packets += packets;
        ndev->stats.tx_bytes += size;

        if(skb)
                dev_kfree_skb(skb);

        return NETDEV_TX_OK;
}

/**
 * axienet_start_xmit - Starts the transmission.
 * @skb:	sk_buff pointer that contains data to be Txed.
 * @ndev:	Pointer to net_device structure.
 *
 * Return: NETDEV_TX_OK, on success
 *	    NETDEV_TX_BUSY, if any of the descriptors are not free
 *
 * This function is invoked from upper layers to initiate transmission. The
 * function uses the next available free BDs and populates their fields to
 * start the transmission. Additionally if checksum offloading is supported,
 * it populates AXI Stream Control fields with appropriate values.
 */
static int axienet_start_xmit(struct sk_buff *skb, struct net_device *ndev)
{
        u16 map = skb_get_queue_mapping(skb); /* Single dma queue default*/

        return axienet_queue_xmit(skb, ndev, map);
}

/**
 * axienet_recv - Is called from Axi DMA Rx Isr to complete the received
 *		  BD processing.
 * @ndev:	Pointer to net_device structure.
 * @budget:	NAPI budget
 * @q:		Pointer to axienet DMA queue structure
 *
 * This function is invoked from the Axi DMA Rx isr(poll) to process the Rx BDs
 * It does minimal processing and invokes "netif_receive_skb" to complete
 * further processing.
 * Return: Number of BD's processed.
 */
static int axienet_recv(struct net_device *ndev, int budget,
                struct axienet_dma_q *q)
{
        u32 length;
        u32 size = 0;
        u32 packets = 0;
        dma_addr_t tail_p = 0;
        struct axienet_local *lp = netdev_priv(ndev);
        struct sk_buff *skb, *new_skb;
        struct axidma_bd *cur_p;
        unsigned int numbdfree = 0;

        /* Get relevat BD status value */
        rmb();

        cur_p = &q->rx_bd_v[q->rx_bd_ci];


        while ((numbdfree < budget) && 
                        (cur_p->status & XAXIDMA_BD_STS_COMPLETE_MASK)) {

                new_skb = netdev_alloc_skb(ndev, lp->max_frm_size);
                if (!new_skb) {
                        dev_err(lp->dev, "No memory for new_skb\n");
                        break;
                }

                tail_p = q->rx_bd_p + sizeof(*q->rx_bd_v) * q->rx_bd_ci;

                dma_unmap_single(ndev->dev.parent, cur_p->phys,
                                lp->max_frm_size,
                                DMA_FROM_DEVICE);

                skb = (struct sk_buff *)(cur_p->sw_id_offset);

                skb_reserve(skb, NET_IP_ALIGN);  /* align IP on 16B boundary. after the ethernet header, the protocol
                                                    header will be aligned on at least a 4-byte boundary.*/  

                length = cur_p->status & XAXIDMA_BD_STS_ACTUAL_LEN_MASK;

                skb_put(skb, length);

                skb->protocol = eth_type_trans(skb, ndev);                
                skb->ip_summed = CHECKSUM_UNNECESSARY;

                netif_receive_skb(skb);

                size += length;
                packets++;

                /* Ensure that the skb is completely updated
                 * prio to mapping the DMA
                 */
                wmb();

                cur_p->phys = dma_map_single(ndev->dev.parent, new_skb->data,
                                lp->max_frm_size,
                                DMA_FROM_DEVICE);
                cur_p->cntrl = lp->max_frm_size;
                cur_p->status = 0;
                cur_p->sw_id_offset = (phys_addr_t)new_skb;

                if (++q->rx_bd_ci >= lp->rx_bd_num)
                        q->rx_bd_ci = 0;

                /* Get relevat BD status value */
                rmb();

                cur_p = &q->rx_bd_v[q->rx_bd_ci];

                numbdfree++;
        }

        ndev->stats.rx_packets += packets;
        ndev->stats.rx_bytes += size;
        q->rx_packets += packets;
        q->rx_bytes += size;

        if (tail_p) {
                axienet_dma_bdout(q, XAXIDMA_RX_TDESC_OFFSET, tail_p);
        }

        return numbdfree;
}

/**
 * xaxienet_rx_poll - Poll routine for rx packets (NAPI)
 * @napi:	napi structure pointer
 * @quota:	Max number of rx packets to be processed.
 *
 * This is the poll routine for rx part.
 * It will process the packets maximux quota value.
 *
 * Return: number of packets received
 */
int xaxienet_rx_poll(struct napi_struct *napi, int quota)
{
        struct net_device *ndev = napi->dev;
        struct axienet_local *lp = netdev_priv(ndev);
        int work_done = 0;
        unsigned int status, cr;

        int map = napi - lp->napi;

        struct axienet_dma_q *q = lp->dq[map];


        spin_lock(&q->rx_lock);

        status = axienet_dma_in32(q, XAXIDMA_RX_SR_OFFSET);


        while ((status & (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_DELAY_MASK)) &&
                        (work_done < quota)) {
                axienet_dma_out32(q, XAXIDMA_RX_SR_OFFSET, status);
                if (status & XAXIDMA_IRQ_ERROR_MASK) {
                        dev_err(lp->dev, "Rx error 0x%x\n\r", status);
                        break;
                }
                work_done += axienet_recv(lp->ndev, quota - work_done, q);
                status = axienet_dma_in32(q, XAXIDMA_RX_SR_OFFSET);
        }

        spin_unlock(&q->rx_lock);

        if (work_done < quota) {
                napi_complete(napi);

                /* Enable the interrupts again */
                cr = axienet_dma_in32(q, XAXIDMA_RX_CR_OFFSET);
                cr |= (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_DELAY_MASK);
                axienet_dma_out32(q, XAXIDMA_RX_CR_OFFSET, cr);
        }

        //status = axienet_dma_in32(q, XAXIDMA_RX_SR_OFFSET);

        return work_done;
}

/**
 * axienet_eth_irq - Ethernet core Isr.
 * @irq:	irq number
 * @_ndev:	net_device pointer
 *
 * Return: IRQ_HANDLED if device generated a core interrupt, IRQ_NONE otherwise.
 *
 * Handle miscellaneous conditions indicated by Ethernet core IRQ.
 */
static irqreturn_t axienet_eth_irq(int irq, void *_ndev)
{
        struct net_device *ndev = _ndev;
        struct axienet_local *lp = netdev_priv(ndev);
        unsigned int status = 0;
        unsigned int speed = 0; 
        char unit = 0;
        char mode = 0;

        status =  axienet_ior(lp, DPETH_PCSPMA_STATUS);

        switch((status >> 10) & 0x3)
        {
                case 0: speed = 10; break;	//10 Mbps
                case 1: speed = 100; break;	//100 Mbps
                case 2: speed = 1; unit = 1; break;	//1000 Mbps or 1Gbps
        }

        mode = ((status >> 12) & 0x1) ? 1 /*full duplex*/ : 0 /*half duplex*/;

        if(status & 0x1) {
                if(!lp->link_alive){
                        netdev_info(ndev, " Link is up - %d%s/%s\n",
                                        speed, unit ? "Gbps" : "Mbps", mode ? "Full" : "Half");
                        lp->link_alive = 1;
                }
        }
        else {
                if(lp->link_alive) {
                        netdev_info(ndev, " Link is down\n");
                        lp->link_alive = 0;
                }
        }
        return IRQ_HANDLED;
}

/**
 * axienet_	 - Driver open routine.
 * @ndev:	Pointer to net_device structure
 *
 * Return: 0, on success.
 *	    non-zero error value on failure
 *
 * This is the driver open routine. It calls phy_start to start the PHY device.
 * It also allocates interrupt service routines, enables the interrupt lines
 * and ISR handling. Axi Ethernet core is reset through Axi DMA core. Buffer
 * descriptors are initialized.
 */
static int axienet_open(struct net_device *ndev)
{
        int ret = 0, i = 0;
        struct axienet_local *lp = netdev_priv(ndev);
        struct axienet_dma_q *q;

        ret  = axienet_device_reset(ndev);
        if (ret < 0) {
                dev_err(lp->dev, "axienet_device_reset failed\n");
                return ret;
        }

        /* Enable tasklets for Axi DMA error handling */
        for_each_rx_dma_queue(lp, i) {

                tasklet_init(&lp->dma_err_tasklet[i],
                                axienet_dma_err_handler,
                                (unsigned long)lp->dq[i]);


                /* Enable NAPI scheduling before enabling Axi DMA Rx
                 * IRQ, or you might run into a race condition; the RX
                 * ISR disables IRQ processing before scheduling the
                 * NAPI function to complete the processing. If NAPI
                 * scheduling is (still) disabled at that time, no more
                 * RX IRQs will be processed as only the NAPI function
                 * re-enables them!
                 */
                napi_enable(&lp->napi[i]);
        }

        for_each_rx_dma_queue(lp, i) {
                struct axienet_dma_q *q = lp->dq[i];

                /* Enable interrupts for Axi DMA Rx */
                ret = request_irq(q->rx_irq, axienet_rx_irq,
                                0, ndev->name, ndev);
                if (ret)
                        goto err_rx_irq;
        }

        // -- requesting ethernet irq
        if(lp->eth_irq)
                ret = request_irq(lp->eth_irq, axienet_eth_irq, IRQF_SHARED,
                                ndev->name, ndev);
        if (ret)
                goto err_eth_irq;

        netif_tx_start_all_queues(ndev);

        return 0;

err_eth_irq:
err_rx_irq:
        i = lp->num_rx_queues;

        while (i--) {
                q = lp->dq[i];
                free_irq(q->rx_irq, ndev);
        }

        for_each_rx_dma_queue(lp, i)
                napi_disable(&lp->napi[i]);

        for_each_rx_dma_queue(lp, i)
                tasklet_kill(&lp->dma_err_tasklet[i]);
        dev_err(lp->dev, "request_irq() failed\n");
        return ret;
}

/**
 * axienet_stop - Driver stop routine.
 * @ndev:	Pointer to net_device structure
 *
 * Return: 0, on success.
 *
 * This is the driver stop routine. It calls phy_disconnect to stop the PHY
 * device. It also removes the interrupt handlers and disables the interrupts.
 * The Axi DMA Tx/Rx BDs are released.
 */
static int axienet_stop(struct net_device *ndev)
{
        u32 i;
        struct axienet_local *lp = netdev_priv(ndev);
        struct axienet_dma_q *q;

        for_each_rx_dma_queue(lp, i) {
                q = lp->dq[i];
                netif_stop_queue(ndev);
                napi_disable(&lp->napi[i]);
                tasklet_kill(&lp->dma_err_tasklet[i]);
                free_irq(q->rx_irq, ndev);
        }

        axienet_pcspma_set(lp, 0x1); //making pcspma down
        
        if(lp->eth_irq)
                free_irq(lp->eth_irq, ndev);

        axienet_dma_bd_release(ndev);

        return 0;
}

/**
 * axienet_change_mtu - Driver change mtu routine.
 * @ndev:	Pointer to net_device structure
 * @new_mtu:	New mtu value to be applied
 *
 * Return: Always returns 0 (success).
 *
 * This is the change mtu driver routine. It checks if the Axi Ethernet
 * hardware supports jumbo frames before changing the mtu. This can be
 * called only when the device is not up.
 */
static int axienet_change_mtu(struct net_device *ndev, int new_mtu)
{
        if (netif_running(ndev))
                return -EBUSY;

        if ((new_mtu + VLAN_ETH_HLEN +
                                XAE_TRL_SIZE) > XAE_MAX_FRAME_SIZE)
                return -EINVAL;

        ndev->mtu = new_mtu;

        return 0;
}

#ifdef CONFIG_NET_POLL_CONTROLLER
/**
 * axienet_poll_controller - Axi Ethernet poll mechanism.
 * @ndev:	Pointer to net_device structure
 *
 * This implements Rx/Tx ISR poll mechanisms. The interrupts are disabled prior
 * to polling the ISRs and are enabled back after the polling is done.
 */
static void axienet_poll_controller(struct net_device *ndev)
{
        struct axienet_local *lp = netdev_priv(ndev);
        int i;

        for_each_rx_dma_queue(lp, i)
                disable_irq(lp->dq[i]->rx_irq);

        for_each_rx_dma_queue(lp, i)

                axienet_rx_irq(lp->dq[i]->rx_irq, ndev);

        for_each_rx_dma_queue(lp, i)
                enable_irq(lp->dq[i]->rx_irq);
}
#endif


static int axienet_ioctl(struct net_device *dev, struct ifreq *rq, int cmd)
{
        return -EOPNOTSUPP;
}

static const struct net_device_ops axienet_netdev_ops = {

        .ndo_open = axienet_open,
        .ndo_stop = axienet_stop,
        .ndo_start_xmit = axienet_start_xmit,
        .ndo_change_mtu	= axienet_change_mtu,
        .ndo_set_mac_address = netdev_set_mac_address,
        .ndo_validate_addr = eth_validate_addr,
        .ndo_do_ioctl = axienet_ioctl,
#ifdef CONFIG_NET_POLL_CONTROLLER
        .ndo_poll_controller = axienet_poll_controller,
#endif
};

static int __maybe_unused axienet_dma_probe(struct platform_device *pdev,
                struct net_device *ndev)
{
        int i, ret;
        struct axienet_local *lp = netdev_priv(ndev);
        struct axienet_dma_q *q;
        struct device_node *np = NULL;
        struct resource dmares;

        for_each_rx_dma_queue(lp, i) {

                q = devm_kzalloc(&pdev->dev, sizeof(*q), GFP_KERNEL);
                if (!q)
                        return -ENOMEM;

                /* parent */
                q->lp = lp;

                lp->dq[i] = q;
        }

        /* Find the DMA node, map the DMA registers, and decode the DMA IRQs */
        /* TODO handle error ret */
        for_each_rx_dma_queue(lp, i) {
                q = lp->dq[i];

                np = of_parse_phandle(pdev->dev.of_node, "axistream-connected", i);
                if (np) {
                        ret = of_address_to_resource(np, 0, &dmares);
                        if (ret >= 0) {
                                q->dma_regs = devm_ioremap_resource(&pdev->dev, &dmares);
                        } else {
                                dev_err(&pdev->dev, "unable to get DMA resource for %pOF\n",
                                                np);
                                return -ENODEV;
                        }
                        q->eth_hasdre = of_property_read_bool(np,
                                        "xlnx,include-dre");
                        ret = of_property_read_u8(np, "xlnx,addrwidth",
                                        (u8 *)&lp->dma_mask);

                        if (ret <  0 || lp->dma_mask < XAE_DMA_MASK_MIN ||
                                        lp->dma_mask > XAE_DMA_MASK_MAX) {
                                dev_info(&pdev->dev, "missing/invalid xlnx,addrwidth property, using default\n");
                                lp->dma_mask = XAE_DMA_MASK_MIN;
                        }
                } else {
                        dev_err(&pdev->dev, "missing axistream-connected property\n");
                        return -EINVAL;
                }
                lp->dq[i]->rx_irq = irq_of_parse_and_map(np, 0);
        }

        of_node_put(np);

        for_each_rx_dma_queue(lp, i) {
                struct axienet_dma_q *q = lp->dq[i];

                spin_lock_init(&q->rx_lock);
        }

        for_each_rx_dma_queue(lp, i) {
                netif_napi_add(ndev, &lp->napi[i], xaxienet_rx_poll,
                                XAXIENET_NAPI_WEIGHT);
        }

        return 0;
}



static int axienet_dma_clk_init(struct platform_device *pdev)
{
        int err;
        struct net_device *ndev = platform_get_drvdata(pdev);
        struct axienet_local *lp = netdev_priv(ndev);

        /* The "dma_clk" is deprecated and will be removed sometime in
         * the future. For proper clock usage check axiethernet binding
         * documentation.
         */
        lp->dma_clk = devm_clk_get(&pdev->dev, "dma_clk");
        if (IS_ERR(lp->dma_clk)) {
                if (PTR_ERR(lp->dma_clk) != -ENOENT) {
                        err = PTR_ERR(lp->dma_clk);
                        return err;
                }

                lp->dma_clk = devm_clk_get(&pdev->dev, "m_axi_mm2s_aclk");
                if (IS_ERR(lp->dma_clk)) {
                        if (PTR_ERR(lp->dma_clk) != -ENOENT) {
                                err = PTR_ERR(lp->dma_clk);
                                return err;
                        }
                        lp->dma_clk = NULL;
                }
        } else {
        }

        lp->dma_rx_clk = devm_clk_get(&pdev->dev, "m_axi_s2mm_aclk");
        if (IS_ERR(lp->dma_rx_clk)) {
                if (PTR_ERR(lp->dma_rx_clk) != -ENOENT) {
                        err = PTR_ERR(lp->dma_rx_clk);
                        return err;
                }
                lp->dma_rx_clk = NULL;
        }

        lp->dma_sg_clk = devm_clk_get(&pdev->dev, "m_axi_sg_aclk");
        if (IS_ERR(lp->dma_sg_clk)) {
                if (PTR_ERR(lp->dma_sg_clk) != -ENOENT) {
                        err = PTR_ERR(lp->dma_sg_clk);
                        return err;
                }
                lp->dma_sg_clk = NULL;
        }

        err = clk_prepare_enable(lp->dma_clk);
        if (err) {
                dev_err(&pdev->dev, "failed to enable tx_clk/dma_clk (%d)\n", err);
                return err;
        }

        err = clk_prepare_enable(lp->dma_rx_clk);
        if (err) {
                dev_err(&pdev->dev, "failed to enable rx_clk (%d)\n", err);
                goto err_disable_txclk;
        }

        err = clk_prepare_enable(lp->dma_sg_clk);
        if (err) {
                dev_err(&pdev->dev, "failed to enable sg_clk (%d)\n", err);
                goto err_disable_rxclk;
        }

        return 0;

err_disable_rxclk:
        clk_disable_unprepare(lp->dma_rx_clk);
err_disable_txclk:
        clk_disable_unprepare(lp->dma_clk);	

        return err;
}

static void axienet_clk_disable(struct platform_device *pdev)
{
        struct net_device *ndev = platform_get_drvdata(pdev);
        struct axienet_local *lp = netdev_priv(ndev);

        clk_disable_unprepare(lp->dma_sg_clk);
        clk_disable_unprepare(lp->dma_clk);
        clk_disable_unprepare(lp->dma_rx_clk);
}

/* Match table for of_platform binding */
static const struct of_device_id axienet_of_match[] = {
        {.compatible = "dp,dp-ethernet-1.0"},
        {},
};

MODULE_DEVICE_TABLE(of, axienet_of_match);

/**
 * axienet_probe - Axi Ethernet probe function.
 * @pdev:	Pointer to platform device structure.
 *
 * Return: 0, on success
 *	    Non-zero error value on failure.
 *
 * This is the probe routine for Axi Ethernet driver. This is called before
 * any other driver routines are invoked. It allocates and sets up the Ethernet
 * device. Parses through device tree and populates fields of
 * axienet_local. It registers the Ethernet device.
 */
static int axienet_probe(struct platform_device *pdev)
{
        int ret = 0;
        struct axienet_local *lp;
        struct net_device *ndev;
        const void *mac_addr;
        struct resource *ethres;
        u16 num_queues;

        // -- allocating ethernet device
        num_queues = XAE_MAX_QUEUES;
        ndev = alloc_etherdev_mq(sizeof(*lp), num_queues);
        if (!ndev)
                return -ENOMEM;

        platform_set_drvdata(pdev, ndev);

        SET_NETDEV_DEV(ndev, &pdev->dev);
        ndev->flags &= ~IFF_MULTICAST;  /* clear multicast */
        ndev->features = NETIF_F_SG;
        ndev->netdev_ops = &axienet_netdev_ops;

        /* MTU range: 64 - 9000 */
        ndev->min_mtu = 64;
        ndev->max_mtu = XAE_JUMBO_MTU;

        lp = netdev_priv(ndev);
        lp->ndev = ndev;
        lp->dev = &pdev->dev;
        lp->num_rx_queues = num_queues;

        lp->rx_bd_num = RX_BD_NUM_DEFAULT;
        //lp->tx_bd_num = TX_BD_NUM_DEFAULT;
        lp->coalesce_count_rx = XAXIDMA_DFT_RX_THRESHOLD;


        /* Map device registers */
        ethres = platform_get_resource(pdev, IORESOURCE_MEM, 0);
        lp->regs = devm_ioremap_resource(&pdev->dev, ethres);
        if (IS_ERR(lp->regs)) {
                ret = PTR_ERR(lp->regs);
                goto free_netdev;
        }
        lp->regs_start = ethres->start;

        // -- getting irq numnber
        lp->eth_irq = platform_get_irq(pdev, 0);
        if (lp->eth_irq <= 0)
                dev_info(&pdev->dev, "Ethernet core IRQ not defined\n");

        // -- Probing DMA
        ret = axienet_dma_probe(pdev, ndev);
        if (ret) {
                pr_err("Getting DMA resource failed\n");
                goto free_netdev;
        }

        if (dma_set_mask_and_coherent(lp->dev, DMA_BIT_MASK(lp->dma_mask)) != 0) {
                dev_warn(&pdev->dev, "default to %d-bit dma mask\n", XAE_DMA_MASK_MIN);
                if (dma_set_mask_and_coherent(lp->dev, DMA_BIT_MASK(XAE_DMA_MASK_MIN)) != 0) {
                        dev_err(&pdev->dev, "dma_set_mask_and_coherent failed, aborting\n");
                        goto free_netdev;
                }
        }

        // -- Initializing dma clocks
        ret = axienet_dma_clk_init(pdev);
        if (ret) {
                if (ret != -EPROBE_DEFER)
                        dev_err(&pdev->dev, "DMA clock init failed %d\n", ret);
                goto free_netdev;
        }

        /* Retrieve the MAC address */
        mac_addr = of_get_mac_address(pdev->dev.of_node);
        if (IS_ERR(mac_addr)) {
                dev_warn(&pdev->dev, "could not find MAC address property: %ld\n",
                                PTR_ERR(mac_addr));
                mac_addr = NULL;
        }
        axienet_set_mac_address(ndev, mac_addr);

        // -- registering network device
        ret = register_netdev(lp->ndev);
        if (ret) {
                dev_err(lp->dev, "register_netdev() error (%i)\n", ret);
                goto err_disable_clk;
        }

        return 0;

err_disable_clk:
        axienet_clk_disable(pdev);
free_netdev:
        free_netdev(ndev);

        return ret;
}

static int axienet_remove(struct platform_device *pdev)
{
        struct net_device *ndev = platform_get_drvdata(pdev);
        struct axienet_local *lp = netdev_priv(ndev);
        int i;


        for_each_rx_dma_queue(lp, i)
                netif_napi_del(&lp->napi[i]);


        unregister_netdev(ndev);

        if (lp->clk)
                clk_disable_unprepare(lp->clk);

        free_netdev(ndev);

        return 0;
}

static void axienet_shutdown(struct platform_device *pdev)
{
        struct net_device *ndev = platform_get_drvdata(pdev);
        
        rtnl_lock();
        
        netif_device_detach(ndev);

        if (netif_running(ndev))
                dev_close(ndev);

        rtnl_unlock();

}

static struct platform_driver axienet_driver = {
        .probe = axienet_probe,
        .remove = axienet_remove,
        .shutdown = axienet_shutdown,
        .driver = {
                .name = "dp_ethernet",
                .of_match_table = axienet_of_match,
        },
};

module_platform_driver(axienet_driver);

MODULE_DESCRIPTION("Ethernet driver");
MODULE_AUTHOR("Data Patterns India Ltd, Vishnu Ram G");
MODULE_LICENSE("GPL");
