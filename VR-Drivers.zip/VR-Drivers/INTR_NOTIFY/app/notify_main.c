
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <errno.h>

#include "../inc/dp_notifier.h"



static int done = 0;
int check = 0;

void ctrl_c_handler(int n, siginfo_t *info, void *unused)
{
        if (n == SIGINT) {
                printf("\nrecieved ctrl-c\n");
                done = 1;
        }
}

void interrupt_event_handler()
{
        printf("event occured Done!!!\n");
}

int main()
{
        int fd;
        struct sigaction act;
		unsigned long uiTimeeout = 0;
		int iRet = 0;
		
        /* install ctrl-c interrupt handler to cleanup at exit */
        sigemptyset (&act.sa_mask);
        act.sa_flags = (SA_SIGINFO | SA_RESETHAND);
        act.sa_sigaction = ctrl_c_handler;
        sigaction (SIGINT, &act, NULL);

        fd = open("/dev/dp_notify", O_RDWR);
        if(fd < 0) {
                printf("Cannot open device file...\n");
                perror("");
                return 0;
        }

		uiTimeeout = 10000;
        while(1) { 
                printf("waiting for event ...");

                /* register this task with kernel for signal */
#if 0
                if (ioctl(fd, DP_REG_CUR_TASK,NULL)) {
                        printf("Failed\n");
                        close(fd);
                        exit(1);
                }
#else
				//iRet = ioctl(fd, DP_REG_CUR_TASK, &uiTimeeout);
				iRet = ioctl(fd, DP_REG_CUR_TASK, NULL);
				if (iRet == DP_EVENT_CONDITION) {
						printf("Event -> condition\n");
                }
				else if (iRet == DP_EVENT_TIMEOUT){
						printf("Event -> Timeout\n");
				}
				else {
						printf("Failed\n");
                        close(fd);
                        exit(1);
				}
#endif
                interrupt_event_handler();
        }
        printf("Closing Driver\n");
        close(fd);
}
