#include <linux/of_platform.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/interrupt.h>
#include <linux/wait.h>
#include <linux/slab.h>
#include "../inc/dp_notifier.h"

#define DP_DEV_NAME "dp_notify"

typedef struct SDevInfo {
        int m_iIrq;

        // -- chrdev
        u32 m_minor_num;
        u32 m_major_num;
        dev_t m_dev_num;
        char m_dev_name[20];
        char m_class_name[25];
        struct cdev m_cdev;
        struct class *m_cdev_class;
        struct device *m_dev;

        // -- wait queue
        wait_queue_head_t m_waitqueue;
        int m_iWaitqueue_flag;

}SDevInfo_t;

/**
 * dp_notify_irq_handler - notifyer Isr.
 * @irq:	irq number
 * @in_psInfo:	device info structure pointer
 *
 * Return: IRQ_HANDLED if device generated a core interrupt, IRQ_NONE otherwise.
 *
 * Handle miscellaneous conditions indicated by notifier IRQ.
 */
static irqreturn_t dp_notify_irq_handler(int irq, void *in_psInfo)
{
        SDevInfo_t *psInfo = in_psInfo;

        // -- waking up the wait quque
        psInfo->m_iWaitqueue_flag = 1;
        wake_up_interruptible(&psInfo->m_waitqueue);

        return IRQ_HANDLED;
}


/**
 * dp_notify_open - Driver open routine.
 * @in_pInode:	Pointer to inode structure
 * @in_pfile:   Pointer to file structure
 *
 * Return: 0, on success.
 *	    non-zero error value on failure
 *
 * This is the driver open routine. it allocates interrupt service routines, 
 * enables the interrupt lines and ISR handling.
 */
static int dp_notify_open (struct inode *in_pInode, struct file *in_pfile)
{
        int ret = 0;
        SDevInfo_t *psInfo;

        psInfo = container_of(in_pInode->i_cdev, SDevInfo_t, m_cdev);
        in_pfile->private_data = psInfo;

        // -- request irq
        if(psInfo->m_iIrq) {
                ret = request_irq(psInfo->m_iIrq, dp_notify_irq_handler, 
                                IRQF_TRIGGER_RISING, psInfo->m_dev_name, psInfo);
                if(ret) {
                        dev_err(psInfo->m_dev, "request_irq() failed\n");
                        return ret;
                }				
        }

        return 0;
}

/**
 * dp_notify_release - Driver release routine.
 * @in_pInode:  Pointer to inode structure
 * @in_pfile:   Pointer to file structure
 *
 * Return: 0, on success.
 *
 * This is the driver stop routine. It removes the interrupt handlers 
 * and disables the interrupts. 
 */
static int dp_notify_release (struct inode *in_pInode, struct file *in_pfile)
{
        SDevInfo_t *psInfo;

        psInfo = container_of(in_pInode->i_cdev, SDevInfo_t, m_cdev);
        in_pfile->private_data = NULL;

        if(psInfo->m_iIrq)
                free_irq(psInfo->m_iIrq, psInfo);

        return 0;
}

static long dp_notify_ioctl (struct file *in_pfile, unsigned int in_uiCmd, 
                unsigned long in_ulArg)
{
        void *pvBuffer;
        unsigned long ulTimeout = 0;
        int iStatus = 0;
        SDevInfo_t *psInfo;
        psInfo = in_pfile->private_data;
        
        if(!(pvBuffer = kzalloc(_IOC_SIZE(in_uiCmd), GFP_KERNEL))){
                dev_err(psInfo->m_dev, "Unable to allocate IO memory\n");
                return -ENOMEM;
        }

        if(in_uiCmd == DP_REG_CUR_TASK) {
                copy_from_user(pvBuffer, (unsigned long *)in_ulArg, 
                                _IOC_SIZE(in_uiCmd));

                if(pvBuffer != NULL)
                        ulTimeout = *((unsigned long*)pvBuffer);

                psInfo->m_iWaitqueue_flag = 0;

                do {
                        wait_event_interruptible_timeout(psInfo->m_waitqueue, 
                                        (psInfo->m_iWaitqueue_flag != 0), 
                                        msecs_to_jiffies(ulTimeout));

                        if(psInfo->m_iWaitqueue_flag != 0) {
                                iStatus = DP_EVENT_CONDITION;
                                break;
                        }

                        iStatus = DP_EVENT_TIMEOUT;
                        break;
                }while(0);
        }

        if(pvBuffer != NULL){
                kfree(pvBuffer);
                pvBuffer = NULL;
        }

        return iStatus;
}

static struct file_operations notify_fops = {
        .open = dp_notify_open,
        .release = dp_notify_release,
        .unlocked_ioctl = dp_notify_ioctl,
        .owner = THIS_MODULE,
};

/**
 * dp_reg_chrdev - char device register function.
 * @pdev:  Pointer to platform_device structure
 *
 * Return: 0, on success.
 *  Non-zero error value on failure.
 *
 * This is the char device register routine. It registers the notify device
 * with the kernel and creates a device file.
 */

static int dp_reg_chrdev(struct platform_device *pdev) 
{       
        int ret = 0;
        dev_t dev_num = 0;
        SDevInfo_t *psInfo = platform_get_drvdata(pdev);

        strcpy(psInfo->m_dev_name, DP_DEV_NAME);

        ret = alloc_chrdev_region(&dev_num, 0, 1, psInfo->m_dev_name);
        if(ret != 0) {
                return ret;
        }

        psInfo->m_dev_num = dev_num;
        psInfo->m_major_num = MAJOR(dev_num);
        psInfo->m_minor_num = MINOR(dev_num);

        cdev_init(&psInfo->m_cdev, &notify_fops); 

        ret = cdev_add(&psInfo->m_cdev, psInfo->m_dev_num, 1);
        if(ret != 0) {
                unregister_chrdev_region(psInfo->m_major_num, 1);
                return ret;
        }

        snprintf(psInfo->m_class_name, (15 * sizeof(char)), "%s_class", 
                        psInfo->m_dev_name);

        if(IS_ERR(psInfo->m_cdev_class = class_create(THIS_MODULE, 
                                        psInfo->m_class_name))) {
                cdev_del(&psInfo->m_cdev);
                unregister_chrdev_region(psInfo->m_major_num, 1);
                return -EINVAL;
        }

        if(IS_ERR(device_create(psInfo->m_cdev_class, NULL, psInfo->m_dev_num, NULL,
                                        psInfo->m_dev_name))) {
                class_destroy(psInfo->m_cdev_class);
                cdev_del(&psInfo->m_cdev);
                unregister_chrdev_region(psInfo->m_major_num, 1);
                return -EINVAL;
        }

        return 0;
}

/**
 * dp_unreg_chrdev - char device unregister function.
 * @pdev:  Pointer to platform_device structure
 *
 * This is the char device unregister routine. It unregisters the notify device
 * with the kernel and removes the device file.
 */
static void dp_unreg_chrdev(struct platform_device *pdev) 
{
        SDevInfo_t *psInfo = platform_get_drvdata(pdev);

        device_destroy(psInfo->m_cdev_class, psInfo->m_dev_num);
        class_destroy(psInfo->m_cdev_class);
        cdev_del(&psInfo->m_cdev);
        unregister_chrdev_region(psInfo->m_major_num, 1);
}


/**
 * dp_notify_probe - probe function.
 * @pdev:	Pointer to platform device structure.
 *
 * Return: 0, on success
 *	    Non-zero error value on failure.
 *
 * This is the probe routine for DP notify driver. This is called before
 * any other driver routines are invoked. It allocates and sets up the notify
 * device. Parses through device tree and populates fields of SDevInfo_t. 
 * It registers the notify device.
 */
static int dp_notify_probe(struct platform_device *pdev)
{
        int ret = 0;
        SDevInfo_t *psInfo;

        psInfo = devm_kzalloc(&pdev->dev, sizeof(SDevInfo_t), GFP_KERNEL);
        if(!psInfo)
                return -ENOMEM;

        platform_set_drvdata(pdev, psInfo);
        psInfo->m_dev = &pdev->dev;

        /*  getting irq number */
        psInfo->m_iIrq = platform_get_irq(pdev, 0);
        if(psInfo->m_iIrq <= 0) {
                dev_err(&pdev->dev,"IRQ not defined\n");
                return -1;
        }

        /* creating chrdev */
        ret = dp_reg_chrdev(pdev);
        if(ret != 0) {
                dev_err(&pdev->dev,"failed to register char dev\n");
                return -1;
        }

        /* Initializing wait quque */
        psInfo->m_iWaitqueue_flag = 0;
        init_waitqueue_head(&psInfo->m_waitqueue);


        return 0;
}

static int dp_notify_remove(struct platform_device *pdev)
{
        dp_unreg_chrdev(pdev);
        return 0;
}

static const struct of_device_id notify_of_match[] = {
        {.compatible = "dp,dp-notifier-1.0"},
        {},
};

MODULE_DEVICE_TABLE(of, notify_of_match);

static struct platform_driver notify_driver = {
        .probe = dp_notify_probe,
        .remove = dp_notify_remove,
        .driver = {
                .name = "Notifier",
                .of_match_table = notify_of_match,
        },
};

module_platform_driver(notify_driver);

MODULE_DESCRIPTION("AXI Event notification Driver");
MODULE_AUTHOR("Data Patterns India Ltd, Vishnu Ram G");
MODULE_LICENSE("GPL");
