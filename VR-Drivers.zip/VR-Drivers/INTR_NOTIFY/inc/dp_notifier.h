#ifndef DP_NOTIFIER_H
#define DP_NOTIFIER_H

#define DP_REG_CUR_TASK          _IOWR('R','2', unsigned long)

#define DP_EVENT_CONDITION	-9997
#define DP_EVENT_TIMEOUT	-9996

#endif
