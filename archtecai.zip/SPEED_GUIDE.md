# Speed Optimization Guide for Jetson Orin NX 16GB

## Your Problem: 5808 token prompt = 20-45 min

## Fix 1: Optimized llama.cpp server command (BIGGEST IMPACT)

```bash
./build/bin/llama-server \
  -m models/mistral-7b-instruct-v0.2.Q4_K_M.gguf \
  -c 4096 \
  --port 8080 \
  -ngl 99 \
  -t 4 \
  --batch-size 512 \
  --ubatch-size 256 \
  --flash-attn \
  --mlock \
  --no-mmap \
  --cont-batching \
  -np 1
```

Key changes:
- `-c 4096` instead of 8192 — halves memory and compute
- `--flash-attn` — major speedup if your build supports it
- `-np 1` — single slot saves memory
- `--mlock` — prevents swapping

If `--flash-attn` errors, remove that flag only.

## Fix 2: Compact prompts (already in updated app.py)

Before: 5808 tokens | After: ~2500-3000 tokens

## Fix 3: Generate section-by-section instead of full document

Use the "Regenerate Section" feature — 2-5 min per section.

## Expected improvement: 30-60 min down to 10-20 min
