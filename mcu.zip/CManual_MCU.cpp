#include "CManual_MCU.h"
#include "ui_CManual_MCU.h"

#include <QTime>
#include <QLabel>

// ── Voltage channel full-scale values (mV) ──────────────────────────────────
const int CManual_MCU::s_voltMax[8] = {
    3300,   // CH0 – VCC_3V3
    5000,   // CH1 – VCC_5V0
    12000,  // CH2 – VCC_12V
    1800,   // CH3 – VREF_1V8
    4200,   // CH4 – BATT_MON
    5000,   // CH5 – VSYS_AUX
    3300,   // CH6 – ADC_IN6
    3300    // CH7 – ADC_IN7
};

// ═══════════════════════════════════════════════════════════════════════════
//  CTOR / DTOR
// ═══════════════════════════════════════════════════════════════════════════
CManual_MCU::CManual_MCU(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::CManual_MCU)
{
    ui->setupUi(this);

    // System clock — updates header timestamp every second
    m_sysTimer = new QTimer(this);
    connect(m_sysTimer, &QTimer::timeout, this, &CManual_MCU::onSysTick);
    m_sysTimer->start(1000);
    onSysTick();
}

CManual_MCU::~CManual_MCU()
{
    delete ui;
}

// ═══════════════════════════════════════════════════════════════════════════
//  SYSTEM TICK
// ═══════════════════════════════════════════════════════════════════════════
void CManual_MCU::onSysTick()
{
    ui->lbl_timestamp->setText(
        QString("SYS: %1").arg(QTime::currentTime().toString("hh:mm:ss")));
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAGE 1 – TEMPERATURE  (public setters)
// ═══════════════════════════════════════════════════════════════════════════
void CManual_MCU::setLocalTemperature(float degC)
{
    ui->lbl_local_temp_val->setText(QString("%1 °C").arg(degC, 0, 'f', 1));
    updateTempMinMax(m_localStats, degC,
                     ui->lbl_local_min, ui->lbl_local_max);
}

void CManual_MCU::setExternalTemperature(float degC)
{
    ui->lbl_ext_temp_val->setText(QString("%1 °C").arg(degC, 0, 'f', 1));
    updateTempMinMax(m_extStats, degC,
                     ui->lbl_ext_min, ui->lbl_ext_max);
}

void CManual_MCU::setCoreTemperature(float degC)
{
    ui->lbl_core_temp_val->setText(QString("%1 °C").arg(degC, 0, 'f', 1));
    updateTempMinMax(m_coreStats, degC,
                     ui->lbl_core_min, ui->lbl_core_max);
}

// ── Temperature button slots ─────────────────────────────────────────────
void CManual_MCU::on_btn_temp_read_clicked()
{
    setTempStatus("READING SENSORS...", "#ffb347");
    emit sig_readTemperatures();
    setTempStatus("READ COMPLETE", "#00ff88");
}

void CManual_MCU::on_btn_temp_clear_clicked()
{
    ui->lbl_local_temp_val->setText("--.- °C");
    ui->lbl_ext_temp_val->setText("--.- °C");
    ui->lbl_core_temp_val->setText("--.- °C");

    ui->lbl_local_min->setText("MIN: --");
    ui->lbl_local_max->setText("MAX: --");
    ui->lbl_ext_min->setText("MIN: --");
    ui->lbl_ext_max->setText("MAX: --");
    ui->lbl_core_min->setText("MIN: --");
    ui->lbl_core_max->setText("MAX: --");

    m_localStats = {}; m_extStats = {}; m_coreStats = {};
    setTempStatus("IDLE — AWAITING READ COMMAND", "#4a6fa5");
    emit sig_clearTemperatures();
}

// ── Helper ────────────────────────────────────────────────────────────────
void CManual_MCU::updateTempMinMax(TempStats &s, float v,
                                    QLabel *lblMin, QLabel *lblMax)
{
    if (!s.valid || v < s.min) { s.min = v; s.valid = true; }
    if (!s.valid || v > s.max) { s.max = v; s.valid = true; }
    lblMin->setText(QString("MIN: %1").arg(s.min, 0, 'f', 1));
    lblMax->setText(QString("MAX: %1").arg(s.max, 0, 'f', 1));
}

void CManual_MCU::setTempStatus(const QString &msg, const QString &color)
{
    ui->lbl_temp_status_val->setText(msg);
    ui->lbl_temp_status_val->setStyleSheet(
        QString("color:%1;font-size:11px;letter-spacing:1px;").arg(color));
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAGE 2 – ETI  (public setters)
// ═══════════════════════════════════════════════════════════════════════════
void CManual_MCU::setEventCount(quint32 count)
{
    ui->lcd_event_count->display(static_cast<int>(count));
    int bar = qMin(static_cast<int>(count), ui->progressBar_events->maximum());
    ui->progressBar_events->setValue(bar);

    // Compute simple rate if elapsed > 0
    int elapsed = ui->lcd_elapsed_time->intValue();
    if (elapsed > 0) {
        float rate = (count * 1000.0f) / static_cast<float>(elapsed);
        ui->lbl_ev_rate->setText(
            QString("RATE:  %1  evt/s").arg(rate, 0, 'f', 1));
    }
}

void CManual_MCU::setElapsedTime(quint32 ms)
{
    ui->lcd_elapsed_time->display(static_cast<int>(ms));
    int bar = qMin(static_cast<int>(ms), ui->progressBar_time->maximum());
    ui->progressBar_time->setValue(bar);
    ui->lbl_et_period->setText(QString("PERIOD:  %1  ms").arg(ms));
}

void CManual_MCU::setEtiStatMin  (quint32 val) { ui->lbl_stat_min_val->setText(QString::number(val)); }
void CManual_MCU::setEtiStatMax  (quint32 val) { ui->lbl_stat_max_val->setText(QString::number(val)); }
void CManual_MCU::setEtiStatAvg  (float   val) { ui->lbl_stat_avg_val->setText(QString("%1 evt/s").arg(val, 0,'f',2)); }
void CManual_MCU::setOverflow    (bool    ov)
{
    ui->lbl_stat_ovf_val->setText(ov ? "OVERFLOW!" : "NONE");
    ui->lbl_stat_ovf_val->setStyleSheet(
        ov ? "color:#ff4444;font-weight:bold;font-size:11px;letter-spacing:1px;"
           : "color:#00ff88;font-weight:bold;font-size:11px;letter-spacing:1px;");
}
void CManual_MCU::setReadsDone   (quint32 reads) { ui->lbl_stat_reads_val->setText(QString::number(reads)); }

// ── ETI button slots ─────────────────────────────────────────────────────
void CManual_MCU::on_btn_eti_read_clicked()
{
    int ch   = ui->combo_eti_channel->currentIndex();
    int mode = ui->combo_eti_mode->currentIndex();

    ui->lbl_stat_ch_val->setText(QString("CH-%1").arg(ch));
    ++m_etiReads;
    ui->lbl_stat_reads_val->setText(QString::number(m_etiReads));

    emit sig_readEti(ch, mode);
}

void CManual_MCU::on_btn_eti_reset_clicked()
{
    ui->lcd_event_count->display(0);
    ui->lcd_elapsed_time->display(0);
    ui->progressBar_events->setValue(0);
    ui->progressBar_time->setValue(0);
    ui->lbl_ev_rate->setText("RATE:  --  evt/s");
    ui->lbl_et_period->setText("PERIOD:  --  ms");
    ui->lbl_stat_min_val->setText("--");
    ui->lbl_stat_max_val->setText("--");
    ui->lbl_stat_avg_val->setText("--");
    ui->lbl_stat_ovf_val->setText("NONE");
    ui->lbl_stat_ovf_val->setStyleSheet("color:#00ff88;font-weight:bold;font-size:11px;letter-spacing:1px;");
    ui->lbl_stat_ch_val->setText("--");
    m_etiReads = 0;
    ui->lbl_stat_reads_val->setText("0");

    emit sig_resetEti();
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAGE 3 – VOLTAGE  (public setter)
// ═══════════════════════════════════════════════════════════════════════════
void CManual_MCU::setChannelVoltage(int channel, float volts)
{
    if (channel < 0 || channel > 7) return;

    // Label references indexed by channel
    static const struct { QLabel** val; QProgressBar** bar; } chWidgets[8] = {
        { nullptr, nullptr }   // filled below — we use name-based lookup per call
    };

    // Use direct widget name access for clarity
    auto setVal = [&](QLabel *lbl, QProgressBar *pb, int maxMv) {
        lbl->setText(QString("%1 V").arg(volts, 7, 'f', 3));
        int mv = static_cast<int>(volts * 1000.0f);
        pb->setValue(qBound(0, mv, maxMv));
    };

    switch (channel) {
        case 0: setVal(ui->lbl_ch0_val, ui->progressBar_ch0, s_voltMax[0]); break;
        case 1: setVal(ui->lbl_ch1_val, ui->progressBar_ch1, s_voltMax[1]); break;
        case 2: setVal(ui->lbl_ch2_val, ui->progressBar_ch2, s_voltMax[2]); break;
        case 3: setVal(ui->lbl_ch3_val, ui->progressBar_ch3, s_voltMax[3]); break;
        case 4: setVal(ui->lbl_ch4_val, ui->progressBar_ch4, s_voltMax[4]); break;
        case 5: setVal(ui->lbl_ch5_val, ui->progressBar_ch5, s_voltMax[5]); break;
        case 6: setVal(ui->lbl_ch6_val, ui->progressBar_ch6, s_voltMax[6]); break;
        case 7: setVal(ui->lbl_ch7_val, ui->progressBar_ch7, s_voltMax[7]); break;
        default: break;
    }
}

// ── Voltage button slots ─────────────────────────────────────────────────
void CManual_MCU::on_btn_volt_read_clicked()
{
    setVoltStatus("READING ADC...", "#ffb347");
    emit sig_readVoltages(
        ui->combo_adc_ref->currentIndex(),
        ui->combo_adc_res->currentIndex());
    setVoltStatus("READ COMPLETE", "#00ff88");
}

void CManual_MCU::on_btn_volt_clear_clicked()
{
    const QString blank = "--.--- V";
    ui->lbl_ch0_val->setText(blank); ui->progressBar_ch0->setValue(0);
    ui->lbl_ch1_val->setText(blank); ui->progressBar_ch1->setValue(0);
    ui->lbl_ch2_val->setText(blank); ui->progressBar_ch2->setValue(0);
    ui->lbl_ch3_val->setText(blank); ui->progressBar_ch3->setValue(0);
    ui->lbl_ch4_val->setText(blank); ui->progressBar_ch4->setValue(0);
    ui->lbl_ch5_val->setText(blank); ui->progressBar_ch5->setValue(0);
    ui->lbl_ch6_val->setText(blank); ui->progressBar_ch6->setValue(0);
    ui->lbl_ch7_val->setText(blank); ui->progressBar_ch7->setValue(0);

    setVoltStatus("IDLE", "#4a6fa5");
    emit sig_clearVoltages();
}

void CManual_MCU::setVoltStatus(const QString &msg, const QString &color)
{
    ui->lbl_volt_status_val->setText(msg);
    ui->lbl_volt_status_val->setStyleSheet(
        QString("color:%1;font-size:11px;letter-spacing:1px;padding-left:8px;").arg(color));
}
