#ifndef CMANUAL_MCU_H
#define CMANUAL_MCU_H

#include <QWidget>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class CManual_MCU; }
QT_END_NAMESPACE

/**
 * @class CManual_MCU
 * @brief MCU Manual Test Console — 3-page board validation widget.
 *
 *  Page 1 – Temperature Test  : Local / External / Core sensor readout
 *  Page 2 – ETI Test          : Event Count & Elapsed Time per channel/mode
 *  Page 3 – Voltage Test      : 8-channel ADC readout with progress bars
 */
class CManual_MCU : public QWidget
{
    Q_OBJECT

public:
    explicit CManual_MCU(QWidget *parent = nullptr);
    ~CManual_MCU();

    /* ── Public API: call these from your hardware/HAL layer ─────────── */

    // Temperature (°C)
    void setLocalTemperature (float degC);
    void setExternalTemperature(float degC);
    void setCoreTemperature  (float degC);

    // ETI
    void setEventCount  (quint32 count);
    void setElapsedTime (quint32 ms);
    void setEtiStatMin  (quint32 val);
    void setEtiStatMax  (quint32 val);
    void setEtiStatAvg  (float   val);
    void setOverflow    (bool    overflow);
    void setReadsDone   (quint32 reads);

    // Voltage (V) — ch 0..7
    void setChannelVoltage(int channel, float volts);

signals:
    /* Emitted when the user clicks READ / CLEAR on each page */
    void sig_readTemperatures();
    void sig_clearTemperatures();

    void sig_readEti(int channel, int mode);
    void sig_resetEti();

    void sig_readVoltages(int adcRefIndex, int adcResIndex);
    void sig_clearVoltages();

private slots:
    // Temperature page
    void on_btn_temp_read_clicked();
    void on_btn_temp_clear_clicked();

    // ETI page
    void on_btn_eti_read_clicked();
    void on_btn_eti_reset_clicked();

    // Voltage page
    void on_btn_volt_read_clicked();
    void on_btn_volt_clear_clicked();

    // System clock tick (header timestamp)
    void onSysTick();

private:
    Ui::CManual_MCU *ui;
    QTimer          *m_sysTimer;

    // Min/Max tracking for temperature
    struct TempStats { float min = 999.f, max = -999.f; bool valid = false; };
    TempStats m_localStats, m_extStats, m_coreStats;

    // ETI read counter
    quint32 m_etiReads = 0;

    // Helpers
    void updateTempMinMax(TempStats &s, float v,
                          class QLabel *lblMin, class QLabel *lblMax);
    void setTempStatus(const QString &msg, const QString &color = "#00ff88");
    void setVoltStatus(const QString &msg, const QString &color = "#00ff88");

    // Voltage channel max-scale table (indexed 0..7)
    static const int s_voltMax[8];
};

#endif // CMANUAL_MCU_H
