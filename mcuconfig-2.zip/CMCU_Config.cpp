#include "CMCU_Config.h"
#include "ui_CMCU_Config.h"
#include "CManual_MCU.h"

#include <QSerialPortInfo>
#include <QApplication>

// ─────────────────────────────────────────────────────────────────────────────
//  CTOR / DTOR
// ─────────────────────────────────────────────────────────────────────────────
CMCU_Config::CMCU_Config(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::CMCU_Config)
    , m_serial(new QSerialPort(this))
{
    ui->setupUi(this);
    populatePorts();
}

CMCU_Config::~CMCU_Config()
{
    if (m_serial->isOpen())
        m_serial->close();
    delete ui;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Populate the combo box with all visible serial ports
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::populatePorts()
{
    ui->combo_port->clear();

    const QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();

    if (ports.isEmpty()) {
        ui->combo_port->addItem("No COM ports detected");
        ui->btn_connect->setEnabled(false);
        setLog("No USB serial device found — plug in the MCU and press ↻", "#ff6b6b");
        setPill("NO DEVICE", "#ff4444");
        return;
    }

    for (const QSerialPortInfo &info : ports) {
        // Label: "COM3  —  USB Serial Device"   userData = raw portName
        QString label = info.portName();
        if (!info.description().isEmpty())
            label += QString("  —  %1").arg(info.description());
        ui->combo_port->addItem(label, info.portName());
    }

    ui->btn_connect->setEnabled(true);
    setLog(QString("%1 port(s) available — select port and press CONNECT")
               .arg(ports.size()), "#7ec8e3");
    setPill("DISCONNECTED", "#4a6fa5");
}

// ─────────────────────────────────────────────────────────────────────────────
//  CONNECT button
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::on_btn_connect_clicked()
{
    const QString portName = ui->combo_port->currentData().toString();
    if (portName.isEmpty()) {
        setLog("No port selected!", "#ff6b6b");
        return;
    }

    // ── Apply hardcoded serial settings ──────────────────────────────────
    m_serial->setPortName   (portName);
    m_serial->setBaudRate   (BAUD);
    m_serial->setDataBits   (DATA);
    m_serial->setParity     (PARITY);
    m_serial->setStopBits   (STOP);
    m_serial->setFlowControl(FLOW);

    // ── Visual feedback while opening ────────────────────────────────────
    ui->btn_connect->setEnabled(false);
    ui->btn_refresh->setEnabled(false);
    ui->combo_port->setEnabled(false);
    setLog(QString("Opening %1  @  115200  8N1 …").arg(portName), "#ffb347");
    setPill("CONNECTING …", "#ffb347");
    QApplication::processEvents();

    // ── Attempt open ──────────────────────────────────────────────────────
    if (!m_serial->open(QIODevice::ReadWrite)) {
        // FAILURE — stay in dialog so user can retry or cancel
        ui->btn_connect->setEnabled(true);
        ui->btn_refresh->setEnabled(true);
        ui->combo_port->setEnabled(true);
        setLog(QString("Failed: %1").arg(m_serial->errorString()), "#ff6b6b");
        setPill("FAILED", "#ff4444");
        return;
    }

    // ── SUCCESS ───────────────────────────────────────────────────────────
    setLog(QString("Connected  —  %1  @  115200  8N1").arg(portName), "#00ff88");
    setPill("CONNECTED", "#00ff88");
    QApplication::processEvents();

    // Open the MCU test console as a standalone top-level window
    m_mcuWin = new CManual_MCU(nullptr);
    m_mcuWin->setWindowTitle(
        QString("MCU Manual Test Console  —  %1").arg(portName));
    m_mcuWin->show();

    // Dismiss this dialog; exec() returns QDialog::Accepted to the caller
    accept();
}

// ─────────────────────────────────────────────────────────────────────────────
//  CANCEL button  →  go back to Home (exec() returns QDialog::Rejected)
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::on_btn_cancel_clicked()
{
    reject();
}

// ─────────────────────────────────────────────────────────────────────────────
//  REFRESH button  →  re-scan ports
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::on_btn_refresh_clicked()
{
    populatePorts();
}

// ─────────────────────────────────────────────────────────────────────────────
//  Port selection changed  →  show brief info in status bar
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::on_combo_port_currentIndexChanged(int /*index*/)
{
    const QString portName = ui->combo_port->currentData().toString();
    if (portName.isEmpty()) return;

    for (const QSerialPortInfo &info : QSerialPortInfo::availablePorts()) {
        if (info.portName() != portName) continue;

        QString detail = info.portName();
        if (!info.manufacturer().isEmpty())
            detail += "  ·  " + info.manufacturer();
        if (!info.serialNumber().isEmpty())
            detail += "  ·  S/N: " + info.serialNumber();
        setLog(detail, "#7ec8e3");
        return;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Helpers
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::setLog(const QString &msg, const QString &color)
{
    ui->lbl_log->setText(msg);
    ui->lbl_log->setStyleSheet(
        QString("color:%1;font-size:10px;letter-spacing:0.5px;").arg(color));
}

void CMCU_Config::setPill(const QString &text, const QString &color)
{
    ui->lbl_pill_status->setText(text);
    ui->lbl_pill_status->setStyleSheet(
        QString("color:%1;font-size:9px;font-weight:bold;letter-spacing:1.5px;").arg(color));
    ui->lbl_dot->setStyleSheet(
        QString("color:%1;font-size:12px;").arg(color));
}
