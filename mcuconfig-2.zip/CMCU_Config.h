#ifndef CMCU_CONFIG_H
#define CMCU_CONFIG_H

#include <QDialog>
#include <QSerialPort>

QT_BEGIN_NAMESPACE
namespace Ui { class CMCU_Config; }
QT_END_NAMESPACE

class CManual_MCU;

/**
 * @class CMCU_Config
 * @brief USB serial port selection dialog.
 *
 * Serial parameters are fixed in code (115200 / 8N1 / No flow control).
 * User only picks the COM port.
 *
 * Outcomes:
 *   CONNECT success  →  opens CManual_MCU, this dialog closes (accept)
 *   CONNECT fail     →  shows error in status bar, stays open
 *   CANCEL           →  closes dialog (reject) → caller returns to Home
 */
class CMCU_Config : public QDialog
{
    Q_OBJECT

public:
    explicit CMCU_Config(QWidget *parent = nullptr);
    ~CMCU_Config();

    /** The open serial port – valid only after accepted() is emitted. */
    QSerialPort *serialPort() const { return m_serial; }

private slots:
    void on_btn_connect_clicked();
    void on_btn_cancel_clicked();
    void on_btn_refresh_clicked();
    void on_combo_port_currentIndexChanged(int index);

private:
    // ── Fixed serial settings ─────────────────────────────────────────────
    static constexpr qint32              BAUD      = 115200;
    static constexpr QSerialPort::DataBits  DATA   = QSerialPort::Data8;
    static constexpr QSerialPort::Parity    PARITY = QSerialPort::NoParity;
    static constexpr QSerialPort::StopBits  STOP   = QSerialPort::OneStop;
    static constexpr QSerialPort::FlowControl FLOW = QSerialPort::NoFlowControl;

    // ── Helpers ───────────────────────────────────────────────────────────
    void populatePorts();
    void setLog(const QString &msg,  const QString &color = "#4a6fa5");
    void setPill(const QString &text, const QString &color);

    Ui::CMCU_Config *ui       = nullptr;
    QSerialPort     *m_serial = nullptr;
    CManual_MCU     *m_mcuWin = nullptr;
};

#endif // CMCU_CONFIG_H
