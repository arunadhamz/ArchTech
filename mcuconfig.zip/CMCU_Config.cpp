#include "CMCU_Config.h"
#include "ui_CMCU_Config.h"
#include "CManual_MCU.h"

#include <QSerialPort>
#include <QSerialPortInfo>
#include <QMessageBox>

// ─────────────────────────────────────────────────────────────────────────────
//  Baud-rate index → Qt enum map
// ─────────────────────────────────────────────────────────────────────────────
static const QSerialPort::BaudRate kBaudMap[] = {
    QSerialPort::Baud9600,
    QSerialPort::Baud19200,
    QSerialPort::Baud38400,
    QSerialPort::Baud57600,
    QSerialPort::Baud115200,
    static_cast<QSerialPort::BaudRate>(230400),
    static_cast<QSerialPort::BaudRate>(460800),
    static_cast<QSerialPort::BaudRate>(921600)
};

static const QSerialPort::DataBits kDataBitsMap[] = {
    QSerialPort::Data8,
    QSerialPort::Data7,
    QSerialPort::Data6,
    QSerialPort::Data5
};

static const QSerialPort::Parity kParityMap[] = {
    QSerialPort::NoParity,
    QSerialPort::EvenParity,
    QSerialPort::OddParity,
    QSerialPort::SpaceParity,
    QSerialPort::MarkParity
};

static const QSerialPort::StopBits kStopBitsMap[] = {
    QSerialPort::OneStop,
    QSerialPort::OneAndHalfStop,
    QSerialPort::TwoStop
};

// ─────────────────────────────────────────────────────────────────────────────
//  CTOR / DTOR
// ─────────────────────────────────────────────────────────────────────────────
CMCU_Config::CMCU_Config(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::CMCU_Config)
    , m_serial(new QSerialPort(this))
{
    ui->setupUi(this);
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    setAttribute(Qt::WA_TranslucentBackground);

    // Default to 115200 baud
    ui->combo_baud->setCurrentIndex(4);

    connect(m_serial, &QSerialPort::errorOccurred,
            this, &CMCU_Config::onSerialError);

    populatePorts();
    setConnected(false);
}

CMCU_Config::~CMCU_Config()
{
    if (m_serial->isOpen())
        m_serial->close();
    delete ui;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Port enumeration
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::populatePorts()
{
    ui->combo_port->clear();

    const QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();
    if (ports.isEmpty()) {
        ui->combo_port->addItem("No COM ports found");
        ui->btn_connect->setEnabled(false);
        setStatus("No USB serial device detected", "#ff6b6b", "#ff4444");
        return;
    }

    for (const QSerialPortInfo &info : ports) {
        // Label: "COM3  —  USB Serial Device (VID:PID)"
        QString label = info.portName();
        if (!info.description().isEmpty())
            label += QString("  —  %1").arg(info.description());
        if (info.hasVendorIdentifier())
            label += QString("  [%1:%2]")
                         .arg(info.vendorIdentifier(),  4, 16, QChar('0'))
                         .arg(info.productIdentifier(), 4, 16, QChar('0'));
        ui->combo_port->addItem(label, info.portName());
    }

    ui->btn_connect->setEnabled(true);
    setStatus(QString("%1 port(s) found — select and press CONNECT")
                  .arg(ports.size()), "#7ec8e3", "#4a6fa5");
}

// ─────────────────────────────────────────────────────────────────────────────
//  Apply combo-box settings to QSerialPort
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::applySerialSettings()
{
    m_serial->setBaudRate  (kBaudMap    [ui->combo_baud->currentIndex()]);
    m_serial->setDataBits  (kDataBitsMap[ui->combo_databits->currentIndex()]);
    m_serial->setParity    (kParityMap  [ui->combo_parity->currentIndex()]);
    m_serial->setStopBits  (kStopBitsMap[ui->combo_stopbits->currentIndex()]);
    m_serial->setFlowControl(QSerialPort::NoFlowControl);
}

// ─────────────────────────────────────────────────────────────────────────────
//  CONNECT button
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::on_btn_connect_clicked()
{
    // ── If already connected, disconnect ─────────────────────────────────────
    if (m_serial->isOpen()) {
        m_serial->close();
        setConnected(false);
        setStatus("Disconnected", "#4a6fa5", "#4a6fa5");
        ui->btn_connect->setText("CONNECT");
        return;
    }

    // ── Guard: no port selected ───────────────────────────────────────────────
    if (ui->combo_port->currentData().isNull()) {
        setStatus("No port selected!", "#ff6b6b", "#ff4444");
        return;
    }

    // ── Configure & open ──────────────────────────────────────────────────────
    const QString portName = ui->combo_port->currentData().toString();
    m_serial->setPortName(portName);
    applySerialSettings();

    setStatus(QString("Opening %1 ...").arg(portName), "#ffb347", "#ffb347");
    ui->btn_connect->setEnabled(false);
    QApplication::processEvents();

    if (!m_serial->open(QIODevice::ReadWrite)) {
        ui->btn_connect->setEnabled(true);
        setStatus(QString("Failed: %1").arg(m_serial->errorString()),
                  "#ff6b6b", "#ff4444");
        return;
    }

    // ── SUCCESS ───────────────────────────────────────────────────────────────
    setConnected(true);
    setStatus(QString("Connected to %1  @  %2 baud")
                  .arg(portName)
                  .arg(ui->combo_baud->currentText()),
              "#00ff88", "#00ff88");
    ui->btn_connect->setText("DISCONNECT");
    ui->btn_connect->setEnabled(true);

    // ── Launch CManual_MCU ────────────────────────────────────────────────────
    m_mcuWin = new CManual_MCU(nullptr);   // top-level window
    m_mcuWin->setWindowTitle(
        QString("MCU Manual Test Console  —  %1").arg(portName));

    // Forward disconnect: if serial is closed externally, notify the MCU window
    connect(m_serial, &QSerialPort::errorOccurred,
            m_mcuWin, [this](QSerialPort::SerialPortError err) {
        if (err != QSerialPort::NoError && m_mcuWin)
            m_mcuWin->setWindowTitle("MCU Manual Test Console  [DISCONNECTED]");
    });

    m_mcuWin->show();

    // Close (accept) this dialog now that we're connected
    accept();
}

// ─────────────────────────────────────────────────────────────────────────────
//  CANCEL button
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::on_btn_cancel_clicked()
{
    if (m_serial->isOpen())
        m_serial->close();
    reject();
}

// ─────────────────────────────────────────────────────────────────────────────
//  REFRESH button
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::on_btn_refresh_clicked()
{
    if (m_serial->isOpen()) return;   // don't repopulate while connected
    populatePorts();
}

// ─────────────────────────────────────────────────────────────────────────────
//  Port combo changed — show port details in status bar
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::on_combo_port_currentIndexChanged(int /*index*/)
{
    if (m_serial->isOpen()) return;

    const QString portName = ui->combo_port->currentData().toString();
    if (portName.isEmpty()) return;

    for (const QSerialPortInfo &info : QSerialPortInfo::availablePorts()) {
        if (info.portName() == portName) {
            QString detail = info.portName();
            if (!info.manufacturer().isEmpty())
                detail += "  ·  " + info.manufacturer();
            if (!info.serialNumber().isEmpty())
                detail += "  ·  S/N: " + info.serialNumber();
            setStatus(detail, "#7ec8e3", "#4a6fa5");
            return;
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Serial error handler
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::onSerialError(QSerialPort::SerialPortError error)
{
    if (error == QSerialPort::NoError) return;

    if (m_serial->isOpen())
        m_serial->close();

    setConnected(false);
    ui->btn_connect->setText("CONNECT");
    setStatus(QString("Serial error: %1").arg(m_serial->errorString()),
              "#ff6b6b", "#ff4444");
}

// ─────────────────────────────────────────────────────────────────────────────
//  UI helpers
// ─────────────────────────────────────────────────────────────────────────────
void CMCU_Config::setStatus(const QString &msg,
                             const QString &color,
                             const QString &dot)
{
    ui->lbl_log->setText(msg);
    ui->lbl_log->setStyleSheet(
        QString("color:%1;font-size:10px;letter-spacing:0.5px;").arg(color));
    ui->lbl_status_dot->setStyleSheet(
        QString("font-size:12px;color:%1;").arg(dot));
    ui->lbl_status_text->setStyleSheet(
        QString("color:%1;font-size:9px;font-weight:bold;letter-spacing:1.5px;").arg(color));
}

void CMCU_Config::setConnected(bool connected)
{
    // Freeze controls while connected
    ui->combo_port->setEnabled(!connected);
    ui->combo_baud->setEnabled(!connected);
    ui->combo_databits->setEnabled(!connected);
    ui->combo_parity->setEnabled(!connected);
    ui->combo_stopbits->setEnabled(!connected);
    ui->btn_refresh->setEnabled(!connected);

    ui->lbl_status_text->setText(connected ? "CONNECTED" : "DISCONNECTED");
}
