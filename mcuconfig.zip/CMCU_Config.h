#ifndef CMCU_CONFIG_H
#define CMCU_CONFIG_H

#include <QDialog>
#include <QSerialPort>
#include <QSerialPortInfo>

QT_BEGIN_NAMESPACE
namespace Ui { class CMCU_Config; }
QT_END_NAMESPACE

class CManual_MCU;

/**
 * @class CMCU_Config
 * @brief USB Serial configuration dialog.
 *
 * Workflow:
 *   1. Lists all available COM ports in the combo box.
 *   2. User selects port + baud / data-bits / parity / stop-bits.
 *   3. On CONNECT → opens QSerialPort; on success → launches CManual_MCU.
 *   4. CANCEL closes the dialog.
 */
class CMCU_Config : public QDialog
{
    Q_OBJECT

public:
    explicit CMCU_Config(QWidget *parent = nullptr);
    ~CMCU_Config();

    /** Returns the open serial port (caller does NOT own it). */
    QSerialPort *serialPort() const { return m_serial; }

private slots:
    void on_btn_connect_clicked();
    void on_btn_cancel_clicked();
    void on_btn_refresh_clicked();
    void on_combo_port_currentIndexChanged(int index);

    void onSerialError(QSerialPort::SerialPortError error);

private:
    void populatePorts();
    void applySerialSettings();
    void setStatus(const QString &msg,
                   const QString &color  = "#4a6fa5",
                   const QString &dot    = "#4a6fa5");
    void setConnected(bool connected);

    Ui::CMCU_Config *ui      = nullptr;
    QSerialPort     *m_serial = nullptr;
    CManual_MCU     *m_mcuWin = nullptr;
};

#endif // CMCU_CONFIG_H
